# R8 Full Mode Rules for Stayar (com.workshop.ledger)
-optimizationpasses 5
-allowaccessmodification

# Keep kotlinx.serialization Backup DTOs
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.AnnotationsKt
-keepclassmembers class com.workshop.ledger.** {
    *** Companion;
}
-keepclasseswithmembers class com.workshop.ledger.** {
    kotlinx.serialization.KSerializer serializer(...);
}

# Keep Room Database & Entities
-keep class * extends androidx.room.RoomDatabase
-keep @androidx.room.Entity class *
-dontwarn androidx.room.paging.**

# Keep Protobuf Lite generated classes
-keep class com.workshop.ledger.datastore.proto.** { *; }
