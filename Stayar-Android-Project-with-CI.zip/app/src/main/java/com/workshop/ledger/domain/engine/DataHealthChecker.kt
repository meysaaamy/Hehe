package com.workshop.ledger.domain.engine

import com.workshop.ledger.domain.model.AttendanceValue
import com.workshop.ledger.domain.model.Project
import com.workshop.ledger.domain.model.ReportRange
import com.workshop.ledger.domain.model.UserType

enum class HealthSeverity {
    OK,
    WARN,
    ERROR
}

data class HealthRuleResult(
    val code: String,
    val titleFa: String,
    val severity: HealthSeverity,
    val messageFa: String,
    val targetPage: String,
    val canCleanOrphans: Boolean = false
)

object DataHealthChecker {

    /**
     * Evaluates all 9 QA rules over the WHOLE project (range cleared).
     */
    fun check(project: Project): List<HealthRuleResult> {
        val fullRange = ReportRange("", "")
        val r = AccountingEngine.compute(project, fullRange)
        val liveUsers = project.liveUsers()
        val liveUserMap = liveUsers.associateBy { it.id }
        val results = mutableListOf<HealthRuleResult>()

        // Rule 1: master — At least one active master
        val activeMasters = liveUsers.filter { it.type == UserType.MASTER && it.active }
        if (activeMasters.isEmpty()) {
            results.add(
                HealthRuleResult(
                    code = "master",
                    titleFa = "حداقل یک اوستای فعال",
                    severity = HealthSeverity.ERROR,
                    messageFa = "هیچ اوستای فعالی برای تقسیم سود وجود ندارد.",
                    targetPage = "users"
                )
            )
        } else {
            results.add(
                HealthRuleResult(
                    code = "master",
                    titleFa = "حداقل یک اوستای فعال",
                    severity = HealthSeverity.OK,
                    messageFa = "حداقل یک اوستای فعال — سالم است",
                    targetPage = "users"
                )
            )
        }

        // Rule 2: wage — Active staff with attendance but no wage
        val staffWithoutWage = liveUsers.filter { u ->
            u.type != UserType.MASTER && u.active &&
                project.wages.none { it.userId == u.id && it.rate > 0L } &&
                project.attendance.values.any { day -> day.containsKey(u.id) }
        }
        if (staffWithoutWage.isNotEmpty()) {
            val names = staffWithoutWage.joinToString("، ") { it.name }
            results.add(
                HealthRuleResult(
                    code = "wage",
                    titleFa = "نرخ دستمزد شاگردان",
                    severity = HealthSeverity.ERROR,
                    messageFa = "حضور ثبت شده اما هیچ نرخ دستمزدی تعریف نشده: $names",
                    targetPage = "wages"
                )
            )
        } else {
            results.add(
                HealthRuleResult(
                    code = "wage",
                    titleFa = "نرخ دستمزد شاگردان",
                    severity = HealthSeverity.OK,
                    messageFa = "نرخ دستمزد شاگردان — سالم است",
                    targetPage = "wages"
                )
            )
        }

        // Rule 3: hours — Invalid/over-24 attendance
        val invalidAttLabels = mutableListOf<String>()
        for ((date, dayMap) in project.attendance.entries.sortedBy { it.key }) {
            for ((uid, v) in dayMap) {
                val u = liveUserMap[uid] ?: continue
                val f = AccountingEngine.attFr(v, project)
                if (f == null || (v is AttendanceValue.Hourly && (v.hours < 0.0 || v.hours > 24.0))) {
                    invalidAttLabels.add("${u.name} ($date)")
                }
            }
        }
        if (invalidAttLabels.isNotEmpty()) {
            val sample = invalidAttLabels.take(4).joinToString("، ")
            results.add(
                HealthRuleResult(
                    code = "hours",
                    titleFa = "مقادیر حضور",
                    severity = HealthSeverity.ERROR,
                    messageFa = "ساعت منفی، بیش از ۲۴ یا مقدار نامعتبر در حضور: $sample",
                    targetPage = "attendance"
                )
            )
        } else {
            results.add(
                HealthRuleResult(
                    code = "hours",
                    titleFa = "مقادیر حضور",
                    severity = HealthSeverity.OK,
                    messageFa = "مقادیر حضور — سالم است",
                    targetPage = "attendance"
                )
            )
        }

        // Rule 4: inactive-att — Attendance for inactive users
        val inactiveUsers = liveUsers.filter { !it.active }
        var inactiveAttCount = 0
        val inactiveNamesWithAtt = linkedSetOf<String>()
        for (dayMap in project.attendance.values) {
            for (u in inactiveUsers) {
                if (dayMap.containsKey(u.id)) {
                    inactiveAttCount++
                    inactiveNamesWithAtt.add(u.name)
                }
            }
        }
        if (inactiveAttCount > 0) {
            val names = inactiveNamesWithAtt.joinToString("، ")
            results.add(
                HealthRuleResult(
                    code = "inactive-att",
                    titleFa = "حضور نیروهای غیرفعال",
                    severity = HealthSeverity.WARN,
                    messageFa = "$inactiveAttCount ثبت حضور برای نیروی غیرفعال ($names) هست؛ در حساب‌ها حساب می‌شود ولی در صفحهٔ حضور دیده نمی‌شود. برای دیدن یا ویرایش، آن‌ها را فعال کنید.",
                    targetPage = "users"
                )
            )
        } else {
            results.add(
                HealthRuleResult(
                    code = "inactive-att",
                    titleFa = "حضور نیروهای غیرفعال",
                    severity = HealthSeverity.OK,
                    messageFa = "حضور نیروهای غیرفعال — سالم است",
                    targetPage = "users"
                )
            )
        }

        // Rule 5: orphan — Records pointing to deleted/missing users
        val orphanStats = detectOrphans(project)
        if (orphanStats.total > 0) {
            val parts = mutableListOf<String>()
            if (orphanStats.attendance > 0) parts.add("${orphanStats.attendance} حضور")
            if (orphanStats.wages > 0) parts.add("${orphanStats.wages} نرخ")
            if (orphanStats.payouts > 0) parts.add("${orphanStats.payouts} پرداختی")
            if (orphanStats.adjustments > 0) parts.add("${orphanStats.adjustments} تعدیل")
            if (orphanStats.transfers > 0) parts.add("${orphanStats.transfers} انتقال")
            if (orphanStats.expenses > 0) parts.add("${orphanStats.expenses} هزینه")
            results.add(
                HealthRuleResult(
                    code = "orphan",
                    titleFa = "رکوردهای یتیم",
                    severity = HealthSeverity.WARN,
                    messageFa = "رکورد باقی‌مانده از کاربران حذف‌شده: ${parts.joinToString("، ")}",
                    targetPage = "health",
                    canCleanOrphans = true
                )
            )
        } else {
            results.add(
                HealthRuleResult(
                    code = "orphan",
                    titleFa = "رکوردهای یتیم",
                    severity = HealthSeverity.OK,
                    messageFa = "رکوردهای یتیم — سالم است",
                    targetPage = "health"
                )
            )
        }

        // Rule 6: cat — Uncategorized expenses
        val validCatIds = project.categories.map { it.id }.toSet()
        val uncategorized = project.expenses.filter {
            it.active && (it.categoryId.isNullOrBlank() || it.categoryId !in validCatIds)
        }
        if (uncategorized.isNotEmpty()) {
            val sample = uncategorized.take(3).joinToString("، ") { it.description }
            results.add(
                HealthRuleResult(
                    code = "cat",
                    titleFa = "دسته‌بندی هزینه‌ها",
                    severity = HealthSeverity.WARN,
                    messageFa = "${uncategorized.size} هزینه بدون دسته‌بندی: $sample",
                    targetPage = "expenses"
                )
            )
        } else {
            results.add(
                HealthRuleResult(
                    code = "cat",
                    titleFa = "دسته‌بندی هزینه‌ها",
                    severity = HealthSeverity.OK,
                    messageFa = "دسته‌بندی هزینه‌ها — سالم است",
                    targetPage = "expenses"
                )
            )
        }

        // Rule 7: amount — Invalid date or negative/zero amount
        val badAmountLabels = mutableListOf<String>()
        for (e in project.expenses) {
            if (e.amount <= 0L || !JalaliCalendarEngine.isValidStrictProjectJalaliDate(e.date)) {
                badAmountLabels.add("هزینه (${e.description})")
            }
        }
        for (rec in project.receipts) {
            if (rec.amount <= 0L ||
                !JalaliCalendarEngine.isValidStrictProjectJalaliDate(rec.dateFrom) ||
                !JalaliCalendarEngine.isValidStrictProjectJalaliDate(rec.dateTo) ||
                rec.dateTo < rec.dateFrom
            ) {
                badAmountLabels.add("واریزی (${rec.description.ifBlank { rec.dateFrom }})")
            }
        }
        for (p in project.payouts) {
            if (p.amount <= 0L || !JalaliCalendarEngine.isValidStrictProjectJalaliDate(p.date)) {
                badAmountLabels.add("پرداختی (${p.date})")
            }
        }
        if (badAmountLabels.isNotEmpty()) {
            results.add(
                HealthRuleResult(
                    code = "amount",
                    titleFa = "مبلغ و تاریخ رکوردها",
                    severity = HealthSeverity.ERROR,
                    messageFa = "مبلغ منفی/تهی یا تاریخ نامعتبر: ${badAmountLabels.take(4).joinToString("، ")}",
                    targetPage = "expenses"
                )
            )
        } else {
            results.add(
                HealthRuleResult(
                    code = "amount",
                    titleFa = "مبلغ و تاریخ رکوردها",
                    severity = HealthSeverity.OK,
                    messageFa = "مبلغ و تاریخ رکوردها — سالم است",
                    targetPage = "expenses"
                )
            )
        }

        // Rule 8: overpay — Staff with negative debt (overpaid)
        val overpaidStaff = r.staff.filter { it.debt < 0L }
        if (overpaidStaff.isNotEmpty()) {
            val details = overpaidStaff.joinToString("، ") { "${it.name} (${TextNormalizer.fmt(-it.debt)})" }
            results.add(
                HealthRuleResult(
                    code = "overpay",
                    titleFa = "اضافه‌پرداخت به شاگردان",
                    severity = HealthSeverity.WARN,
                    messageFa = "پرداختی بیشتر از استحقاق: $details",
                    targetPage = "payouts"
                )
            )
        } else {
            results.add(
                HealthRuleResult(
                    code = "overpay",
                    titleFa = "اضافه‌پرداخت به شاگردان",
                    severity = HealthSeverity.OK,
                    messageFa = "اضافه‌پرداخت به شاگردان — سالم است",
                    targetPage = "payouts"
                )
            )
        }

        // Rule 9: share — Active masters' total work is 0 while profit != 0 or attendance exists
        val hasAnyAttendance = project.attendance.values.any { it.isNotEmpty() }
        if (r.totalWorkFinal == 0.0 && (r.profit != 0L || hasAnyAttendance)) {
            results.add(
                HealthRuleResult(
                    code = "share",
                    titleFa = "تقسیم سود",
                    severity = HealthSeverity.WARN,
                    messageFa = "کارکرد اوستاهای فعال ۰ است و سود تقسیم نمی‌شود.",
                    targetPage = "attendance"
                )
            )
        } else {
            results.add(
                HealthRuleResult(
                    code = "share",
                    titleFa = "تقسیم سود",
                    severity = HealthSeverity.OK,
                    messageFa = "تقسیم سود — سالم است",
                    targetPage = "attendance"
                )
            )
        }

        return results
    }

    data class OrphanStats(
        val attendance: Int,
        val wages: Int,
        val payouts: Int,
        val adjustments: Int,
        val transfers: Int,
        val expenses: Int
    ) {
        val total: Int
            get() = attendance + wages + payouts + adjustments + transfers + expenses
    }

    fun detectOrphans(project: Project): OrphanStats {
        val liveIds = project.liveUsers().map { it.id }.toSet()
        var attOrphans = 0
        for (dayMap in project.attendance.values) {
            for (uid in dayMap.keys) {
                if (uid !in liveIds) attOrphans++
            }
        }
        val wageOrphans = project.wages.count { it.userId !in liveIds }
        val payoutOrphans = project.payouts.count { it.userId !in liveIds }
        val adjOrphans = project.adjustments.count { it.userId !in liveIds }
        val transferOrphans = project.transfers.count {
            it.toId !in liveIds || (it.fromId != null && it.fromId !in liveIds)
        }
        val expenseOrphans = project.expenses.count {
            it.payerId != "shared" && it.payerId !in liveIds
        }
        return OrphanStats(
            attendance = attOrphans,
            wages = wageOrphans,
            payouts = payoutOrphans,
            adjustments = adjOrphans,
            transfers = transferOrphans,
            expenses = expenseOrphans
        )
    }

    fun cleanOrphans(project: Project): Project {
        val liveIds = project.liveUsers().map { it.id }.toSet()
        val cleanedAttendance = project.attendance.mapNotNull { (date, dayMap) ->
            val filtered = dayMap.filterKeys { it in liveIds }
            if (filtered.isEmpty()) null else date to filtered
        }.toMap()

        return project.copy(
            users = project.liveUsers(),
            attendance = cleanedAttendance,
            wages = project.wages.filter { it.userId in liveIds },
            payouts = project.payouts.filter { it.userId in liveIds },
            adjustments = project.adjustments.filter { it.userId in liveIds },
            transfers = project.transfers.filter {
                it.toId in liveIds && (it.fromId == null || it.fromId in liveIds)
            },
            expenses = project.expenses.map { e ->
                if (e.payerId != "shared" && e.payerId !in liveIds) {
                    e.copy(payerId = "shared")
                } else {
                    e
                }
            }
        )
    }
}
