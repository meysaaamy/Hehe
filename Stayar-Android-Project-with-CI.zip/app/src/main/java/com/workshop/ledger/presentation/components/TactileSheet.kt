package com.workshop.ledger.presentation.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.workshop.ledger.presentation.theme.StayarTheme

@Composable
fun TactileSheet(
    titleFa: String,
    onDismissRequest: () -> Unit,
    hasUnsavedChanges: Boolean = false,
    content: @Composable ColumnScope.() -> Unit
) {
    val colors = StayarTheme.colors
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var showUnsavedConfirm by remember { mutableStateOf(false) }

    ModalBottomSheet(
        onDismissRequest = {
            if (hasUnsavedChanges) {
                showUnsavedConfirm = true
            } else {
                onDismissRequest()
            }
        },
        sheetState = sheetState,
        containerColor = colors.bgElev,
        contentColor = colors.text,
        shape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 18.dp, vertical = 8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = titleFa,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.text
                )
                TextButton(
                    onClick = {
                        if (hasUnsavedChanges) {
                            showUnsavedConfirm = true
                        } else {
                            onDismissRequest()
                        }
                    }
                ) {
                    Text("بستن", color = colors.textDim, fontWeight = FontWeight.SemiBold)
                }
            }
            HorizontalDivider(color = colors.border, thickness = colors.defaultBorderWidth)
            Spacer(modifier = Modifier.height(12.dp))
            content()
            Spacer(modifier = Modifier.height(16.dp))
        }
    }

    if (showUnsavedConfirm) {
        AlertDialog(
            onDismissRequest = { showUnsavedConfirm = false },
            containerColor = colors.bgElev,
            title = {
                Text("تغییرات ذخیره‌نشده", fontWeight = FontWeight.Bold, color = colors.text)
            },
            text = {
                Text("تغییرات فرم هنوز ذخیره نشده است. بدون ذخیره بسته شود؟", color = colors.textDim)
            },
            confirmButton = {
                Button(
                    onClick = {
                        showUnsavedConfirm = false
                        onDismissRequest()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = colors.danger)
                ) {
                    Text("بستن بدون ذخیره", color = colors.onAccent)
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { showUnsavedConfirm = false },
                    border = BorderStroke(colors.defaultBorderWidth, colors.borderStrong)
                ) {
                    Text("ادامه ویرایش", color = colors.text)
                }
            }
        )
    }
}
