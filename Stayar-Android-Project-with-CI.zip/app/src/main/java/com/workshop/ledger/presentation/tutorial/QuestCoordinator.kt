package com.workshop.ledger.presentation.tutorial

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.workshop.ledger.domain.engine.TextNormalizer
import com.workshop.ledger.domain.model.AccountingResult
import com.workshop.ledger.domain.model.Project
import com.workshop.ledger.domain.tutorial.OnboardingState
import com.workshop.ledger.domain.tutorial.TutorialChapters
import com.workshop.ledger.domain.tutorial.TutorialRuntimeEvents
import com.workshop.ledger.domain.tutorial.TutorialStep
import com.workshop.ledger.presentation.components.BadgePill
import com.workshop.ledger.presentation.components.TactileSheet
import com.workshop.ledger.presentation.theme.StayarTheme

/**
 * Reactive Compose-native QuestCoordinator replacing legacy 350ms DOM polling and CSS selectors.
 * Tracks exact live window `Rect` coordinates via `Modifier.questTarget(targetId)`.
 */
class QuestCoordinator {

    val targetRects = mutableStateMapOf<String, Rect>()
    var runtimeEvents by mutableStateOf(TutorialRuntimeEvents())
        private set
    var stepDoneBanner by mutableStateOf<String?>(null)
    var showGraduationSheet by mutableStateOf(false)
    var showPracticeChooserSheet by mutableStateOf(false)

    fun updateTargetRect(targetId: String, rect: Rect) {
        targetRects[targetId] = rect
    }

    fun removeTargetRect(targetId: String) {
        targetRects.remove(targetId)
    }

    fun onPageChanged(pageId: String) {
        runtimeEvents = runtimeEvents.copy(
            currentPage = pageId,
            visitedHealthPage = runtimeEvents.visitedHealthPage || pageId == "health"
        )
    }

    fun onOpenedProfitRuler() {
        runtimeEvents = runtimeEvents.copy(openedProfitRuler = true)
    }

    fun onViewedStatement(userId: String) {
        runtimeEvents = runtimeEvents.copy(viewedStatementUserId = userId)
    }

    fun onExportedReportOrBackup() {
        runtimeEvents = runtimeEvents.copy(exportedReportOrBackup = true)
    }

    fun onAttemptedLockedEdit() {
        runtimeEvents = runtimeEvents.copy(attemptedLockedEdit = true)
    }

    fun currentStep(onboarding: OnboardingState): TutorialStep? {
        if (onboarding.status != "in_quest") return null
        return TutorialChapters.STEPS.getOrNull(onboarding.questStep.coerceIn(0, 27))
    }
}

@Composable
fun Modifier.questTarget(
    targetId: String,
    coordinator: QuestCoordinator?
): Modifier {
    if (coordinator == null) return this
    DisposableEffect(targetId, coordinator) {
        onDispose {
            coordinator.removeTargetRect(targetId)
        }
    }
    return this.onGloballyPositioned { coords ->
        if (coords.isAttached) {
            coordinator.updateTargetRect(targetId, coords.boundsInRoot())
        }
    }
}

/**
 * 120 FPS QuestBeaconOverlay drawing a pulsing core and two expanding rings directly over
 * the active tutorial step's live `Rect` using Compose `Canvas`.
 */
@Composable
fun QuestBeaconOverlay(
    coordinator: QuestCoordinator,
    activeStep: TutorialStep?,
    modifier: Modifier = Modifier
) {
    if (activeStep == null) return
    val rect = coordinator.targetRects[activeStep.aim.targetId] ?: return
    if (rect.isEmpty) return

    val infinite = rememberInfiniteTransition(label = "questBeacon")
    val pulse1 by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulse1"
    )
    val pulse2 by infinite.animateFloat(
        initialValue = 0.5f,
        targetValue = 1.5f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulse2"
    )

    val center = Offset(rect.center.x, rect.center.y)
    val baseRadius = (maxOf(rect.width, rect.height) * 0.35f).coerceIn(22f, 56f)

    Canvas(modifier = modifier.fillMaxSize()) {
        val gold = Color(0xFFFBBF24)
        val p2 = pulse2 % 1f
        drawCircle(
            color = gold.copy(alpha = (1f - pulse1) * 0.65f),
            radius = baseRadius * (1f + pulse1 * 0.9f),
            center = center,
            style = Stroke(width = 3.dp.toPx())
        )
        drawCircle(
            color = gold.copy(alpha = (1f - p2) * 0.55f),
            radius = baseRadius * (1f + p2 * 0.9f),
            center = center,
            style = Stroke(width = 2.dp.toPx())
        )
        drawCircle(
            color = gold.copy(alpha = 0.85f),
            radius = 7.dp.toPx(),
            center = center
        )
    }
}

@Composable
fun QuestDock(
    onboarding: OnboardingState,
    step: TutorialStep,
    project: Project?,
    accountingResult: AccountingResult?,
    stepDoneResultText: String?,
    onNavigateToAimPage: (String) -> Unit,
    onApplySkipHelpersAndNext: () -> Unit,
    onPrevStep: () -> Unit,
    onExitQuest: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = StayarTheme.colors
    val digitsMode = StayarTheme.digitsMode
    val f = { s: String -> TextNormalizer.formatDisplayDigits(s, digitsMode) }
    val progressFraction = (step.index + 1).toFloat() / 28f

    Surface(
        shape = RoundedCornerShape(18.dp),
        color = colors.bgElev,
        border = BorderStroke(2.dp, colors.accent),
        shadowElevation = 10.dp,
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    BadgePill(f("فصل ${step.chapter} · گام ${step.index + 1} از ۲۸"), colors.accent)
                    Text(
                        text = step.titleFa,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.5.sp,
                        color = colors.text
                    )
                }
                TextButton(onClick = onExitQuest) {
                    Text("خروج از تمرین", fontSize = 12.sp, color = colors.textDim)
                }
            }

            LinearProgressIndicator(
                progress = { progressFraction },
                color = colors.accent,
                trackColor = colors.bgElev2,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp)
            )

            Text(
                text = step.sayFa,
                fontSize = 13.sp,
                color = colors.text,
                modifier = Modifier.padding(vertical = 4.dp)
            )

            if (stepDoneResultText != null) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = colors.success.copy(alpha = 0.14f),
                    border = BorderStroke(1.dp, colors.success),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                ) {
                    Text(
                        text = "✅ $stepDoneResultText",
                        fontSize = 12.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.success,
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (step.index > 0) {
                        OutlinedButton(
                            onClick = onPrevStep,
                            border = BorderStroke(colors.defaultBorderWidth, colors.borderStrong)
                        ) {
                            Text("قبلی", fontSize = 12.5.sp, color = colors.text)
                        }
                    }
                    OutlinedButton(
                        onClick = { onNavigateToAimPage(step.aim.page) },
                        border = BorderStroke(colors.defaultBorderWidth, colors.accent)
                    ) {
                        Text(
                            text = step.aim.hintFa.ifBlank { "رفتن به بخش" },
                            fontSize = 12.5.sp,
                            color = colors.accent,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                Button(
                    onClick = onApplySkipHelpersAndNext,
                    colors = ButtonDefaults.buttonColors(containerColor = colors.accent)
                ) {
                    Text(
                        text = if (stepDoneResultText != null) "گام بعدی ◂" else "رد کردن / بعدی ◂",
                        fontSize = 12.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.onAccent
                    )
                }
            }
        }
    }
}

@Composable
fun PracticeChooserSheet(
    currentOnboarding: OnboardingState,
    onStartChapter: (chapter: Int, stepIndex: Int) -> Unit,
    onResumeCurrent: () -> Unit,
    onDismiss: () -> Unit
) {
    val colors = StayarTheme.colors
    val digitsMode = StayarTheme.digitsMode
    val f = { s: String -> TextNormalizer.formatDisplayDigits(s, digitsMode) }

    TactileSheet(
        titleFa = "کارگاه تمرینی تعاملی (۳ فصل، ۲۸ گام)",
        onDismissRequest = onDismiss
    ) {
        Text(
            text = "یک پروژهٔ تمرینی جداگانه ساخته می‌شود تا بدون نگرانی از خراب‌شدن حساب‌های واقعی، تمام امکانات استایار را به صورت زنده تجربه کنید.",
            fontSize = 13.5.sp,
            color = colors.textDim
        )
        Spacer(modifier = Modifier.height(12.dp))

        if (currentOnboarding.status == "in_quest" && currentOnboarding.questStep in 0..27) {
            Button(
                onClick = {
                    onDismiss()
                    onResumeCurrent()
                },
                colors = ButtonDefaults.buttonColors(containerColor = colors.accent),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
            ) {
                Text(
                    text = f("ادامهٔ تمرین از گام ${currentOnboarding.questStep + 1} (فصل ${currentOnboarding.chapter})"),
                    color = colors.onAccent,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
        }

        val chapterStarts = listOf(1 to 0, 2 to 15, 3 to 22)
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            for ((ch, startIdx) in chapterStarts) {
                val title = TutorialChapters.CHAPTER_TITLES_FA[ch] ?: "فصل $ch"
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = colors.bgElev2,
                    border = BorderStroke(colors.defaultBorderWidth, colors.borderStrong),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            onDismiss()
                            onStartChapter(ch, startIdx)
                        }
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = title,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = colors.text,
                            modifier = Modifier.weight(1f)
                        )
                        Text(
                            text = "شروع ◂",
                            fontWeight = FontWeight.Bold,
                            color = colors.accent,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun GraduationSheet(
    onReturnToMainProjects: () -> Unit,
    onRestartTutorial: () -> Unit,
    onDismiss: () -> Unit
) {
    val colors = StayarTheme.colors
    TactileSheet(
        titleFa = "🎓 فارغ‌التحصیلی کارگاه استایار",
        onDismissRequest = onDismiss
    ) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = colors.success.copy(alpha = 0.14f),
            border = BorderStroke(2.dp, colors.success),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(18.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "تبریک اوستا! هر ۲۸ گام را کامل کردید",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = colors.success
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "اکنون به تمام ابزارهای حضور و غیاب، ضرایب شراکت، هزینه‌های شخصی و مشترک، تسویه مانده‌های منفی، خروجی PDF/A4 و قفل دوره مالی تسلط کامل دارید.",
                    fontSize = 13.5.sp,
                    color = colors.text
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            OutlinedButton(
                onClick = {
                    onDismiss()
                    onRestartTutorial()
                },
                border = BorderStroke(colors.defaultBorderWidth, colors.borderStrong),
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
            ) {
                Text("تکرار تمرین", color = colors.text, fontWeight = FontWeight.SemiBold)
            }
            Button(
                onClick = {
                    onDismiss()
                    onReturnToMainProjects()
                },
                colors = ButtonDefaults.buttonColors(containerColor = colors.accent),
                modifier = Modifier
                    .weight(1.4f)
                    .height(48.dp)
            ) {
                Text("رفتن به پروژه‌های اصلی", color = colors.onAccent, fontWeight = FontWeight.Bold)
            }
        }
    }
}
