package com.workshop.ledger.core.export

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import androidx.core.content.FileProvider
import com.workshop.ledger.domain.engine.JalaliCalendarEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

class FileDeliveryManager(private val context: Context) {

    companion object {
        const val AUTHORITY = "com.workshop.ledger.fileprovider"
    }

    val exportsDir: File
        get() = File(context.cacheDir, "exports").apply { mkdirs() }

    /**
     * Cleans up old temporary export files in cacheDir/exports/ on app launch/stop.
     */
    fun cleanupOldExports() {
        try {
            exportsDir.listFiles()?.forEach { file ->
                if (file.isFile) file.delete()
            }
        } catch (_: Throwable) {
        }
    }

    fun compactTodayJalali(): String {
        return JalaliCalendarEngine.jTodayStr().replace("/", "")
    }

    private fun last4AlphaNum(id: String): String {
        val cleaned = id.filter { it.isLetterOrDigit() }
        return if (cleaned.length >= 4) cleaned.takeLast(4) else cleaned.padStart(4, '0')
    }

    /**
     * Builds canonical file names per Section 11:
     * `stayar-{kind}-{YYYYMMDD}.{ext}`
     */
    fun buildExportFileName(kind: String, ext: String): String {
        val ymd = compactTodayJalali()
        return "stayar-$kind-$ymd.$ext"
    }

    fun buildProjectJsonFileName(projectId: String): String {
        val suffix = last4AlphaNum(projectId)
        return buildExportFileName("project-$suffix", "json")
    }

    fun buildStatementFileName(
        userId: String,
        ext: String,
        pageNumber: Int? = null,
        combinedAll: Boolean = false
    ): String {
        val ymd = compactTodayJalali()
        val suffix = last4AlphaNum(userId)
        val pagePart = when {
            combinedAll -> "-all"
            pageNumber != null -> "-p$pageNumber"
            else -> ""
        }
        return "stayar-statement-$ymd-$suffix$pagePart.$ext"
    }

    suspend fun writeUtf8FileToExportsCache(fileName: String, content: String): File =
        withContext(Dispatchers.IO) {
            val f = File(exportsDir, fileName)
            f.writeText(content, Charsets.UTF_8)
            f
        }

    suspend fun writeBitmapPngToExportsCache(fileName: String, bitmap: Bitmap): File =
        withContext(Dispatchers.IO) {
            val f = File(exportsDir, fileName)
            FileOutputStream(f).use { fos ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos)
                fos.flush()
            }
            f
        }

    fun getShareUri(file: File): Uri {
        return FileProvider.getUriForFile(context, AUTHORITY, file)
    }

    fun shareFile(file: File, mimeType: String, chooserTitleFa: String = "اشتراک‌گذاری فایل") {
        try {
            val uri = getShareUri(file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = mimeType
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val chooser = Intent.createChooser(intent, chooserTitleFa).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(chooser)
        } catch (_: Throwable) {
        }
    }

    fun copyTextToClipboard(labelFa: String, text: String): Boolean {
        return try {
            val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                ?: return false
            cm.setPrimaryClip(ClipData.newPlainText(labelFa, text))
            true
        } catch (_: Throwable) {
            false
        }
    }
}
