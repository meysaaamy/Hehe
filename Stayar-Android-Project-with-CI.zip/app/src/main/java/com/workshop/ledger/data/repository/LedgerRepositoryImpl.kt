package com.workshop.ledger.data.repository

import com.workshop.ledger.data.local.backup.BackupManager
import com.workshop.ledger.data.local.backup.BackupSlotInfo
import com.workshop.ledger.data.local.datastore.AppPreferences
import com.workshop.ledger.data.local.datastore.PreferencesRepository
import com.workshop.ledger.data.local.db.AttendanceEntity
import com.workshop.ledger.data.local.db.EntityMappers.toEntity
import com.workshop.ledger.data.local.db.EntityMappers.toProjectEntity
import com.workshop.ledger.data.local.db.LedgerDao
import com.workshop.ledger.data.local.db.ProjectEntity
import com.workshop.ledger.domain.engine.AccountingEngine
import com.workshop.ledger.domain.engine.DataHealthChecker
import com.workshop.ledger.domain.engine.SampleProjectFactory
import com.workshop.ledger.domain.engine.TextNormalizer
import com.workshop.ledger.domain.model.AccountingResult
import com.workshop.ledger.domain.model.Adjustment
import com.workshop.ledger.domain.model.AppState
import com.workshop.ledger.domain.model.AttendanceValue
import com.workshop.ledger.domain.model.Category
import com.workshop.ledger.domain.model.DomainConstants
import com.workshop.ledger.domain.model.Expense
import com.workshop.ledger.domain.model.Payout
import com.workshop.ledger.domain.model.Project
import com.workshop.ledger.domain.model.ProjectSettings
import com.workshop.ledger.domain.model.Receipt
import com.workshop.ledger.domain.model.Transfer
import com.workshop.ledger.domain.model.User
import com.workshop.ledger.domain.model.UserType
import com.workshop.ledger.domain.model.Wage
import com.workshop.ledger.domain.tutorial.OnboardingState
import com.workshop.ledger.domain.tutorial.PracticeSandboxSeeder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.withContext

sealed interface MutationOutcome {
    data class Success(val messageFa: String = "ذخیره شد") : MutationOutcome
    data object PeriodLocked : MutationOutcome
    data object SaveBlocked : MutationOutcome
    data class ValidationError(val messageFa: String) : MutationOutcome
}

@OptIn(ExperimentalCoroutinesApi::class)
class LedgerRepositoryImpl(
    private val dao: LedgerDao,
    val prefs: PreferencesRepository,
    val backupManager: BackupManager,
    private val appScope: CoroutineScope
) {

    private val _saveBlocked = MutableStateFlow(false)
    val saveBlocked: StateFlow<Boolean> = _saveBlocked.asStateFlow()

    private val _loadError = MutableStateFlow<String?>(null)
    val loadError: StateFlow<String?> = _loadError.asStateFlow()

    private val _lockedAttemptEvents = MutableSharedFlow<Unit>(extraBufferCapacity = 8)
    val lockedAttemptEvents: SharedFlow<Unit> = _lockedAttemptEvents.asSharedFlow()

    val preferencesFlow: StateFlow<AppPreferences> = prefs.preferencesFlow.stateIn(
        scope = appScope,
        started = SharingStarted.Eagerly,
        initialValue = AppPreferences()
    )

    val allProjectsSummaryFlow: StateFlow<List<ProjectEntity>> = dao.observeAllProjectEntities()
        .stateIn(
            scope = appScope,
            started = SharingStarted.Eagerly,
            initialValue = emptyList()
        )

    val activeProjectFlow: StateFlow<Project?> = combine(
        preferencesFlow.map { it.activeProjectId }.distinctUntilChanged(),
        allProjectsSummaryFlow
    ) { activeId, list ->
        when {
            list.any { it.id == activeId } -> activeId
            list.isNotEmpty() -> list.first().id
            else -> ""
        }
    }.distinctUntilChanged().flatMapLatest { projectId ->
        if (projectId.isEmpty()) flowOf(null) else dao.observeProjectSnapshot(projectId)
    }.stateIn(
        scope = appScope,
        started = SharingStarted.Eagerly,
        initialValue = null
    )

    val accountingResultFlow: StateFlow<AccountingResult?> = activeProjectFlow
        .map { project -> project?.let { AccountingEngine.compute(it) } }
        .flowOn(Dispatchers.Default)
        .stateIn(
            scope = appScope,
            started = SharingStarted.Eagerly,
            initialValue = null
        )

    /**
     * Initializes first-launch default project «پروژه اول» if database is empty.
     * Catches corruption/IO errors and sets saveBlocked = true with loadError banner.
     */
    suspend fun initializeFirstLaunchIfNeeded() = withContext(Dispatchers.IO) {
        try {
            val existing = dao.getAllProjectEntities()
            val currentPrefs = prefs.preferencesFlow.first()
            if (existing.isEmpty()) {
                val initialProject = SampleProjectFactory.createEmptyProject(
                    name = "پروژه اول",
                    masterName = "اوستای اصلی"
                )
                dao.insertFullProjectGraph(initialProject)
                prefs.setActiveProjectId(initialProject.id)
                prefs.setOnboarding(OnboardingState(status = "not_started", questStep = 0, chapter = 1))
            } else if (currentPrefs.activeProjectId.isEmpty() || existing.none { it.id == currentPrefs.activeProjectId }) {
                prefs.setActiveProjectId(existing.first().id)
            }
        } catch (t: Throwable) {
            _saveBlocked.value = true
            _loadError.value = t.message ?: "خطای دیسک / پایگاه داده"
        }
    }

    private fun guardWriteAllowed(project: Project? = activeProjectFlow.value): MutationOutcome? {
        if (_saveBlocked.value) return MutationOutcome.SaveBlocked
        if (project?.settings?.locked == true) {
            _lockedAttemptEvents.tryEmit(Unit)
            return MutationOutcome.PeriodLocked
        }
        return null
    }

    suspend fun buildCurrentAppStateSnapshot(): AppState = withContext(Dispatchers.IO) {
        val p = prefs.preferencesFlow.first()
        val allProjects = dao.getAllFullProjects()
        AppState(
            version = 3,
            activeProjectId = p.activeProjectId.ifEmpty { allProjects.firstOrNull()?.id.orEmpty() },
            onboarding = p.onboarding,
            coachDismissed = p.coachDismissed,
            projects = allProjects
        )
    }

    // ========================================================================
    // Granular Attendance Operations
    // ========================================================================

    suspend fun toggleOrSetAttendance(
        date: String,
        userId: String,
        newValue: AttendanceValue?
    ): MutationOutcome = withContext(Dispatchers.IO) {
        val project = activeProjectFlow.value ?: return@withContext MutationOutcome.ValidationError("پروژه فعالی یافت نشد.")
        guardWriteAllowed(project)?.let { return@withContext it }

        val existing = project.attendance[date]?.get(userId)
        return@withContext try {
            if (newValue == null || existing == newValue) {
                dao.deleteAttendance(project.id, date, userId)
                MutationOutcome.Success("وضعیت حضور پاک شد")
            } else {
                dao.upsertAttendance(
                    AttendanceEntity(
                        projectId = project.id,
                        date = date,
                        userId = userId,
                        status = newValue.dbStatus,
                        halfHours = newValue.dbHalfHours
                    )
                )
                MutationOutcome.Success("حضور ثبت شد")
            }
        } catch (t: Throwable) {
            if (t.message?.contains("PERIOD_LOCKED") == true) {
                _lockedAttemptEvents.tryEmit(Unit)
                MutationOutcome.PeriodLocked
            } else {
                MutationOutcome.ValidationError("خطا در ثبت حضور")
            }
        }
    }

    suspend fun markAllPresentForDate(date: String): MutationOutcome = withContext(Dispatchers.IO) {
        val project = activeProjectFlow.value ?: return@withContext MutationOutcome.ValidationError("پروژه فعالی یافت نشد.")
        guardWriteAllowed(project)?.let { return@withContext it }

        val activeUsers = project.liveUsers().filter { it.active }
        val rows = activeUsers.map { u ->
            AttendanceEntity(
                projectId = project.id,
                date = date,
                userId = u.id,
                status = AttendanceValue.Full.dbStatus,
                halfHours = AttendanceValue.Full.dbHalfHours
            )
        }
        dao.upsertAttendances(rows)
        MutationOutcome.Success("حضور کامل برای همه ثبت شد")
    }

    // ========================================================================
    // Granular CRUD Operations
    // ========================================================================

    suspend fun upsertUser(user: User): MutationOutcome = withContext(Dispatchers.IO) {
        val project = activeProjectFlow.value ?: return@withContext MutationOutcome.ValidationError("پروژه فعالی یافت نشد.")
        guardWriteAllowed(project)?.let { return@withContext it }

        val trimmedName = user.name.trim()
        if (trimmedName.isEmpty()) {
            return@withContext MutationOutcome.ValidationError("نام را وارد کنید")
        }
        val normName = TextNormalizer.normFa(trimmedName)
        val duplicate = project.liveUsers().any {
            it.id != user.id && TextNormalizer.normFa(it.name) == normName
        }
        if (duplicate) {
            return@withContext MutationOutcome.ValidationError(
                "کاربر دیگری با همین نام وجود دارد. برای تشخیص، چیزی به نام اضافه کنید (مثلاً «علی ۲» یا «علی جوان»)."
            )
        }

        val existing = project.liveUsers().find { it.id == user.id }
        if (existing != null && existing.type != user.type) {
            if (existing.main) {
                return@withContext MutationOutcome.ValidationError("نوع اوستای اصلی قابل تغییر نیست.")
            }
            val historyCount = countUserHistory(project, user.id)
            if (historyCount > 0) {
                return@withContext MutationOutcome.ValidationError(
                    "نوع این کاربر قابل تغییر نیست چون $historyCount سابقه (حضور، نرخ، پرداخت و ...) دارد و تغییر نوع، حساب‌های قبلی را به هم می‌ریزد. او را غیرفعال کنید و کاربر جدید با نوع درست بسازید."
                )
            }
        }

        val normalizedUser = user.copy(
            name = trimmedName.take(60),
            role = user.role.trim().take(40),
            type = if (existing?.main == true) UserType.MASTER else user.type,
            workFactor = if ((if (existing?.main == true) UserType.MASTER else user.type) == UserType.MASTER) {
                user.workFactor.coerceIn(0.0, 100.0)
            } else {
                1.0
            },
            main = existing?.main ?: false
        )

        dao.upsertUser(normalizedUser.toEntity(project.id))
        MutationOutcome.Success("ذخیره شد")
    }

    fun countUserHistory(project: Project, userId: String): Int {
        val attCount = project.attendance.values.count { it.containsKey(userId) }
        val wageCount = project.wages.count { it.userId == userId }
        val payoutCount = project.payouts.count { it.userId == userId }
        val adjCount = project.adjustments.count { it.userId == userId }
        val transferCount = project.transfers.count { it.fromId == userId || it.toId == userId }
        val expCount = project.expenses.count { it.payerId == userId }
        return attCount + wageCount + payoutCount + adjCount + transferCount + expCount
    }

    suspend fun hardDeleteUser(userId: String): MutationOutcome = withContext(Dispatchers.IO) {
        val project = activeProjectFlow.value ?: return@withContext MutationOutcome.ValidationError("پروژه فعالی یافت نشد.")
        guardWriteAllowed(project)?.let { return@withContext it }

        val target = project.liveUsers().find { it.id == userId }
            ?: return@withContext MutationOutcome.ValidationError("کاربر یافت نشد.")
        if (target.main) {
            return@withContext MutationOutcome.ValidationError("اوستای اصلی قابل حذف نیست.")
        }

        var snapshotFailed = false
        backupManager.executeDestructiveAction(
            reason = "حذف کاربر ${target.name}",
            currentStateProvider = { buildCurrentAppStateSnapshot() },
            onSnapshotFailed = { snapshotFailed = true }
        ) {
            dao.hardDeleteUserCascade(project.id, userId)
        }
        if (snapshotFailed) {
            return@withContext MutationOutcome.ValidationError(
                "نسخهٔ امن ذخیره نشد؛ برای محافظت از داده‌ها این عملیات انجام نشد"
            )
        }
        MutationOutcome.Success("حذف شد؛ یک نسخهٔ امن ذخیره شد")
    }

    suspend fun upsertWage(wage: Wage): MutationOutcome = withContext(Dispatchers.IO) {
        val project = activeProjectFlow.value ?: return@withContext MutationOutcome.ValidationError("پروژه فعالی یافت نشد.")
        guardWriteAllowed(project)?.let { return@withContext it }
        if (wage.userId.isBlank()) return@withContext MutationOutcome.ValidationError("شاگرد / پرسنل را انتخاب کنید")
        if (wage.rate <= 0L) return@withContext MutationOutcome.ValidationError("مبلغ دستمزد روزانه را وارد کنید")
        dao.upsertWage(wage.toEntity(project.id))
        MutationOutcome.Success("ذخیره شد")
    }

    suspend fun deleteWage(wageId: String): MutationOutcome = withContext(Dispatchers.IO) {
        val project = activeProjectFlow.value ?: return@withContext MutationOutcome.ValidationError("پروژه فعالی یافت نشد.")
        guardWriteAllowed(project)?.let { return@withContext it }
        dao.deleteWage(project.id, wageId)
        MutationOutcome.Success("حذف شد")
    }

    suspend fun upsertExpense(expense: Expense): MutationOutcome = withContext(Dispatchers.IO) {
        val project = activeProjectFlow.value ?: return@withContext MutationOutcome.ValidationError("پروژه فعالی یافت نشد.")
        guardWriteAllowed(project)?.let { return@withContext it }
        if (expense.amount <= 0L) return@withContext MutationOutcome.ValidationError("مبلغ هزینه را وارد کنید")
        if (expense.description.isBlank()) return@withContext MutationOutcome.ValidationError("شرح هزینه را وارد کنید")
        dao.upsertExpense(expense.toEntity(project.id))
        MutationOutcome.Success("ذخیره شد")
    }

    suspend fun deleteExpense(expenseId: String): MutationOutcome = withContext(Dispatchers.IO) {
        val project = activeProjectFlow.value ?: return@withContext MutationOutcome.ValidationError("پروژه فعالی یافت نشد.")
        guardWriteAllowed(project)?.let { return@withContext it }
        dao.deleteExpense(project.id, expenseId)
        MutationOutcome.Success("حذف شد")
    }

    suspend fun upsertReceipt(receipt: Receipt): MutationOutcome = withContext(Dispatchers.IO) {
        val project = activeProjectFlow.value ?: return@withContext MutationOutcome.ValidationError("پروژه فعالی یافت نشد.")
        guardWriteAllowed(project)?.let { return@withContext it }
        if (receipt.amount <= 0L) return@withContext MutationOutcome.ValidationError("مبلغ واریزی را وارد کنید")
        if (receipt.dateTo < receipt.dateFrom) {
            return@withContext MutationOutcome.ValidationError("تاریخ شروع نباید بعد از تاریخ پایان باشد.")
        }
        dao.upsertReceipt(receipt.toEntity(project.id))
        MutationOutcome.Success("ذخیره شد")
    }

    suspend fun deleteReceipt(receiptId: String): MutationOutcome = withContext(Dispatchers.IO) {
        val project = activeProjectFlow.value ?: return@withContext MutationOutcome.ValidationError("پروژه فعالی یافت نشد.")
        guardWriteAllowed(project)?.let { return@withContext it }
        dao.deleteReceipt(project.id, receiptId)
        MutationOutcome.Success("حذف شد")
    }

    suspend fun upsertPayout(payout: Payout): MutationOutcome = withContext(Dispatchers.IO) {
        val project = activeProjectFlow.value ?: return@withContext MutationOutcome.ValidationError("پروژه فعالی یافت نشد.")
        guardWriteAllowed(project)?.let { return@withContext it }
        if (payout.userId.isBlank()) return@withContext MutationOutcome.ValidationError("ابتدا یک شاگرد یا پرسنل تعریف کنید")
        if (payout.amount <= 0L) return@withContext MutationOutcome.ValidationError("مبلغ پرداختی را وارد کنید")
        dao.upsertPayout(payout.toEntity(project.id))
        MutationOutcome.Success("ذخیره شد")
    }

    suspend fun deletePayout(payoutId: String): MutationOutcome = withContext(Dispatchers.IO) {
        val project = activeProjectFlow.value ?: return@withContext MutationOutcome.ValidationError("پروژه فعالی یافت نشد.")
        guardWriteAllowed(project)?.let { return@withContext it }
        dao.deletePayout(project.id, payoutId)
        MutationOutcome.Success("حذف شد")
    }

    suspend fun upsertTransfer(transfer: Transfer): MutationOutcome = withContext(Dispatchers.IO) {
        val project = activeProjectFlow.value ?: return@withContext MutationOutcome.ValidationError("پروژه فعالی یافت نشد.")
        guardWriteAllowed(project)?.let { return@withContext it }
        if (transfer.toId.isBlank()) return@withContext MutationOutcome.ValidationError("دریافت‌کننده را انتخاب کنید")
        if (transfer.kind == "peer" && (transfer.fromId.isNullOrBlank() || transfer.fromId == transfer.toId)) {
            return@withContext MutationOutcome.ValidationError("پرداخت‌کننده و دریافت‌کننده باید دو اوستای متفاوت باشند.")
        }
        if (transfer.amount <= 0L) return@withContext MutationOutcome.ValidationError("مبلغ انتقال را وارد کنید")
        dao.upsertTransfer(transfer.toEntity(project.id))
        MutationOutcome.Success("ذخیره شد")
    }

    suspend fun deleteTransfer(transferId: String): MutationOutcome = withContext(Dispatchers.IO) {
        val project = activeProjectFlow.value ?: return@withContext MutationOutcome.ValidationError("پروژه فعالی یافت نشد.")
        guardWriteAllowed(project)?.let { return@withContext it }
        dao.deleteTransfer(project.id, transferId)
        MutationOutcome.Success("حذف شد")
    }

    suspend fun upsertAdjustment(adjustment: Adjustment): MutationOutcome = withContext(Dispatchers.IO) {
        val project = activeProjectFlow.value ?: return@withContext MutationOutcome.ValidationError("پروژه فعالی یافت نشد.")
        guardWriteAllowed(project)?.let { return@withContext it }
        if (adjustment.userId.isBlank()) return@withContext MutationOutcome.ValidationError("شخص را انتخاب کنید")
        val targetUser = project.liveUsers().find { it.id == adjustment.userId }
        if (adjustment.kind == "settle" && targetUser?.type != UserType.MASTER) {
            return@withContext MutationOutcome.ValidationError("تسویه نقدی فقط برای اوستا ثبت می‌شود.")
        }
        if (adjustment.amount <= 0L) return@withContext MutationOutcome.ValidationError("مبلغ را وارد کنید")
        dao.upsertAdjustment(adjustment.toEntity(project.id))
        MutationOutcome.Success("ذخیره شد")
    }

    suspend fun deleteAdjustment(adjustmentId: String): MutationOutcome = withContext(Dispatchers.IO) {
        val project = activeProjectFlow.value ?: return@withContext MutationOutcome.ValidationError("پروژه فعالی یافت نشد.")
        guardWriteAllowed(project)?.let { return@withContext it }
        dao.deleteAdjustment(project.id, adjustmentId)
        MutationOutcome.Success("حذف شد")
    }

    suspend fun upsertCategory(category: Category): MutationOutcome = withContext(Dispatchers.IO) {
        val project = activeProjectFlow.value ?: return@withContext MutationOutcome.ValidationError("پروژه فعالی یافت نشد.")
        guardWriteAllowed(project)?.let { return@withContext it }
        val trimmed = category.name.trim().take(40)
        if (trimmed.isEmpty()) return@withContext MutationOutcome.ValidationError("نام دسته را وارد کنید")
        dao.upsertCategory(category.copy(name = trimmed).toEntity(project.id))
        MutationOutcome.Success("ذخیره شد")
    }

    suspend fun deleteCategory(categoryId: String): MutationOutcome = withContext(Dispatchers.IO) {
        val project = activeProjectFlow.value ?: return@withContext MutationOutcome.ValidationError("پروژه فعالی یافت نشد.")
        guardWriteAllowed(project)?.let { return@withContext it }
        dao.deleteCategory(project.id, categoryId)
        MutationOutcome.Success("دسته حذف شد")
    }

    // ========================================================================
    // Project & Settings Management
    // ========================================================================

    suspend fun updateProjectSettings(transform: (ProjectSettings) -> ProjectSettings): MutationOutcome =
        withContext(Dispatchers.IO) {
            if (_saveBlocked.value) return@withContext MutationOutcome.SaveBlocked
            val project = activeProjectFlow.value ?: return@withContext MutationOutcome.ValidationError("پروژه فعالی یافت نشد.")
            val newSettings = transform(project.settings)
            if (project.settings.locked && newSettings.locked) {
                // Only period lock toggle or report range change is permitted while locked
                val onlyRangeChanged = project.settings.copy(
                    rangeFrom = newSettings.rangeFrom,
                    rangeTo = newSettings.rangeTo
                ) == newSettings
                if (!onlyRangeChanged) {
                    _lockedAttemptEvents.tryEmit(Unit)
                    return@withContext MutationOutcome.PeriodLocked
                }
            }
            val updated = project.copy(settings = newSettings)
            dao.upsertProject(updated.toProjectEntity())
            MutationOutcome.Success("ذخیره شد")
        }

    suspend fun setPeriodLocked(locked: Boolean): MutationOutcome = withContext(Dispatchers.IO) {
        if (_saveBlocked.value) return@withContext MutationOutcome.SaveBlocked
        val project = activeProjectFlow.value ?: return@withContext MutationOutcome.ValidationError("پروژه فعالی یافت نشد.")
        val updated = project.copy(settings = project.settings.copy(locked = locked))
        dao.upsertProject(updated.toProjectEntity())
        MutationOutcome.Success(if (locked) "دوره مالی قفل شد" else "قفل باز شد")
    }

    suspend fun renameActiveProject(newName: String): MutationOutcome = withContext(Dispatchers.IO) {
        val project = activeProjectFlow.value ?: return@withContext MutationOutcome.ValidationError("پروژه فعالی یافت نشد.")
        guardWriteAllowed(project)?.let { return@withContext it }
        val trimmed = newName.trim().take(80)
        if (trimmed.isEmpty()) return@withContext MutationOutcome.ValidationError("نام پروژه را وارد کنید")
        dao.upsertProject(project.copy(name = trimmed).toProjectEntity())
        MutationOutcome.Success("نام تغییر کرد")
    }

    suspend fun createNewProject(name: String): MutationOutcome = withContext(Dispatchers.IO) {
        if (_saveBlocked.value) return@withContext MutationOutcome.SaveBlocked
        val existing = dao.getAllProjectEntities()
        if (existing.size >= DomainConstants.MAX_PROJECTS) {
            return@withContext MutationOutcome.ValidationError("حداکثر ۱۰۰ پروژه مجاز است")
        }
        val newProj = SampleProjectFactory.createEmptyProject(
            name = name.trim().take(80).ifEmpty { "پروژه جدید" }
        )
        dao.insertFullProjectGraph(newProj)
        prefs.setActiveProjectId(newProj.id)
        MutationOutcome.Success("پروژه «${newProj.name}» باز شد")
    }

    suspend fun createSampleProject(): MutationOutcome = withContext(Dispatchers.IO) {
        if (_saveBlocked.value) return@withContext MutationOutcome.SaveBlocked
        val existing = dao.getAllProjectEntities()
        if (existing.size >= DomainConstants.MAX_PROJECTS) {
            return@withContext MutationOutcome.ValidationError("حداکثر ۱۰۰ پروژه مجاز است")
        }
        val sample = SampleProjectFactory.createSampleProject()
        dao.insertFullProjectGraph(sample)
        prefs.setActiveProjectId(sample.id)
        MutationOutcome.Success("پروژه «${sample.name}» باز شد")
    }

    suspend fun cloneProjectStructure(sourceProjectId: String): MutationOutcome = withContext(Dispatchers.IO) {
        if (_saveBlocked.value) return@withContext MutationOutcome.SaveBlocked
        val existing = dao.getAllProjectEntities()
        if (existing.size >= DomainConstants.MAX_PROJECTS) {
            return@withContext MutationOutcome.ValidationError("حداکثر ۱۰۰ پروژه مجاز است")
        }
        val source = dao.getFullProjectSnapshot(sourceProjectId)
            ?: return@withContext MutationOutcome.ValidationError("پروژه مبدأ یافت نشد")

        val now = System.currentTimeMillis()
        val newProjectId = "proj_${DomainConstants.uid()}"
        val userIdMap = HashMap<String, String>()
        val clonedUsers = source.liveUsers().mapIndexed { idx, u ->
            val newUid = "u_${idx + 1}_${DomainConstants.uid()}"
            userIdMap[u.id] = newUid
            u.copy(id = newUid, createdAt = now + idx)
        }
        val clonedWages = source.wages.mapNotNull { w ->
            val newUid = userIdMap[w.userId] ?: return@mapNotNull null
            w.copy(id = "w_${DomainConstants.uid()}", userId = newUid)
        }
        val clonedCategories = source.categories.mapIndexed { idx, c ->
            c.copy(id = "cat_${idx + 1}_${DomainConstants.uid()}")
        }
        val cloned = Project(
            id = newProjectId,
            name = "${source.name} (تکثیر)".take(80),
            createdAt = now,
            settings = source.settings.copy(
                rangeFrom = "",
                rangeTo = "",
                locked = false,
                calcVersion = 2
            ),
            users = clonedUsers,
            wages = clonedWages,
            categories = clonedCategories
        )
        dao.insertFullProjectGraph(cloned)
        prefs.setActiveProjectId(cloned.id)
        MutationOutcome.Success("ساختار پروژه تکثیر شد؛ داده‌های مالی صفر است")
    }

    suspend fun deleteProject(projectId: String): MutationOutcome = withContext(Dispatchers.IO) {
        if (_saveBlocked.value) return@withContext MutationOutcome.SaveBlocked
        val all = dao.getAllProjectEntities()
        if (all.size <= 1) {
            return@withContext MutationOutcome.ValidationError("آخرین پروژه قابل حذف نیست")
        }
        val target = all.find { it.id == projectId }
            ?: return@withContext MutationOutcome.ValidationError("پروژه یافت نشد")

        var snapshotFailed = false
        backupManager.executeDestructiveAction(
            reason = "حذف پروژه ${target.name}",
            currentStateProvider = { buildCurrentAppStateSnapshot() },
            onSnapshotFailed = { snapshotFailed = true }
        ) {
            dao.deleteProjectById(projectId)
            val remaining = dao.getAllProjectEntities()
            if (remaining.isNotEmpty()) {
                prefs.setActiveProjectId(remaining.first().id)
            }
        }
        if (snapshotFailed) {
            return@withContext MutationOutcome.ValidationError(
                "نسخهٔ امن ذخیره نشد؛ برای محافظت از داده‌ها این عملیات انجام نشد"
            )
        }
        MutationOutcome.Success("پروژه حذف شد")
    }

    suspend fun clearActiveProjectFinancialData(): MutationOutcome = withContext(Dispatchers.IO) {
        val project = activeProjectFlow.value ?: return@withContext MutationOutcome.ValidationError("پروژه فعالی یافت نشد.")
        guardWriteAllowed(project)?.let { return@withContext it }

        var snapshotFailed = false
        backupManager.executeDestructiveAction(
            reason = "پاک‌کردن داده‌های مالی پروژه ${project.name}",
            currentStateProvider = { buildCurrentAppStateSnapshot() },
            onSnapshotFailed = { snapshotFailed = true }
        ) {
            dao.clearProjectFinancialData(project.id)
        }
        if (snapshotFailed) {
            return@withContext MutationOutcome.ValidationError(
                "نسخهٔ امن ذخیره نشد؛ برای محافظت از داده‌ها این عملیات انجام نشد"
            )
        }
        MutationOutcome.Success("داده‌های مالی پروژه پاک شد")
    }

    suspend fun cleanOrphansInActiveProject(): MutationOutcome = withContext(Dispatchers.IO) {
        val project = activeProjectFlow.value ?: return@withContext MutationOutcome.ValidationError("پروژه فعالی یافت نشد.")
        guardWriteAllowed(project)?.let { return@withContext it }

        var snapshotFailed = false
        backupManager.executeDestructiveAction(
            reason = "پاکسازی رکوردهای یتیم ${project.name}",
            currentStateProvider = { buildCurrentAppStateSnapshot() },
            onSnapshotFailed = { snapshotFailed = true }
        ) {
            val cleaned = DataHealthChecker.cleanOrphans(project)
            dao.deleteProjectById(project.id)
            dao.insertFullProjectGraph(cleaned)
        }
        if (snapshotFailed) {
            return@withContext MutationOutcome.ValidationError(
                "نسخهٔ امن ذخیره نشد؛ برای محافظت از داده‌ها این عملیات انجام نشد"
            )
        }
        MutationOutcome.Success("رکوردهای یتیم پاک شد")
    }

    // ========================================================================
    // Backup Restore & Import Operations
    // ========================================================================

    suspend fun replaceFullDatabaseState(newState: AppState, reason: String): MutationOutcome =
        withContext(Dispatchers.IO) {
            if (_saveBlocked.value) return@withContext MutationOutcome.SaveBlocked
            var snapshotFailed = false
            backupManager.executeDestructiveAction(
                reason = reason,
                currentStateProvider = { buildCurrentAppStateSnapshot() },
                onSnapshotFailed = { snapshotFailed = true }
            ) {
                dao.deleteAllProjects()
                for (p in newState.projects) {
                    dao.insertFullProjectGraph(p)
                }
                val activeId = if (newState.projects.any { it.id == newState.activeProjectId }) {
                    newState.activeProjectId
                } else {
                    newState.projects.first().id
                }
                prefs.setActiveProjectId(activeId)
                prefs.setCoachDismissed(newState.coachDismissed)
                prefs.setOnboarding(newState.onboarding)
            }
            if (snapshotFailed) {
                return@withContext MutationOutcome.ValidationError(
                    "نسخهٔ امن ذخیره نشد؛ برای محافظت از داده‌ها این عملیات انجام نشد"
                )
            }
            MutationOutcome.Success("پشتیبان بازیابی شد")
        }

    suspend fun appendImportedProject(imported: Project): MutationOutcome =
        withContext(Dispatchers.IO) {
            if (_saveBlocked.value) return@withContext MutationOutcome.SaveBlocked
            val existing = dao.getAllProjectEntities()
            if (existing.size >= DomainConstants.MAX_PROJECTS) {
                return@withContext MutationOutcome.ValidationError("حداکثر ۱۰۰ پروژه مجاز است")
            }
            val newId = "proj_${DomainConstants.uid()}"
            val newProject = imported.copy(
                id = newId,
                name = "${imported.name} (وارد شده)".take(80),
                createdAt = System.currentTimeMillis(),
                settings = imported.settings.copy(locked = false)
            )
            dao.insertFullProjectGraph(newProject)
            prefs.setActiveProjectId(newId)
            MutationOutcome.Success("پروژه اضافه شد")
        }

    // ========================================================================
    // Interactive Tutorial Sandbox Seeding
    // ========================================================================

    suspend fun startOrResumePracticeTutorial(chapter: Int = 1, stepIndex: Int = 0): String =
        withContext(Dispatchers.IO) {
            val currentPrefs = prefs.preferencesFlow.first()
            val existingSandboxId = currentPrefs.onboarding.sandboxProjectId
            val existingSandbox = existingSandboxId?.let { dao.getFullProjectSnapshot(it) }

            val sandboxProject = if (existingSandbox != null) {
                existingSandbox
            } else {
                val seeded = PracticeSandboxSeeder.seed()
                dao.insertFullProjectGraph(seeded)
                seeded
            }
            prefs.setActiveProjectId(sandboxProject.id)
            prefs.setOnboarding(
                OnboardingState(
                    status = "in_quest",
                    chapter = chapter.coerceIn(1, 3),
                    questStep = stepIndex.coerceIn(0, 27),
                    sandboxProjectId = sandboxProject.id
                )
            )
            sandboxProject.id
        }

    suspend fun applyTutorialHelperTransform(transform: (Project) -> Project) =
        withContext(Dispatchers.IO) {
            val current = activeProjectFlow.value ?: return@withContext
            val updated = transform(current)
            if (updated != current) {
                dao.insertFullProjectGraph(updated)
            }
        }
}
