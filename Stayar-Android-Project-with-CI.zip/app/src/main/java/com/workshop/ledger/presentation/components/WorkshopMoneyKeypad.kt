package com.workshop.ledger.presentation.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.workshop.ledger.domain.engine.PersianMoneyWords
import com.workshop.ledger.domain.engine.TextNormalizer
import com.workshop.ledger.presentation.theme.JetBrainsMonoFontFamily
import com.workshop.ledger.presentation.theme.MoneyText
import com.workshop.ledger.presentation.theme.StayarTheme
import kotlinx.coroutines.delay

/**
 * Custom Workshop Money Field + Native WorkshopMoneyKeypad:
 * - Keys 0..9, Backspace (⌫), Clear (C)
 * - Golden Shortcut Keys: `۰۰۰` (Thousand) and `۰۰۰٬۰۰۰` (Million)
 * - Inline Calculator (`+` and `−`) with live expression chip
 * - Live Persian money-in-words (`LiveRegionMode.Polite`)
 * - 4.5s transient hints for clamped (> 999B) or decimal input
 */
@Composable
fun WorkshopMoneyFieldWithKeypad(
    labelFa: String,
    amountTomans: Long,
    onAmountChange: (Long) -> Unit,
    onTick: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val colors = StayarTheme.colors
    val digitsMode = StayarTheme.digitsMode
    var keypadOpen by remember { mutableStateOf(false) }
    var rawExpr by remember(amountTomans) {
        mutableStateOf(if (amountTomans > 0L) amountTomans.toString() else "")
    }
    var transientHint by remember { mutableStateOf<String?>(null) }

    val evalResult = remember(rawExpr) {
        PersianMoneyWords.evaluateInlineCalculator(rawExpr)
    }

    LaunchedEffect(evalResult.clamped, evalResult.dec) {
        if (evalResult.clamped) {
            transientHint = "حداکثر مبلغ ۹۹۹ میلیارد تومان است"
            delay(4500L)
            transientHint = null
        } else if (evalResult.dec) {
            transientHint = "اعشار حذف شد؛ مبلغ را به تومانِ کامل وارد کنید"
            delay(4500L)
            transientHint = null
        }
    }

    fun applyExpr(newExpr: String) {
        onTick()
        rawExpr = newExpr
        val res = PersianMoneyWords.evaluateInlineCalculator(newExpr)
        onAmountChange(res.v)
    }

    val hasInlineOp = rawExpr.contains('+') || rawExpr.contains('-') || rawExpr.contains('−')
    val wordsFa = remember(evalResult.v) {
        PersianMoneyWords.numToFaWord(evalResult.v, "تومان")
    }

    Column(modifier = modifier.fillMaxWidth()) {
        Text(
            text = labelFa,
            fontSize = 13.5.sp,
            fontWeight = FontWeight.SemiBold,
            color = colors.textDim
        )
        Spacer(modifier = Modifier.height(4.dp))

        if (hasInlineOp) {
            Surface(
                color = colors.bgElev2,
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, colors.accent),
                modifier = Modifier.padding(bottom = 4.dp)
            ) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    Text(
                        text = TextNormalizer.formatDisplayDigits(rawExpr, digitsMode),
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = 13.sp,
                        color = colors.accent,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }
        }

        Surface(
            shape = RoundedCornerShape(12.dp),
            color = colors.bgElev2,
            border = BorderStroke(
                width = if (keypadOpen) 2.dp else colors.defaultBorderWidth,
                color = if (keypadOpen) colors.accent else colors.borderStrong
            ),
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 52.dp)
                .clickable {
                    onTick()
                    keypadOpen = !keypadOpen
                }
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                MoneyText(
                    amount = evalResult.v,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.text
                )
                Text(
                    text = if (keypadOpen) "بستن کیبورد ▲" else "تومان ⌨",
                    fontSize = 12.5.sp,
                    color = colors.accent,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = wordsFa,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            color = colors.accent,
            modifier = Modifier.semantics { liveRegion = LiveRegionMode.Polite }
        )

        if (transientHint != null) {
            Text(
                text = transientHint!!,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = colors.warn,
                modifier = Modifier.padding(top = 2.dp)
            )
        }

        if (keypadOpen) {
            Spacer(modifier = Modifier.height(8.dp))
            WorkshopMoneyKeypad(
                onDigit = { d -> applyExpr(rawExpr + d) },
                onTripleZero = { applyExpr(if (rawExpr.isEmpty()) "0" else "${rawExpr}000") },
                onSixZeros = { applyExpr(if (rawExpr.isEmpty()) "0" else "${rawExpr}000000") },
                onPlus = {
                    if (rawExpr.isNotEmpty() && rawExpr.last().isDigit()) {
                        applyExpr("$rawExpr+")
                    }
                },
                onMinus = {
                    if (rawExpr.isNotEmpty() && rawExpr.last().isDigit()) {
                        applyExpr("$rawExpr-")
                    }
                },
                onBackspace = {
                    if (rawExpr.isNotEmpty()) {
                        applyExpr(rawExpr.dropLast(1))
                    }
                },
                onClear = { applyExpr("") },
                onDone = {
                    rawExpr = if (evalResult.v > 0L) evalResult.v.toString() else ""
                    keypadOpen = false
                }
            )
        }
    }
}

@Composable
fun WorkshopMoneyKeypad(
    onDigit: (String) -> Unit,
    onTripleZero: () -> Unit,
    onSixZeros: () -> Unit,
    onPlus: () -> Unit,
    onMinus: () -> Unit,
    onBackspace: () -> Unit,
    onClear: () -> Unit,
    onDone: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = StayarTheme.colors
    val digitsMode = StayarTheme.digitsMode
    val f = { s: String -> TextNormalizer.formatDisplayDigits(s, digitsMode) }

    Surface(
        shape = RoundedCornerShape(16.dp),
        color = colors.bgElev,
        border = BorderStroke(colors.defaultBorderWidth, colors.borderStrong),
        modifier = modifier.fillMaxWidth()
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Column(
                modifier = Modifier.padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Golden Shortcut Row: 000, 000,000, +, -
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    KeypadKey(
                        label = f("۰۰۰"),
                        subLabel = "هزار",
                        bgColor = colors.warn.copy(alpha = 0.18f),
                        textColor = colors.text,
                        onClick = onTripleZero,
                        modifier = Modifier.weight(1.3f)
                    )
                    KeypadKey(
                        label = f("۰۰۰٬۰۰۰"),
                        subLabel = "میلیون",
                        bgColor = colors.warn.copy(alpha = 0.26f),
                        textColor = colors.text,
                        onClick = onSixZeros,
                        modifier = Modifier.weight(1.5f)
                    )
                    KeypadKey(
                        label = "+",
                        bgColor = colors.bgElev2,
                        textColor = colors.accent,
                        onClick = onPlus,
                        modifier = Modifier.weight(0.9f)
                    )
                    KeypadKey(
                        label = "−",
                        bgColor = colors.bgElev2,
                        textColor = colors.danger,
                        onClick = onMinus,
                        modifier = Modifier.weight(0.9f)
                    )
                }

                // Digits 7, 8, 9, ⌫
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    KeypadKey(f("7"), onClick = { onDigit("7") }, modifier = Modifier.weight(1f))
                    KeypadKey(f("8"), onClick = { onDigit("8") }, modifier = Modifier.weight(1f))
                    KeypadKey(f("9"), onClick = { onDigit("9") }, modifier = Modifier.weight(1f))
                    KeypadKey(
                        label = "⌫",
                        bgColor = colors.bgElev2,
                        textColor = colors.danger,
                        onClick = onBackspace,
                        modifier = Modifier.weight(1f)
                    )
                }

                // Digits 4, 5, 6, C
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    KeypadKey(f("4"), onClick = { onDigit("4") }, modifier = Modifier.weight(1f))
                    KeypadKey(f("5"), onClick = { onDigit("5") }, modifier = Modifier.weight(1f))
                    KeypadKey(f("6"), onClick = { onDigit("6") }, modifier = Modifier.weight(1f))
                    KeypadKey(
                        label = "C",
                        subLabel = "پاک",
                        bgColor = colors.bgElev2,
                        textColor = colors.danger,
                        onClick = onClear,
                        modifier = Modifier.weight(1f)
                    )
                }

                // Digits 1, 2, 3, 0, تایید
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    KeypadKey(f("1"), onClick = { onDigit("1") }, modifier = Modifier.weight(1f))
                    KeypadKey(f("2"), onClick = { onDigit("2") }, modifier = Modifier.weight(1f))
                    KeypadKey(f("3"), onClick = { onDigit("3") }, modifier = Modifier.weight(1f))
                    KeypadKey(f("0"), onClick = { onDigit("0") }, modifier = Modifier.weight(1f))
                }

                Button(
                    onClick = onDone,
                    colors = ButtonDefaults.buttonColors(containerColor = colors.accent),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                ) {
                    Text("تأیید مبلغ", color = colors.onAccent, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun KeypadKey(
    label: String,
    modifier: Modifier = Modifier,
    subLabel: String? = null,
    bgColor: androidx.compose.ui.graphics.Color = StayarTheme.colors.bgElev2,
    textColor: androidx.compose.ui.graphics.Color = StayarTheme.colors.text,
    onClick: () -> Unit
) {
    val colors = StayarTheme.colors
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = bgColor,
        border = BorderStroke(colors.defaultBorderWidth, colors.borderStrong),
        modifier = modifier
            .height(52.dp)
            .clickable(onClick = onClick)
    ) {
        Column(
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = label,
                fontFamily = JetBrainsMonoFontFamily,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = textColor
            )
            if (subLabel != null) {
                Text(
                    text = subLabel,
                    fontSize = 10.sp,
                    color = colors.textDim
                )
            }
        }
    }
}
