package com.workshop.ledger.domain.engine

import com.workshop.ledger.domain.model.AccountingResult
import com.workshop.ledger.domain.model.AttendanceValue
import com.workshop.ledger.domain.model.MasterResult
import com.workshop.ledger.domain.model.PersonAccumulator
import com.workshop.ledger.domain.model.Project
import com.workshop.ledger.domain.model.Receipt
import com.workshop.ledger.domain.model.ReportRange
import com.workshop.ledger.domain.model.StaffResult
import com.workshop.ledger.domain.model.UserType
import com.workshop.ledger.domain.model.Wage
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToLong

object AccountingEngine {

    /**
     * Legacy JavaScript Math.round(x) = floor(x + 0.5)
     */
    fun jsRound(x: Double): Long = floor(x + 0.5).toLong()

    /**
     * Exact rational half-away-from-zero rounding for calcVersion = 2:
     * roundHalfAwayFromZero(num, den) = if (num >= 0) (num + den / 2) / den else -((-num + den / 2) / den)
     */
    fun roundHalfAwayFromZero(num: Long, den: Long): Long {
        require(den > 0L) { "Denominator must be positive" }
        return if (num >= 0L) {
            (num + den / 2L) / den
        } else {
            -((-num + den / 2L) / den)
        }
    }

    fun sanitizeOvertimeFactor(ot: Double): Double {
        return if (ot.isFinite() && ot >= 1.0) ot else 1.0
    }

    fun sanitizeAbsentPenalty(pen: Double): Double {
        return if (pen.isFinite() && pen in 0.0..3.0) pen else 0.5
    }

    /**
     * Primitive attFraction(value, overtimeFactor) -> Double?
     * Returns 0.0 for Absent (compute() and attFr() override Absent with -absentPenalty).
     */
    fun attFraction(value: AttendanceValue?, overtimeFactor: Double = 1.0): Double? {
        if (value == null) return null
        val ot = sanitizeOvertimeFactor(overtimeFactor)
        return when (value) {
            AttendanceValue.Full -> 1.0
            AttendanceValue.Half -> 0.5
            AttendanceValue.Absent -> 0.0
            is AttendanceValue.Hourly -> {
                val h = value.hours
                if (!h.isFinite() || h < 0.0 || h > 24.0) {
                    null
                } else if (h <= 8.0) {
                    h / 8.0
                } else {
                    (8.0 + (h - 8.0) * ot) / 8.0
                }
            }
        }
    }

    /**
     * Signed attendance fraction applying -absentPenalty when value is Absent.
     */
    fun attFr(value: AttendanceValue?, project: Project): Double? {
        if (value == null) return null
        val ot = sanitizeOvertimeFactor(project.settings.overtimeFactor)
        val pen = sanitizeAbsentPenalty(project.settings.absentPenalty)
        return if (value == AttendanceValue.Absent) {
            if (pen == 0.0) 0.0 else -pen
        } else {
            attFraction(value, ot)
        }
    }

    /**
     * Exact rational numerator over denominator 1600L for calcVersion = 2.
     */
    fun attRationalNumerator1600(
        value: AttendanceValue,
        otScaled: Long,
        penScaled: Long
    ): Long? {
        return when (value) {
            AttendanceValue.Full -> 1600L
            AttendanceValue.Half -> 800L
            AttendanceValue.Absent -> -16L * penScaled
            is AttendanceValue.Hourly -> {
                val h = value.hours
                if (!h.isFinite() || h < 0.0 || h > 24.0) return null
                val halfHours = (h * 2.0).roundToLong()
                if (halfHours !in 0L..48L) return null
                if (halfHours <= 16L) {
                    halfHours * 100L
                } else {
                    1600L + (halfHours - 16L) * otScaled
                }
            }
        }
    }

    fun wageRateFor(wages: List<Wage>, userId: String, date: String): Long {
        val userWages = wages.filter { it.userId == userId }.sortedBy { it.effectiveDate }
        if (userWages.isEmpty()) return 0L
        val best = userWages.lastOrNull { it.effectiveDate <= date }
        return (best ?: userWages.first()).rate
    }

    fun wageRateFor(project: Project, userId: String, date: String): Long {
        return wageRateFor(project.wages, userId, date)
    }

    /**
     * Largest-remainder allocation method.
     * Exact remainder ties are broken deterministically by lower index first (index ASC).
     */
    fun allocate(total: Long, weights: List<Double>): LongArray {
        val n = weights.size
        if (n == 0) return LongArray(0)
        val sum = weights.sum()
        if (!sum.isFinite() || sum <= 0.0 || total == 0L) {
            return LongArray(n) { 0L }
        }
        val sign = if (total < 0L) -1L else 1L
        val absT = abs(total)
        val raw = DoubleArray(n) { i ->
            val w = max(0.0, weights[i])
            (absT.toDouble() * w) / sum
        }
        val floored = LongArray(n) { i -> floor(raw[i]).toLong() }
        val rem = (absT - floored.sum()).toInt().coerceIn(0, n)

        val indices = (0 until n).sortedWith { a, b ->
            val fracA = raw[a] - floored[a].toDouble()
            val fracB = raw[b] - floored[b].toDouble()
            val cmp = fracB.compareTo(fracA)
            if (cmp != 0) cmp else a.compareTo(b)
        }
        for (k in 0 until rem) {
            floored[indices[k]] += 1L
        }
        return LongArray(n) { i -> floored[i] * sign }
    }

    /**
     * Pro-rata share of a client payment inside the report range.
     */
    fun receiptShare(
        receipt: Receipt,
        range: ReportRange,
        calcVersion: Int = 2
    ): Long {
        val amt = receipt.amount
        if (amt <= 0L) return 0L
        if (range.from.isNotEmpty() && receipt.dateTo < range.from) return 0L
        if (range.to.isNotEmpty() && receipt.dateFrom > range.to) return 0L

        val t0 = JalaliCalendarEngine.jToJdn(receipt.dateFrom)
        val t1 = JalaliCalendarEngine.jToJdn(receipt.dateTo)
        if (t0 == null || t1 == null || t1 < t0) return amt

        val lo = if (range.from.isNotEmpty()) {
            JalaliCalendarEngine.jToJdn(range.from) ?: return amt
        } else {
            null
        }
        val hi = if (range.to.isNotEmpty()) {
            JalaliCalendarEngine.jToJdn(range.to) ?: return amt
        } else {
            null
        }

        val spanDays = (t1 - t0) + 1L
        val a = if (lo != null) max(t0, lo) else t0
        val b = if (hi != null) min(t1, hi) else t1
        if (b < a) return 0L

        val k0 = a - t0
        val k1 = (b - t0) + 1L
        if (k0 == 0L && k1 == spanDays) return amt

        return if (calcVersion >= 2) {
            roundHalfAwayFromZero(amt * k1, spanDays) - roundHalfAwayFromZero(amt * k0, spanDays)
        } else {
            jsRound(amt.toDouble() * k1.toDouble() / spanDays.toDouble()) -
                jsRound(amt.toDouble() * k0.toDouble() / spanDays.toDouble())
        }
    }

    fun dailyStaffWage(
        value: AttendanceValue,
        rate: Long,
        ot: Double,
        pen: Double,
        calcVersion: Int
    ): Long {
        if (rate == 0L) return 0L
        if (calcVersion >= 2) {
            val otScaled = (ot * 100.0).roundToLong()
            val penScaled = (pen * 100.0).roundToLong()
            val num = attRationalNumerator1600(value, otScaled, penScaled) ?: return 0L
            return roundHalfAwayFromZero(num * rate, 1600L)
        } else {
            val f = if (value == AttendanceValue.Absent) {
                if (pen == 0.0) 0.0 else -pen
            } else {
                attFraction(value, ot) ?: return 0L
            }
            return jsRound(f * rate.toDouble())
        }
    }

    fun compute(
        project: Project,
        explicitRange: ReportRange? = null
    ): AccountingResult {
        val range = explicitRange ?: ReportRange(
            from = project.settings.rangeFrom,
            to = project.settings.rangeTo
        )
        val basis = if (project.settings.profitBasis == "commitment") "commitment" else "cash"
        val ot = sanitizeOvertimeFactor(project.settings.overtimeFactor)
        val pen = sanitizeAbsentPenalty(project.settings.absentPenalty)
        val calcVersion = project.settings.calcVersion

        val liveUsers = project.liveUsers()
        val accMap = LinkedHashMap<String, PersonAccumulator>(liveUsers.size)
        for (u in liveUsers) {
            val wf = if (u.type == UserType.MASTER && u.workFactor.isFinite() && u.workFactor >= 0.0) {
                u.workFactor
            } else {
                1.0
            }
            accMap[u.id] = PersonAccumulator(
                id = u.id,
                name = u.name,
                role = u.role,
                type = u.type,
                active = u.active,
                main = u.main,
                workFactor = wf
            )
        }

        val errors = mutableListOf<String>()
        fun pushError(msg: String) {
            if (errors.size < 30) {
                errors.add(msg)
            }
        }

        // Step A: Attendance and gross wages
        val sortedDates = project.attendance.keys.filter { range.inRange(it) }.sorted()
        for (date in sortedDates) {
            val dayMap = project.attendance[date] ?: continue
            for ((userId, v) in dayMap) {
                val acc = accMap[userId] ?: continue
                val f = if (v == AttendanceValue.Absent) {
                    if (pen == 0.0) 0.0 else -pen
                } else {
                    attFraction(v, ot)
                }
                if (f == null) {
                    val over24Suffix = if (v is AttendanceValue.Hourly && v.hours > 24.0) {
                        val hStr = TextNormalizer.fmtDays(v.hours)
                        " ($hStr ساعت؛ حداکثر 24 ساعت در روز)"
                    } else {
                        ""
                    }
                    pushError("${acc.name} — $date: مقدار حضور نامعتبر$over24Suffix")
                    continue
                }

                when (v) {
                    AttendanceValue.Full -> acc.full++
                    AttendanceValue.Half -> acc.half++
                    AttendanceValue.Absent -> acc.absent++
                    is AttendanceValue.Hourly -> {
                        acc.hourly++
                        if (v.hours > 8.0) {
                            acc.overtimeHours += (v.hours - 8.0)
                        }
                    }
                }
                acc.days += f
                if (acc.type != UserType.MASTER) {
                    val rate = wageRateFor(project.wages, userId, date)
                    acc.baseWage += dailyStaffWage(v, rate, ot, pen, calcVersion)
                }
            }
        }

        // Step B: Receipts, expenses, payouts
        var totalReceipts = 0L
        for (r in project.receipts) {
            if (!r.active) continue
            totalReceipts += receiptShare(r, range, calcVersion)
        }

        var sharedExpenses = 0L
        var personalExpTotal = 0L
        for (e in project.expenses) {
            if (!e.active || !range.inRange(e.date)) continue
            val payer = accMap[e.payerId]
            if (payer != null && payer.type == UserType.MASTER) {
                payer.reimburse += e.amount
                personalExpTotal += e.amount
            } else {
                sharedExpenses += e.amount
            }
        }

        var totalCashPayouts = 0L
        for (p in project.payouts) {
            if (!p.active || !range.inRange(p.date)) continue
            val target = accMap[p.userId] ?: continue
            if (target.type != UserType.MASTER) {
                target.paid += p.amount
                totalCashPayouts += p.amount
            } else {
                pushError("پرداختی به اوستا ثبت شده است (${target.name}) و محاسبه نشد")
            }
        }

        // Step C: Transfers and adjustments
        for (t in project.transfers) {
            if (!t.active || !range.inRange(t.date)) continue
            if (t.kind == "advance") {
                val a = accMap[t.toId] ?: (t.fromId?.let { accMap[it] })
                if (a != null && a.type == UserType.MASTER) {
                    a.advance += t.amount
                }
            } else if (t.kind == "peer") {
                val from = t.fromId?.let { accMap[it] }
                val to = accMap[t.toId]
                if (from != null) from.given += t.amount
                if (to != null) to.taken += t.amount
            }
        }

        var masterBonus = 0L
        var masterPenalty = 0L
        var staffAssistance = 0L
        for (adj in project.adjustments) {
            if (!adj.active || !range.inRange(adj.date)) continue
            val a = accMap[adj.userId] ?: continue
            val amt = adj.amount
            when (adj.kind) {
                "bonus" -> {
                    a.bonus += amt
                    if (a.type == UserType.MASTER) masterBonus += amt
                }
                "penalty" -> {
                    a.penalty += amt
                    if (a.type == UserType.MASTER) masterPenalty += amt
                }
                "assistance" -> {
                    a.assistance += amt
                    if (a.type != UserType.MASTER) staffAssistance += amt
                }
                "settle" -> {
                    a.settle += amt
                }
            }
        }

        // Step F: Staff balance
        val staffList = mutableListOf<StaffResult>()
        val apprenticesList = mutableListOf<StaffResult>()
        val othersList = mutableListOf<StaffResult>()
        var totalWages = 0L
        var unpaidWages = 0L

        for (acc in accMap.values) {
            if (acc.type == UserType.MASTER) continue
            val entitled = acc.baseWage + acc.bonus - acc.penalty
            val totalPaid = acc.paid + acc.assistance
            val debt = entitled - totalPaid
            totalWages += entitled
            unpaidWages += max(0L, debt)
            val sr = StaffResult(
                id = acc.id,
                name = acc.name,
                role = acc.role,
                type = acc.type,
                active = acc.active,
                full = acc.full,
                half = acc.half,
                hourly = acc.hourly,
                overtimeHours = acc.overtimeHours,
                absent = acc.absent,
                days = acc.days,
                baseWage = acc.baseWage,
                bonus = acc.bonus,
                penalty = acc.penalty,
                entitled = entitled,
                paid = acc.paid,
                assistance = acc.assistance,
                totalPaid = totalPaid,
                debt = debt
            )
            staffList.add(sr)
            if (acc.type == UserType.APPRENTICE) {
                apprenticesList.add(sr)
            } else {
                othersList.add(sr)
            }
        }

        // Step D: Distributable profit
        val profit = if (basis == "commitment") {
            totalReceipts - sharedExpenses - totalWages - masterBonus + masterPenalty
        } else {
            totalReceipts - sharedExpenses - totalCashPayouts - staffAssistance - masterBonus + masterPenalty
        }

        // Step E: Profit sharing between active masters
        val masterAccumulators = accMap.values.filter { it.type == UserType.MASTER }
        val workFinals = masterAccumulators.map { acc ->
            if (acc.active) max(0.0, acc.days * acc.workFactor) else 0.0
        }
        val totalWorkFinal = workFinals.sum()
        val shares = allocate(profit, workFinals)
        val spe = allocate(personalExpTotal, workFinals)

        val mastersList = mutableListOf<MasterResult>()
        for (i in masterAccumulators.indices) {
            val acc = masterAccumulators[i]
            val wf = workFinals[i]
            val percent = if (totalWorkFinal > 0.0) wf / totalWorkFinal else 0.0
            val share = shares[i]
            val sharedPersonalExp = spe[i]
            val finalBalance = share + acc.reimburse - sharedPersonalExp +
                acc.given - acc.taken - acc.advance - acc.assistance +
                acc.bonus - acc.penalty + acc.settle

            mastersList.add(
                MasterResult(
                    id = acc.id,
                    name = acc.name,
                    role = acc.role,
                    active = acc.active,
                    main = acc.main,
                    full = acc.full,
                    half = acc.half,
                    hourly = acc.hourly,
                    overtimeHours = acc.overtimeHours,
                    absent = acc.absent,
                    days = acc.days,
                    workFactor = acc.workFactor,
                    workFinal = wf,
                    percent = percent,
                    share = share,
                    reimburse = acc.reimburse,
                    sharedPersonalExp = sharedPersonalExp,
                    given = acc.given,
                    taken = acc.taken,
                    advance = acc.advance,
                    assistance = acc.assistance,
                    bonus = acc.bonus,
                    penalty = acc.penalty,
                    settle = acc.settle,
                    finalBalance = finalBalance
                )
            )
        }

        var unallocated = 0L
        if (totalWorkFinal == 0.0) {
            unallocated = profit
            if (profit != 0L || masterAccumulators.isNotEmpty()) {
                pushError("مجموع کارکرد اوستاهای فعال صفر است؛ سود قابل تقسیم توزیع نشد")
            }
        }

        // Step G: Negative masters
        val negativeMasters = mastersList.filter { it.finalBalance < 0L }

        return AccountingResult(
            basis = basis,
            range = range,
            totalReceipts = totalReceipts,
            sharedExpenses = sharedExpenses,
            personalExpTotal = personalExpTotal,
            totalWages = totalWages,
            totalCashPayouts = totalCashPayouts,
            staffAssistance = staffAssistance,
            masterBonus = masterBonus,
            masterPenalty = masterPenalty,
            profit = profit,
            unallocated = unallocated,
            totalWorkFinal = totalWorkFinal,
            unpaidWages = unpaidWages,
            acc = accMap,
            masters = mastersList,
            staff = staffList,
            apprentices = apprenticesList,
            others = othersList,
            negativeMasters = negativeMasters,
            errors = errors
        )
    }
}
