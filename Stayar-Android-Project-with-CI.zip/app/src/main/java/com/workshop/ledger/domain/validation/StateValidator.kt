package com.workshop.ledger.domain.validation

import com.workshop.ledger.domain.engine.JalaliCalendarEngine
import com.workshop.ledger.domain.model.AppState
import com.workshop.ledger.domain.model.AttendanceValue
import com.workshop.ledger.domain.model.DomainConstants
import com.workshop.ledger.domain.model.Project
import com.workshop.ledger.domain.model.UserType

data class ValidationResult(
    val ok: Boolean,
    val errors: List<String> = emptyList()
) {
    val firstError: String? get() = errors.firstOrNull()
}

object StateValidator {

    private val VALID_ONBOARDING_STATUS = setOf("not_started", "in_quest", "completed", "skipped")
    private val VALID_ADJUSTMENT_KINDS = setOf("bonus", "penalty", "assistance", "settle")
    private val VALID_TRANSFER_KINDS = setOf("peer", "advance")

    fun isValidId(id: String?): Boolean {
        if (id.isNullOrEmpty()) return false
        return DomainConstants.ID_REGEX.matches(id)
    }

    fun isValidMoney(amount: Long, allowZero: Boolean = false): Boolean {
        val min = if (allowZero) 0L else 1L
        return amount in min..DomainConstants.MAX_MONEY
    }

    fun validateProject(project: Project, projectNumber: Int = 1): ValidationResult {
        val errors = mutableListOf<String>()
        val pPrefix = "پروژه $projectNumber"

        if (!isValidId(project.id)) {
            errors.add("$pPrefix: شناسه پروژه نامعتبر است.")
        }
        if (project.name.isBlank() || project.name.length > DomainConstants.MAX_NAME_LENGTH) {
            errors.add("$pPrefix: نام پروژه نامعتبر یا بیش از سقف مجاز است.")
        }

        val s = project.settings
        if (s.rangeFrom.isNotEmpty() && !JalaliCalendarEngine.isValidStrictProjectJalaliDate(s.rangeFrom)) {
            errors.add("$pPrefix: تاریخ شروع بازه گزارش نامعتبر است.")
        }
        if (s.rangeTo.isNotEmpty() && !JalaliCalendarEngine.isValidStrictProjectJalaliDate(s.rangeTo)) {
            errors.add("$pPrefix: تاریخ پایان بازه گزارش نامعتبر است.")
        }
        if (!s.overtimeFactor.isFinite() || s.overtimeFactor !in 1.0..5.0) {
            errors.add("$pPrefix: ضریب اضافه‌کار نامعتبر است.")
        }
        if (!s.absentPenalty.isFinite() || s.absentPenalty !in 0.0..3.0) {
            errors.add("$pPrefix: کسر غیبت نامعتبر است.")
        }
        if (s.profitBasis != "cash" && s.profitBasis != "commitment") {
            errors.add("$pPrefix: مبنای سود نامعتبر است.")
        }

        val userIds = HashSet<String>()
        val masterIds = HashSet<String>()
        project.users.forEachIndexed { idx, u ->
            val uPos = "$pPrefix / کاربر ${idx + 1}"
            if (!isValidId(u.id) || !userIds.add(u.id)) {
                errors.add("$uPos: شناسه کاربر تکراری یا نامعتبر است.")
            }
            if (u.name.isBlank() || u.name.length > DomainConstants.MAX_NAME_LENGTH) {
                errors.add("$uPos: نام کاربر نامعتبر است.")
            }
            if (u.role.length > DomainConstants.MAX_NAME_LENGTH) {
                errors.add("$uPos: نقش کاربر بیش از سقف مجاز است.")
            }
            if (!u.workFactor.isFinite() || u.workFactor !in 0.0..100.0) {
                errors.add("$uPos: ضریب کارکرد نامعتبر است.")
            }
            if (u.type == UserType.MASTER) {
                masterIds.add(u.id)
            }
        }

        val categoryIds = HashSet<String>()
        project.categories.forEachIndexed { idx, c ->
            val cPos = "$pPrefix / دسته ${idx + 1}"
            if (!isValidId(c.id) || !categoryIds.add(c.id)) {
                errors.add("$cPos: شناسه دسته تکراری یا نامعتبر است.")
            }
            if (c.name.isBlank() || c.name.length > DomainConstants.MAX_NAME_LENGTH) {
                errors.add("$cPos: نام دسته نامعتبر است.")
            }
        }

        val wageIds = HashSet<String>()
        project.wages.forEachIndexed { idx, w ->
            val wPos = "$pPrefix / دستمزد ${idx + 1}"
            if (!isValidId(w.id) || !wageIds.add(w.id)) {
                errors.add("$wPos: شناسه دستمزد تکراری یا نامعتبر است.")
            }
            if (w.userId !in userIds) {
                errors.add("$wPos: کاربر مرجع دستمزد یافت نشد.")
            }
            if (!isValidMoney(w.rate, allowZero = true)) {
                errors.add("$wPos: مبلغ (rate) نامعتبر، منفی یا بیش از سقف مجاز است.")
            }
            if (!JalaliCalendarEngine.isValidStrictProjectJalaliDate(w.effectiveDate)) {
                errors.add("$wPos: تاریخ اعتبار نامعتبر است.")
            }
        }

        for ((date, dayMap) in project.attendance) {
            if (!JalaliCalendarEngine.isValidStrictProjectJalaliDate(date)) {
                errors.add("$pPrefix / حضور $date: تاریخ حضور نامعتبر است.")
                continue
            }
            for ((uid, v) in dayMap) {
                if (uid !in userIds) {
                    errors.add("$pPrefix / حضور $date: کاربر $uid در لیست کاربران وجود ندارد.")
                }
                if (v is AttendanceValue.Hourly) {
                    if (!v.hours.isFinite() || v.hours < 0.0 || v.hours > DomainConstants.MAX_HOURS.toDouble()) {
                        errors.add("$pPrefix / حضور $date: ساعت حضور نامعتبر یا بیش از ۲۴ ساعت است.")
                    }
                }
            }
        }

        val expenseIds = HashSet<String>()
        project.expenses.forEachIndexed { idx, e ->
            val ePos = "$pPrefix / هزینه ${idx + 1}"
            if (!isValidId(e.id) || !expenseIds.add(e.id)) {
                errors.add("$ePos: شناسه هزینه تکراری یا نامعتبر است.")
            }
            if (!JalaliCalendarEngine.isValidStrictProjectJalaliDate(e.date)) {
                errors.add("$ePos: تاریخ هزینه نامعتبر است.")
            }
            if (!isValidMoney(e.amount)) {
                errors.add("$ePos: مبلغ (amount) نامعتبر، منفی یا بیش از سقف مجاز است.")
            }
            if (e.description.length > DomainConstants.MAX_DESCRIPTION_LENGTH) {
                errors.add("$ePos: توضیحات بیش از سقف مجاز است.")
            }
            if (!e.categoryId.isNullOrEmpty() && e.categoryId !in categoryIds) {
                errors.add("$ePos: دسته‌بندی مرجع یافت نشد.")
            }
            if (e.payerId != "shared" && e.payerId !in userIds) {
                errors.add("$ePos: پرداخت‌کننده مرجع یافت نشد.")
            }
        }

        val receiptIds = HashSet<String>()
        project.receipts.forEachIndexed { idx, r ->
            val rPos = "$pPrefix / واریزی ${idx + 1}"
            if (!isValidId(r.id) || !receiptIds.add(r.id)) {
                errors.add("$rPos: شناسه واریزی تکراری یا نامعتبر است.")
            }
            if (!JalaliCalendarEngine.isValidStrictProjectJalaliDate(r.dateFrom) ||
                !JalaliCalendarEngine.isValidStrictProjectJalaliDate(r.dateTo) ||
                r.dateTo < r.dateFrom
            ) {
                errors.add("$rPos: بازه تاریخ واریزی نامعتبر است.")
            }
            if (!isValidMoney(r.amount)) {
                errors.add("$rPos: مبلغ (amount) نامعتبر، منفی یا بیش از سقف مجاز است.")
            }
            if (r.description.length > DomainConstants.MAX_DESCRIPTION_LENGTH) {
                errors.add("$rPos: توضیحات بیش از سقف مجاز است.")
            }
        }

        val payoutIds = HashSet<String>()
        project.payouts.forEachIndexed { idx, p ->
            val pPos = "$pPrefix / پرداختی ${idx + 1}"
            if (!isValidId(p.id) || !payoutIds.add(p.id)) {
                errors.add("$pPos: شناسه پرداختی تکراری یا نامعتبر است.")
            }
            if (!JalaliCalendarEngine.isValidStrictProjectJalaliDate(p.date)) {
                errors.add("$pPos: تاریخ پرداختی نامعتبر است.")
            }
            if (p.userId !in userIds) {
                errors.add("$pPos: دریافت‌کننده در لیست کاربران یافت نشد.")
            }
            if (!isValidMoney(p.amount)) {
                errors.add("$pPos: مبلغ (amount) نامعتبر، منفی یا بیش از سقف مجاز است.")
            }
            if (p.description.length > DomainConstants.MAX_DESCRIPTION_LENGTH) {
                errors.add("$pPos: توضیحات بیش از سقف مجاز است.")
            }
        }

        val transferIds = HashSet<String>()
        project.transfers.forEachIndexed { idx, t ->
            val tPos = "$pPrefix / انتقال ${idx + 1}"
            if (!isValidId(t.id) || !transferIds.add(t.id)) {
                errors.add("$tPos: شناسه انتقال تکراری یا نامعتبر است.")
            }
            if (!JalaliCalendarEngine.isValidStrictProjectJalaliDate(t.date)) {
                errors.add("$tPos: تاریخ انتقال نامعتبر است.")
            }
            if (t.kind !in VALID_TRANSFER_KINDS) {
                errors.add("$tPos: نوع انتقال نامعتبر است.")
            }
            if (t.toId !in userIds) {
                errors.add("$tPos: دریافت‌کننده انتقال یافت نشد.")
            }
            if (t.kind == "peer") {
                if (t.fromId.isNullOrEmpty() || t.fromId !in userIds || t.fromId == t.toId) {
                    errors.add("$tPos: فرستنده و گیرنده انتقال باید دو اوستای معتبر و متفاوت باشند.")
                }
            }
            if (!isValidMoney(t.amount)) {
                errors.add("$tPos: مبلغ (amount) نامعتبر، منفی یا بیش از سقف مجاز است.")
            }
            if (t.description.length > DomainConstants.MAX_DESCRIPTION_LENGTH) {
                errors.add("$tPos: توضیحات بیش از سقف مجاز است.")
            }
        }

        val adjIds = HashSet<String>()
        project.adjustments.forEachIndexed { idx, a ->
            val aPos = "$pPrefix / تعدیل ${idx + 1}"
            if (!isValidId(a.id) || !adjIds.add(a.id)) {
                errors.add("$aPos: شناسه تعدیل تکراری یا نامعتبر است.")
            }
            if (!JalaliCalendarEngine.isValidStrictProjectJalaliDate(a.date)) {
                errors.add("$aPos: تاریخ تعدیل نامعتبر است.")
            }
            if (a.userId !in userIds) {
                errors.add("$aPos: کاربر مرجع تعدیل یافت نشد.")
            }
            if (a.kind !in VALID_ADJUSTMENT_KINDS) {
                errors.add("$aPos: نوع تعدیل نامعتبر است.")
            }
            if (!isValidMoney(a.amount)) {
                errors.add("$aPos: مبلغ (amount) نامعتبر، منفی یا بیش از سقف مجاز است.")
            }
            if (a.description.length > DomainConstants.MAX_DESCRIPTION_LENGTH) {
                errors.add("$aPos: توضیحات بیش از سقف مجاز است.")
            }
        }

        return ValidationResult(ok = errors.isEmpty(), errors = errors)
    }

    fun validateAppState(state: AppState): ValidationResult {
        val errors = mutableListOf<String>()
        if (state.projects.isEmpty() || state.projects.size > DomainConstants.MAX_PROJECTS) {
            errors.add("تعداد پروژه‌ها باید بین ۱ تا ۱۰۰ باشد.")
        }
        val projectIds = HashSet<String>()
        state.projects.forEachIndexed { idx, p ->
            if (!projectIds.add(p.id)) {
                errors.add("پروژه ${idx + 1}: شناسه پروژه تکراری است.")
            }
            val pRes = validateProject(p, idx + 1)
            errors.addAll(pRes.errors)
        }
        if (state.projects.isNotEmpty() && state.activeProjectId !in projectIds) {
            errors.add("پروژه فعال در لیست پروژه‌ها وجود ندارد.")
        }

        val ob = state.onboarding
        if (ob.status !in VALID_ONBOARDING_STATUS) {
            errors.add("وضعیت آموزش (onboarding.status) نامعتبر است.")
        }
        if (ob.questStep !in 0..27) {
            errors.add("گام آموزش (onboarding.questStep) باید بین ۰ تا ۲۷ باشد.")
        }
        if (ob.chapter !in 1..3) {
            errors.add("فصل آموزش (onboarding.chapter) باید بین ۱ تا ۳ باشد.")
        }
        val sbId = ob.sandboxProjectId
        if (!sbId.isNullOrEmpty()) {
            if (!sbId.startsWith("demo_quest_") || !isValidId(sbId)) {
                errors.add("شناسه کارگاه تمرینی (sandboxProjectId) نامعتبر است.")
            }
        }

        return ValidationResult(ok = errors.isEmpty(), errors = errors)
    }
}
