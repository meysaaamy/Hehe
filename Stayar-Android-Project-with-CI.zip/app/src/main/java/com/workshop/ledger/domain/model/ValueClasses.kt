package com.workshop.ledger.domain.model

import kotlinx.serialization.KSerializer
import kotlinx.serialization.Serializable
import kotlinx.serialization.descriptors.PrimitiveKind
import kotlinx.serialization.descriptors.PrimitiveSerialDescriptor
import kotlinx.serialization.descriptors.SerialDescriptor
import kotlinx.serialization.encoding.Decoder
import kotlinx.serialization.encoding.Encoder
import kotlinx.serialization.json.JsonDecoder
import kotlinx.serialization.json.JsonEncoder
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import java.util.Locale
import kotlin.math.roundToInt
import kotlin.random.Random

@JvmInline
@Serializable
value class Money(val tomans: Long) : Comparable<Money> {
    override fun compareTo(other: Money): Int = tomans.compareTo(other.tomans)
    operator fun plus(other: Money): Money = Money(tomans + other.tomans)
    operator fun minus(other: Money): Money = Money(tomans - other.tomans)
}

@JvmInline
@Serializable
value class ProjectId(val value: String)

@JvmInline
@Serializable
value class UserId(val value: String)

@JvmInline
@Serializable
value class CategoryId(val value: String)

@JvmInline
value class JalaliDate(val packed: Int) : Comparable<JalaliDate> {
    val year: Int get() = packed ushr 9
    val month: Int get() = (packed ushr 5) and 0x0F
    val day: Int get() = packed and 0x1F

    override fun compareTo(other: JalaliDate): Int = packed.compareTo(other.packed)

    fun toFormattedString(): String = "%04d/%02d/%02d".format(Locale.US, year, month, day)

    override fun toString(): String = toFormattedString()

    companion object {
        fun of(year: Int, month: Int, day: Int): JalaliDate =
            JalaliDate((year shl 9) or (month shl 5) or day)
    }
}

@Serializable(with = AttendanceValueSerializer::class)
sealed interface AttendanceValue {
    val dbStatus: Int
    val dbHalfHours: Int

    data object Full : AttendanceValue {
        override val dbStatus: Int = 1
        override val dbHalfHours: Int = 16
    }

    data object Half : AttendanceValue {
        override val dbStatus: Int = 2
        override val dbHalfHours: Int = 8
    }

    data object Absent : AttendanceValue {
        override val dbStatus: Int = 0
        override val dbHalfHours: Int = 0
    }

    data class Hourly(val hours: Double) : AttendanceValue {
        override val dbStatus: Int = 3
        override val dbHalfHours: Int = (hours * 2.0).roundToInt()
    }

    companion object {
        fun fromDb(status: Int, halfHours: Int): AttendanceValue? = when (status) {
            1 -> Full
            2 -> Half
            0 -> Absent
            3 -> Hourly(halfHours / 2.0)
            else -> null
        }
    }
}

object AttendanceValueSerializer : KSerializer<AttendanceValue> {
    override val descriptor: SerialDescriptor =
        PrimitiveSerialDescriptor("AttendanceValue", PrimitiveKind.STRING)

    override fun serialize(encoder: Encoder, value: AttendanceValue) {
        val jsonEncoder = encoder as? JsonEncoder
        when (value) {
            AttendanceValue.Full -> if (jsonEncoder != null) {
                jsonEncoder.encodeJsonElement(JsonPrimitive(1))
            } else {
                encoder.encodeInt(1)
            }
            AttendanceValue.Half -> if (jsonEncoder != null) {
                jsonEncoder.encodeJsonElement(JsonPrimitive(0.5))
            } else {
                encoder.encodeDouble(0.5)
            }
            AttendanceValue.Absent -> if (jsonEncoder != null) {
                jsonEncoder.encodeJsonElement(JsonPrimitive(0))
            } else {
                encoder.encodeInt(0)
            }
            is AttendanceValue.Hourly -> if (jsonEncoder != null) {
                val hNum: Number = if (value.hours % 1.0 == 0.0) value.hours.toInt() else value.hours
                jsonEncoder.encodeJsonElement(
                    buildJsonObject {
                        put("t", "h")
                        put("h", hNum)
                    }
                )
            } else {
                encoder.encodeString("h:${value.hours}")
            }
        }
    }

    override fun deserialize(decoder: Decoder): AttendanceValue {
        val jsonDecoder = decoder as? JsonDecoder
        if (jsonDecoder != null) {
            val el = jsonDecoder.decodeJsonElement()
            if (el is JsonPrimitive) {
                val content = el.content.trim()
                if (content == "1" || content == "1.0") return AttendanceValue.Full
                if (content == "0.5") return AttendanceValue.Half
                if (content == "0" || content == "0.0") return AttendanceValue.Absent
                val d = el.doubleOrNull
                if (d == 1.0) return AttendanceValue.Full
                if (d == 0.5) return AttendanceValue.Half
                if (d == 0.0) return AttendanceValue.Absent
            } else if (el is JsonObject) {
                val t = el["t"]?.jsonPrimitive?.content
                val h = el["h"]?.jsonPrimitive?.doubleOrNull
                if (t == "h" && h != null) {
                    return AttendanceValue.Hourly(h)
                }
            }
            return AttendanceValue.Hourly(Double.NaN)
        }
        return AttendanceValue.Full
    }
}

object DomainConstants {
    const val BASE_HOURS: Int = 8
    const val MAX_HOURS: Int = 24
    const val MAX_MONEY: Long = 999_999_999_999L
    const val MAX_PROJECTS: Int = 100
    const val MAX_NAME_LENGTH: Int = 200
    const val MAX_DESCRIPTION_LENGTH: Int = 2000
    const val MAX_IMPORT_BYTES: Long = 67_108_864L // 64 MiB

    val ID_REGEX = Regex("^[A-Za-z0-9_.-]{1,64}$")
    val JALALI_DATE_REGEX = Regex("^(\\d{4})/(\\d{2})/(\\d{2})$")

    val DEFAULT_CATEGORIES: List<String> = listOf(
        "مصالح ساختمانی",
        "حمل‌ونقل",
        "ابزار و تجهیزات",
        "غذا و پذیرایی",
        "متفرقه"
    )

    val TYPE_FA: Map<String, String> = mapOf(
        "master" to "اوستا",
        "apprentice" to "شاگرد",
        "custom" to "سایر پرسنل"
    )

    val KIND_FA: Map<String, String> = mapOf(
        "bonus" to "پاداش",
        "penalty" to "جریمه",
        "assistance" to "مساعده",
        "settle" to "تسویه نقدی"
    )

    fun uid(): String {
        val timePart = System.currentTimeMillis().toString(36)
        val randPart = kotlin.math.abs(Random.nextLong()).toString(36).padStart(6, '0').takeLast(6)
        return timePart + randPart
    }
}
