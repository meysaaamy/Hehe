package com.workshop.ledger.presentation.screens.crud

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.workshop.ledger.domain.engine.TextNormalizer
import com.workshop.ledger.domain.model.Category
import com.workshop.ledger.domain.model.DomainConstants
import com.workshop.ledger.domain.model.Expense
import com.workshop.ledger.presentation.components.BadgePill
import com.workshop.ledger.presentation.components.TactileSheet
import com.workshop.ledger.presentation.theme.StayarTheme

@Composable
fun CategoryManagerSheet(
    categories: List<Category>,
    expenses: List<Expense>,
    onUpsertCategory: (Category) -> Unit,
    onDeleteCategory: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val colors = StayarTheme.colors
    val digitsMode = StayarTheme.digitsMode
    val f = { s: String -> TextNormalizer.formatDisplayDigits(s, digitsMode) }
    var newCategoryName by remember { mutableStateOf("") }

    TactileSheet(
        titleFa = "دسته‌بندی هزینه‌ها",
        onDismissRequest = onDismiss
    ) {
        if (categories.isEmpty()) {
            Text("دسته‌ای وجود ندارد", color = colors.textDim, fontSize = 13.5.sp)
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                for (cat in categories) {
                    var editedName by remember(cat.id, cat.name) { mutableStateOf(cat.name) }
                    val usageCount = expenses.count { it.categoryId == cat.id }

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = colors.bgElev2,
                        border = BorderStroke(colors.defaultBorderWidth, colors.borderStrong),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = editedName,
                                onValueChange = {
                                    val capped = it.take(40)
                                    editedName = capped
                                    if (capped.isNotBlank()) {
                                        onUpsertCategory(cat.copy(name = capped.trim()))
                                    }
                                },
                                singleLine = true,
                                modifier = Modifier
                                    .weight(1f)
                                    .semantics { contentDescription = "نام دسته" }
                            )
                            BadgePill(f("$usageCount مورد"), colors.info)
                            OutlinedButton(
                                onClick = { onDeleteCategory(cat.id) },
                                border = BorderStroke(1.dp, colors.danger),
                                modifier = Modifier.semantics { contentDescription = "حذف دسته" }
                            ) {
                                Text("حذف", color = colors.danger, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Footer: input placeholder «نام دسته جدید» + button «افزودن»
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = newCategoryName,
                onValueChange = { newCategoryName = it.take(40) },
                placeholder = { Text("نام دسته جدید") },
                singleLine = true,
                modifier = Modifier.weight(1f)
            )
            Button(
                onClick = {
                    val trimmed = newCategoryName.trim()
                    if (trimmed.isNotEmpty()) {
                        onUpsertCategory(Category(id = "cat_${DomainConstants.uid()}", name = trimmed))
                        newCategoryName = ""
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = colors.accent),
                modifier = Modifier.height(54.dp)
            ) {
                Text("افزودن", color = colors.onAccent, fontWeight = FontWeight.Bold)
            }
        }
    }
}
