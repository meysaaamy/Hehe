package com.workshop.ledger.presentation.screens.health

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.workshop.ledger.domain.engine.DataHealthChecker
import com.workshop.ledger.domain.engine.HealthRuleResult
import com.workshop.ledger.domain.engine.HealthSeverity
import com.workshop.ledger.domain.engine.TextNormalizer
import com.workshop.ledger.domain.model.Project
import com.workshop.ledger.domain.tutorial.AimTarget
import com.workshop.ledger.presentation.theme.StayarTheme
import com.workshop.ledger.presentation.tutorial.questTarget

/**
 * Data Health Check Screen (`«سنجش سلامت داده»`, Section 13).
 * Always evaluates the whole project (range cleared) across all 9 QA rules.
 * Tapping an issue card navigates to the target page to fix the issue.
 * Orphan records card provides the danger `«پاکسازی»` action button.
 */
@Composable
fun HealthScreen(
    project: Project,
    onNavigateToPage: (pageId: String) -> Unit,
    onCleanOrphans: () -> Unit
) {
    val colors = StayarTheme.colors
    val digitsMode = StayarTheme.digitsMode
    val f = { s: String -> TextNormalizer.formatDisplayDigits(s, digitsMode) }

    val ruleResults: List<HealthRuleResult> = remember(project) {
        DataHealthChecker.check(project)
    }

    val issues = ruleResults.filter { it.severity != HealthSeverity.OK }
    val errorCount = ruleResults.count { it.severity == HealthSeverity.ERROR }
    val warnCount = ruleResults.count { it.severity == HealthSeverity.WARN }
    val okCount = ruleResults.count { it.severity == HealthSeverity.OK }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Summary Header Card
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .questTarget(AimTarget.HealthSummaryBox)
                .clip(RoundedCornerShape(16.dp))
                .background(colors.bgElev)
                .border(1.dp, colors.borderStrong, RoundedCornerShape(16.dp))
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (issues.isEmpty()) "داده‌های کارگاه کاملاً سالم است" else "سنجش سلامت داده",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 17.sp,
                        color = if (issues.isEmpty()) colors.success else colors.text
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "پیش از تسویه نهایی، داده‌های این پروژه با قواعد حسابداری بررسی می‌شود. روی کارت‌های «خطا» یا «هشدار» بزنید تا به اولین مورد بروید.",
                        fontSize = 12.sp,
                        lineHeight = 18.sp,
                        color = colors.textDim
                    )
                }

                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(
                            when {
                                errorCount > 0 -> colors.danger.copy(alpha = 0.14f)
                                warnCount > 0 -> colors.warn.copy(alpha = 0.14f)
                                else -> colors.success.copy(alpha = 0.14f)
                            }
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = f(issues.size.toString()),
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 17.sp,
                        color = when {
                            errorCount > 0 -> colors.danger
                            warnCount > 0 -> colors.warn
                            else -> colors.success
                        }
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                SeverityBadge(
                    label = "خطا",
                    count = errorCount,
                    color = colors.danger,
                    format = f,
                    modifier = Modifier.weight(1f)
                )
                SeverityBadge(
                    label = "هشدار",
                    count = warnCount,
                    color = colors.warn,
                    format = f,
                    modifier = Modifier.weight(1f)
                )
                SeverityBadge(
                    label = "سالم",
                    count = okCount,
                    color = colors.success,
                    format = f,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        if (issues.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(colors.success.copy(alpha = 0.08f))
                    .border(1.dp, colors.success.copy(alpha = 0.4f), RoundedCornerShape(14.dp))
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "هیچ مغایرت یا مشکلی یافت نشد؛ همه ۹ قانون کنترل کیفیت تأیید شدند. آماده تسویه‌حساب!",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = colors.success
                )
            }
        }

        // List all 9 rules
        ruleResults.forEach { item ->
            val isOk = item.severity == HealthSeverity.OK
            val cardColor = when (item.severity) {
                HealthSeverity.ERROR -> colors.danger
                HealthSeverity.WARN -> colors.warn
                HealthSeverity.OK -> colors.success
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(colors.bgElev)
                    .border(
                        width = if (isOk) 1.dp else 1.5.dp,
                        color = if (isOk) colors.border else cardColor.copy(alpha = 0.65f),
                        shape = RoundedCornerShape(14.dp)
                    )
                    .clickable(enabled = !isOk && !item.canCleanOrphans) {
                        onNavigateToPage(item.targetPage)
                    }
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(cardColor)
                        )
                        Text(
                            text = f(item.titleFa),
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = if (isOk) colors.text else cardColor
                        )
                    }

                    if (item.canCleanOrphans && item.severity != HealthSeverity.OK) {
                        Button(
                            onClick = onCleanOrphans,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = colors.danger,
                                contentColor = colors.onAccent
                            ),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("پاکسازی", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    } else if (!isOk) {
                        Text(
                            text = "بررسی و اصلاح ←",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = colors.accent
                        )
                    } else {
                        Text(
                            text = "سالم",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = colors.success
                        )
                    }
                }

                Text(
                    text = f(item.messageFa),
                    fontSize = 12.sp,
                    lineHeight = 18.sp,
                    color = if (isOk) colors.textDim else colors.text
                )
            }
        }

        Spacer(modifier = Modifier.height(48.dp))
    }
}

@Composable
private fun SeverityBadge(
    label: String,
    count: Int,
    color: androidx.compose.ui.graphics.Color,
    format: (String) -> String,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(color.copy(alpha = 0.1f))
            .border(1.dp, color.copy(alpha = 0.35f), RoundedCornerShape(10.dp))
            .padding(vertical = 8.dp, horizontal = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = format(count.toString()),
            fontWeight = FontWeight.ExtraBold,
            fontSize = 15.sp,
            color = color
        )
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = color
        )
    }
}
