package com.workshop.ledger.presentation.screens.crud

sealed class CrudPageConfig(
    val pageId: String,
    val titleFa: String,
    val singleFa: String,
    val addBtnFa: String,
    val icon: String,
    val introFa: String,
    val hasRangeToggle: Boolean = true,
    val hasFooterTotal: Boolean = false,
    val hasActiveFlag: Boolean = true,
    val hasSaveAndAddAnother: Boolean = true,
    val extraBtnFa: String? = null
) {
    data object Receipts : CrudPageConfig(
        pageId = "receipts",
        titleFa = "واریزی‌های کارفرما",
        singleFa = "واریزی",
        addBtnFa = "واریزی جدید",
        icon = "wallet",
        introFa = "پولی که از کارفرما دریافت می‌کنید. هر واریزی یک بازهٔ تاریخ دارد؛ مبلغ آن به‌طور مساوی بین روزهای همین بازه پخش می‌شود و هر گزارش فقط سهم روزهای داخل بازهٔ خودش را حساب می‌کند (پس جمع گزارش‌های پشت‌سرهم دقیقاً برابر کل مبلغ است). بازه را همان دوره‌ای بگذارید که پول بابتش آمده.",
        hasRangeToggle = true,
        hasFooterTotal = true
    )

    data object Expenses : CrudPageConfig(
        pageId = "expenses",
        titleFa = "هزینه‌ها",
        singleFa = "هزینه",
        addBtnFa = "هزینه جدید",
        icon = "cart",
        introFa = "هزینه «مشترک» از صندوق کارگاه پرداخت می‌شود و از سود کم می‌شود. هزینه «شخصی اوستا» را همان اوستا از جیب داده؛ به او برگردانده می‌شود و بین همه اوستاها به نسبت کارکرد تقسیم می‌شود.",
        hasRangeToggle = true,
        hasFooterTotal = true,
        extraBtnFa = "دسته‌ها"
    )

    data object Payouts : CrudPageConfig(
        pageId = "payouts",
        titleFa = "پرداختی‌های شاگردها",
        singleFa = "پرداختی",
        addBtnFa = "پرداختی جدید",
        icon = "receipt",
        introFa = "پول نقدی که به شاگرد یا پرسنل داده‌اید. این مبلغ از طلب او کم می‌شود؛ مانده حساب هر نفر در داشبورد دیده می‌شود.",
        hasRangeToggle = true,
        hasFooterTotal = true
    )

    data object Transfers : CrudPageConfig(
        pageId = "transfers",
        titleFa = "انتقال بین اوستاها",
        singleFa = "انتقال",
        addBtnFa = "انتقال جدید",
        icon = "transfer",
        introFa = "پرداخت مستقیم یک اوستا به اوستای دیگر (تسویه داخلی) از درآمد کارگاه جداست. «پیش‌برداشت» یعنی اوستا پیش از تقسیم سود از صندوق پول برداشته است.",
        hasRangeToggle = true,
        hasFooterTotal = false
    )

    data object Adjustments : CrudPageConfig(
        pageId = "adjustments",
        titleFa = "پاداش، جریمه و مساعده",
        singleFa = "تعدیل",
        addBtnFa = "تعدیل جدید",
        icon = "bolt",
        introFa = "اقلام مستقل از حضور و غیاب: پاداش و جریمه تراز فرد را کم و زیاد می‌کند؛ مساعده پول نقد فوری از صندوق است؛ «تسویه نقدی» پولی است که اوستای بدهکار به صندوق برمی‌گرداند.",
        hasRangeToggle = true,
        hasFooterTotal = false
    )

    data object Wages : CrudPageConfig(
        pageId = "wages",
        titleFa = "دستمزدها",
        singleFa = "نرخ دستمزد",
        addBtnFa = "نرخ جدید",
        icon = "layers",
        introFa = "نرخ روزانه هر شاگرد یا پرسنل با تاریخ اعتبار. حساب هر روز کارکرد با نزدیک‌ترین نرخ قبل از همان روز انجام می‌شود؛ اگر پیش از اولین نرخ کار کرده باشد، اولین نرخ ثبت‌شده مبنا قرار می‌گیرد.",
        hasRangeToggle = false,
        hasFooterTotal = false,
        hasActiveFlag = false,
        hasSaveAndAddAnother = false
    )

    data object Users : CrudPageConfig(
        pageId = "users",
        titleFa = "کاربران",
        singleFa = "کاربر",
        addBtnFa = "کاربر جدید",
        icon = "users",
        introFa = "اوستا در سود کارگاه سهیم است (به نسبت کارکرد × ضریب). شاگرد و پرسنل سایر دستمزد روزانه می‌گیرند. کاربر غیرفعال در حضور و غیاب دیده نمی‌شود اما سوابقش می‌ماند؛ به‌جای حذف، غیرفعال‌کردن را ترجیح دهید.",
        hasRangeToggle = false,
        hasFooterTotal = false,
        hasActiveFlag = true,
        hasSaveAndAddAnother = false
    )

    companion object {
        fun forPageId(pageId: String): CrudPageConfig = when (pageId) {
            "receipts" -> Receipts
            "expenses" -> Expenses
            "payouts" -> Payouts
            "transfers" -> Transfers
            "adjustments" -> Adjustments
            "wages" -> Wages
            "users" -> Users
            else -> Expenses
        }
    }
}
