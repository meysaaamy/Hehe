package com.workshop.ledger.presentation.screens.reports

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.workshop.ledger.core.document.StayarDocumentEngine
import com.workshop.ledger.domain.engine.TextNormalizer
import com.workshop.ledger.presentation.components.TactileSheet
import com.workshop.ledger.presentation.theme.StayarTheme
import kotlinx.coroutines.launch
import java.io.File

/**
 * Multi-page A4 Preview Sheet (`«تصویر A4 — {N} صفحه»`, Section 11).
 * Displays page thumbnails, individual page export buttons (`«صفحه {i}»`),
 * and the primary vertical stitch button (`«همهٔ صفحه‌ها در یک تصویر»`).
 */
@Composable
fun A4PreviewSheet(
    title: String,
    pages: List<Bitmap>,
    baseName: String,
    documentEngine: StayarDocumentEngine,
    onSharePngFile: (File, String) -> Unit,
    onDismiss: () -> Unit
) {
    val colors = StayarTheme.colors
    val digitsMode = StayarTheme.digitsMode
    val scope = rememberCoroutineScope()

    TactileSheet(
        title = title,
        onDismiss = onDismiss
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (pages.size > 1) {
                Button(
                    onClick = {
                        scope.launch {
                            val combined = documentEngine.stitchBitmapsVertically(pages)
                            val outFile = documentEngine.saveBitmapToPngFile(combined, "${baseName}_all.png")
                            onSharePngFile(outFile, "${baseName}_all.png")
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = colors.accent,
                        contentColor = colors.onAccent
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("همهٔ صفحه‌ها در یک تصویر", fontWeight = FontWeight.ExtraBold)
                }
            }

            pages.forEachIndexed { idx, pageBitmap ->
                val pageNumberFa = TextNormalizer.formatDisplayDigits((idx + 1).toString(), digitsMode)
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(colors.bgElev)
                        .border(1.dp, colors.borderStrong, RoundedCornerShape(14.dp))
                        .padding(10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "صفحه $pageNumberFa",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 13.sp,
                            color = colors.text
                        )
                        OutlinedButton(
                            onClick = {
                                scope.launch {
                                    val file = documentEngine.saveBitmapToPngFile(
                                        pageBitmap,
                                        "${baseName}_p${idx + 1}.png"
                                    )
                                    onSharePngFile(file, "${baseName}_p${idx + 1}.png")
                                }
                            }
                        ) {
                            Text("صفحه $pageNumberFa", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Image(
                        bitmap = pageBitmap.asImageBitmap(),
                        contentDescription = "صفحه $pageNumberFa",
                        contentScale = ContentScale.FillWidth,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .border(1.dp, colors.border, RoundedCornerShape(8.dp))
                    )
                }
            }

            OutlinedButton(
                onClick = onDismiss,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("بستن", fontWeight = FontWeight.Bold)
            }
        }
    }
}
