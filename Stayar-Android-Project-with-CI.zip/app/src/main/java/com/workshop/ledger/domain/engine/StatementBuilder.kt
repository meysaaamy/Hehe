package com.workshop.ledger.domain.engine

import com.workshop.ledger.domain.model.AccountingResult
import com.workshop.ledger.domain.model.AttendanceValue
import com.workshop.ledger.domain.model.DailyStatementRow
import com.workshop.ledger.domain.model.DomainConstants
import com.workshop.ledger.domain.model.Project
import com.workshop.ledger.domain.model.ReportRange
import com.workshop.ledger.domain.model.StatementModel
import com.workshop.ledger.domain.model.StatementTransferRow
import com.workshop.ledger.domain.model.UserType

object StatementBuilder {

    fun rangeTextFa(range: ReportRange, digitsMode: DigitsMode = DigitsMode.EN): String {
        if (range.from.isEmpty() && range.to.isEmpty()) {
            return "همهٔ دوره"
        }
        val fromPart = if (range.from.isNotEmpty()) {
            JalaliCalendarEngine.jHuman(range.from, digitsMode)
        } else {
            "ابتدای کار"
        }
        val toPart = if (range.to.isNotEmpty()) {
            JalaliCalendarEngine.jHuman(range.to, digitsMode)
        } else {
            "امروز"
        }
        return "$fromPart تا $toPart"
    }

    fun attendanceStatusLabelFa(value: AttendanceValue, digitsMode: DigitsMode = DigitsMode.EN): String {
        return when (value) {
            AttendanceValue.Full -> "کامل"
            AttendanceValue.Half -> "نصفه"
            AttendanceValue.Absent -> "غایب"
            is AttendanceValue.Hourly -> {
                val h = TextNormalizer.fmtDays(value.hours)
                TextNormalizer.formatDisplayDigits("$h ساعت", digitsMode)
            }
        }
    }

    fun statementModel(
        project: Project,
        userId: String,
        accountingResult: AccountingResult? = null
    ): StatementModel? {
        val r = accountingResult ?: AccountingEngine.compute(project)
        val person = r.acc[userId] ?: return null
        val range = r.range
        val ot = AccountingEngine.sanitizeOvertimeFactor(project.settings.overtimeFactor)
        val pen = AccountingEngine.sanitizeAbsentPenalty(project.settings.absentPenalty)
        val calcVersion = project.settings.calcVersion

        val dailyRows = mutableListOf<DailyStatementRow>()
        val sortedDates = project.attendance.keys.filter { range.inRange(it) }.sorted()
        for (date in sortedDates) {
            val v = project.attendance[date]?.get(userId) ?: continue
            val f = AccountingEngine.attFr(v, project) ?: continue
            val rate = if (person.type != UserType.MASTER) {
                AccountingEngine.wageRateFor(project.wages, userId, date)
            } else {
                0L
            }
            val amount = if (person.type != UserType.MASTER) {
                AccountingEngine.dailyStaffWage(v, rate, ot, pen, calcVersion)
            } else {
                0L
            }
            dailyRows.add(
                DailyStatementRow(
                    date = date,
                    weekdayFa = JalaliCalendarEngine.jDowStr(date),
                    value = v,
                    statusLabelFa = attendanceStatusLabelFa(v),
                    fraction = f,
                    rate = rate,
                    amount = amount
                )
            )
        }

        val payouts = project.payouts.filter {
            it.active && it.userId == userId && range.inRange(it.date)
        }.sortedBy { it.date }

        val adjustments = project.adjustments.filter {
            it.active && it.userId == userId && range.inRange(it.date)
        }.sortedBy { it.date }

        val userNames = project.users.associate { it.id to it.name }
        val transfers = project.transfers.filter {
            it.active && range.inRange(it.date) && (it.fromId == userId || it.toId == userId)
        }.sortedBy { it.date }.map { t ->
            val label = when {
                t.kind == "advance" -> "پیش‌برداشت از صندوق"
                t.fromId == userId -> "پرداخت به ${userNames[t.toId] ?: t.toId}"
                else -> "دریافت از ${userNames[t.fromId] ?: (t.fromId ?: "صندوق")}"
            }
            StatementTransferRow(
                date = t.date,
                labelFa = label,
                amount = t.amount,
                description = t.description
            )
        }

        val personalExpenses = project.expenses.filter {
            it.active && range.inRange(it.date) && it.payerId == userId
        }.sortedBy { it.date }

        return StatementModel(
            userId = userId,
            name = person.name,
            role = person.role,
            type = person.type,
            projectName = project.name,
            range = range,
            person = person,
            masterResult = r.masters.find { it.id == userId },
            staffResult = r.staff.find { it.id == userId },
            dailyRows = dailyRows,
            payouts = payouts,
            adjustments = adjustments,
            transfers = transfers,
            personalExpenses = personalExpenses
        )
    }

    fun statementText(
        project: Project,
        userId: String,
        accountingResult: AccountingResult? = null
    ): String {
        val r = accountingResult ?: AccountingEngine.compute(project)
        val model = statementModel(project, userId, r) ?: return ""
        val p = model.person
        val typeLabel = p.type.labelFa
        val rangeStr = rangeTextFa(model.range, DigitsMode.EN)
        val daysStr = TextNormalizer.fmtDays(p.days)

        val lines = mutableListOf<String>()
        lines.add("📒 صورتحساب کارگاه — استایار")
        lines.add("👤 ${p.name} ($typeLabel)")
        lines.add("🏗️ پروژه: ${project.name}")
        lines.add("📅 بازه: $rangeStr")
        lines.add("━━━━━━━━━━━━━━")
        lines.add("⏱️ کارکرد: $daysStr روز (کامل ${p.full}، نصفه ${p.half}، ساعتی ${p.hourly}، غایب ${p.absent})")

        if (p.type != UserType.MASTER) {
            val sr = model.staffResult!!
            lines.add("💰 دستمزد پایه: ${TextNormalizer.fmt(sr.baseWage)} تومان")
            lines.add("🎁 پاداش: ${TextNormalizer.fmt(sr.bonus)} تومان")
            lines.add("⚠️ جریمه: ${TextNormalizer.fmt(sr.penalty)} تومان")
            lines.add("📌 دستمزد استحقاقی: ${TextNormalizer.fmt(sr.entitled)} تومان")
            lines.add("💵 پرداختی و مساعده: ${TextNormalizer.fmt(sr.totalPaid)} تومان")
            lines.add("━━━━━━━━━━━━━━")
            if (sr.debt >= 0L) {
                lines.add("✅ مانده طلب: ${TextNormalizer.fmt(sr.debt)} تومان")
            } else {
                lines.add("🔸 اضافه‌پرداخت: ${TextNormalizer.fmt(-sr.debt)} تومان")
            }
        } else {
            val mr = model.masterResult!!
            val pctStr = TextNormalizer.pctText(mr.percent)
            val netTransfers = mr.given - mr.taken
            val advAndAssist = mr.advance + mr.assistance
            val netBonusPenalty = mr.bonus - mr.penalty
            lines.add("📊 سهم از سود: ٪$pctStr = ${TextNormalizer.fmt(mr.share)} تومان")
            lines.add("🧾 بازپرداخت هزینه شخصی: ${TextNormalizer.fmt(mr.reimburse)} تومان")
            lines.add("➖ سهم هزینه‌های شخصی مشترک: ${TextNormalizer.fmt(mr.sharedPersonalExp)} تومان")
            lines.add("🔄 انتقال‌ها (خالص): ${TextNormalizer.fmt(netTransfers)} تومان")
            lines.add("🏦 پیش‌برداشت و مساعده: ${TextNormalizer.fmt(advAndAssist)} تومان")
            lines.add("🎁 پاداش/جریمه: ${TextNormalizer.fmt(netBonusPenalty)} تومان")
            if (mr.settle != 0L) {
                lines.add("💵 تسویه نقدی: ${TextNormalizer.fmt(mr.settle)} تومان")
            }
            lines.add("━━━━━━━━━━━━━━")
            if (mr.finalBalance >= 0L) {
                lines.add("✅ مانده تسویه: ${TextNormalizer.fmt(mr.finalBalance)} تومان")
            } else {
                lines.add("🔸 بدهکار به کارگاه: ${TextNormalizer.fmt(-mr.finalBalance)} تومان")
            }
        }

        return lines.joinToString("\n")
    }

    /**
     * CSV formula-injection guard & RFC 4180 cell escaping.
     */
    fun csvCell(raw: Any?): String {
        if (raw == null) return ""
        var s = raw.toString()
        if (s.isEmpty()) return ""
        val first = s[0]
        if (first == '=' || first == '+' || first == '@' || first == '\t' || first == '\r' ||
            (first == '-' && s.length > 1 && !s[1].isDigit())
        ) {
            s = "'$s"
        }
        return if (s.contains(',') || s.contains('"') || s.contains('\n') || s.contains('\r')) {
            "\"${s.replace("\"", "\"\"")}\""
        } else {
            s
        }
    }

    private fun csvRow(vararg cells: Any?): String = cells.joinToString(",") { csvCell(it) }

    fun buildFinancialReportCsv(
        project: Project,
        accountingResult: AccountingResult? = null,
        nowStr: String = JalaliCalendarEngine.jNowStr(),
        includeBom: Boolean = false
    ): String {
        val r = accountingResult ?: AccountingEngine.compute(project)
        val basisFa = if (r.basis == "commitment") "تعهدی" else "نقدی"
        val rangeStr = rangeTextFa(r.range, DigitsMode.EN)

        val rows = mutableListOf<String>()
        rows.add("گزارش جامع مالی — استایار")
        rows.add(csvRow("پروژه", project.name))
        rows.add(csvRow("بازه", rangeStr))
        rows.add(csvRow("مبنای سود", basisFa))
        rows.add(csvRow("تاریخ تهیه", nowStr))
        rows.add("")
        rows.add("شاخص‌های کلیدی")
        rows.add(csvRow("شاخص", "مبلغ (تومان)"))
        rows.add(csvRow("مجموع واریزی", r.totalReceipts))
        rows.add(csvRow("هزینه‌های مشترک", r.sharedExpenses))
        rows.add(csvRow("هزینه‌های شخصی اوستاها", r.personalExpTotal))
        rows.add(csvRow("کل دستمزد استحقاقی", r.totalWages))
        rows.add(csvRow("پرداختی‌های نقدی", r.totalCashPayouts))
        rows.add(csvRow("مساعده پرسنل", r.staffAssistance))
        rows.add(csvRow("پاداش اوستاها", r.masterBonus))
        rows.add(csvRow("جریمه اوستاها", r.masterPenalty))
        rows.add(csvRow("مانده قابل تقسیم", r.profit))
        rows.add("")
        rows.add("سهم اوستاها")
        rows.add(
            csvRow(
                "نام", "کارکرد (روز)", "ضریب", "کارکرد نهایی", "درصد سهم",
                "سهم پایه", "بازپرداخت هزینه شخصی", "سهم هزینه شخصی",
                "انتقال داده‌شده", "انتقال گرفته‌شده", "پیش‌برداشت", "مساعده",
                "پاداش", "جریمه", "تسویه نقدی", "مانده نهایی"
            )
        )
        for (m in r.masters) {
            rows.add(
                csvRow(
                    m.name,
                    TextNormalizer.fmtDays(m.days),
                    TextNormalizer.fmtDays(m.workFactor),
                    TextNormalizer.fmtDays(m.workFinal),
                    TextNormalizer.fmtDays(m.percent * 100.0),
                    m.share,
                    m.reimburse,
                    m.sharedPersonalExp,
                    m.given,
                    m.taken,
                    m.advance,
                    m.assistance,
                    m.bonus,
                    m.penalty,
                    m.settle,
                    m.finalBalance
                )
            )
        }
        rows.add("")
        rows.add("تراز شاگردان و پرسنل سایر")
        rows.add(
            csvRow(
                "نام", "نوع", "روز کامل", "روز نصفه", "ساعتی",
                "ساعت اضافه‌کار", "دستمزد پایه", "پاداش", "جریمه",
                "دستمزد استحقاقی", "پرداختی", "مساعده", "مانده"
            )
        )
        for (s in r.staff) {
            rows.add(
                csvRow(
                    s.name,
                    s.type.labelFa,
                    s.full,
                    s.half,
                    s.hourly,
                    TextNormalizer.fmtDays(s.overtimeHours),
                    s.baseWage,
                    s.bonus,
                    s.penalty,
                    s.entitled,
                    s.paid,
                    s.assistance,
                    s.debt
                )
            )
        }

        val body = rows.joinToString("\n")
        return if (includeBom) "\uFEFF" + body.replace("\n", "\r\n") else body
    }

    fun buildDetailedAuditCsv(
        project: Project,
        accountingResult: AccountingResult? = null,
        includeBom: Boolean = false
    ): String {
        val r = accountingResult ?: AccountingEngine.compute(project)
        val range = r.range
        val rangeStr = rangeTextFa(range, DigitsMode.EN)
        val userNames = project.users.associate { it.id to it.name }
        val catNames = project.categories.associate { it.id to it.name }

        val rows = mutableListOf<String>()
        rows.add(csvRow("ریز حسابرسی — ${project.name}", "بازه: $rangeStr"))
        rows.add("فقط ثبت‌های داخل بازهٔ گزارش آمده است. مبلغ‌ها به تومان‌اند و ستون «روز کار» فقط برای حضور است.")
        rows.add(
            csvRow(
                "نوع", "تاریخ", "شرح", "دسته", "پرداخت‌کننده / شخص",
                "مبلغ (تومان)", "روز کار", "وضعیت", "سهم واریزی در بازه (تومان)"
            )
        )

        var activeReceiptShareSum = 0L
        for (rec in project.receipts) {
            val share = AccountingEngine.receiptShare(rec, range, project.settings.calcVersion)
            val overlaps = (range.from.isEmpty() || rec.dateTo >= range.from) &&
                (range.to.isEmpty() || rec.dateFrom <= range.to)
            if (!overlaps) continue
            val statusFa = if (rec.active) "فعال" else "غیرفعال"
            if (rec.active) activeReceiptShareSum += share
            rows.add(
                csvRow(
                    "واریزی",
                    "${rec.dateFrom} تا ${rec.dateTo}",
                    rec.description,
                    "",
                    "",
                    rec.amount,
                    "",
                    statusFa,
                    if (rec.active) share else 0L
                )
            )
        }

        var activeExpenseSum = 0L
        for (exp in project.expenses) {
            if (!range.inRange(exp.date)) continue
            val catFa = exp.categoryId?.let { catNames[it] } ?: ""
            val payerFa = if (exp.payerId == "shared") {
                "صندوق مشترک"
            } else {
                userNames[exp.payerId] ?: exp.payerId
            }
            val statusFa = if (exp.active) "فعال" else "غیرفعال"
            if (exp.active) activeExpenseSum += exp.amount
            rows.add(
                csvRow(
                    "هزینه",
                    exp.date,
                    exp.description,
                    catFa,
                    payerFa,
                    exp.amount,
                    "",
                    statusFa,
                    ""
                )
            )
        }

        var activePayoutSum = 0L
        for (pay in project.payouts) {
            if (!range.inRange(pay.date)) continue
            val userFa = userNames[pay.userId] ?: pay.userId
            val statusFa = if (pay.active) "فعال" else "غیرفعال"
            if (pay.active && r.acc[pay.userId]?.type != UserType.MASTER) {
                activePayoutSum += pay.amount
            }
            rows.add(
                csvRow(
                    "پرداختی",
                    pay.date,
                    pay.description,
                    "",
                    userFa,
                    pay.amount,
                    "",
                    statusFa,
                    ""
                )
            )
        }

        for (tr in project.transfers) {
            if (!range.inRange(tr.date)) continue
            val kindFa = if (tr.kind == "advance") "پیش‌برداشت" else "انتقال"
            val fromFa = if (tr.kind == "advance" || tr.fromId == null) {
                "صندوق"
            } else {
                userNames[tr.fromId] ?: tr.fromId
            }
            val toFa = userNames[tr.toId] ?: tr.toId
            val statusFa = if (tr.active) "فعال" else "غیرفعال"
            rows.add(
                csvRow(
                    kindFa,
                    tr.date,
                    tr.description,
                    "",
                    "$fromFa → $toFa",
                    tr.amount,
                    "",
                    statusFa,
                    ""
                )
            )
        }

        for (adj in project.adjustments) {
            if (!range.inRange(adj.date)) continue
            val kindFa = DomainConstants.KIND_FA[adj.kind] ?: adj.kind
            val userFa = userNames[adj.userId] ?: adj.userId
            val statusFa = if (adj.active) "فعال" else "غیرفعال"
            rows.add(
                csvRow(
                    kindFa,
                    adj.date,
                    adj.description,
                    "",
                    userFa,
                    adj.amount,
                    "",
                    statusFa,
                    ""
                )
            )
        }

        val liveUsers = project.liveUsers()
        val sortedDates = project.attendance.keys.filter { range.inRange(it) }.sorted()
        for (date in sortedDates) {
            val dayMap = project.attendance[date] ?: continue
            for (u in liveUsers) {
                val v = dayMap[u.id] ?: continue
                val f = AccountingEngine.attFr(v, project)
                val descFa = attendanceStatusLabelFa(v, DigitsMode.EN)
                val fStr = if (f != null) TextNormalizer.fmtDays(f) else ""
                val statusFa = if (f != null) "معتبر" else "نامعتبر"
                rows.add(
                    csvRow(
                        "حضور",
                        date,
                        descFa,
                        "",
                        u.name,
                        "",
                        fStr,
                        statusFa,
                        ""
                    )
                )
            }
        }

        rows.add("")
        rows.add("جمع (فقط ردیف‌های فعال)")
        rows.add(csvRow("واریزی‌ها (سهم در بازه)", "", "", "", "", "", "", "", activeReceiptShareSum))
        rows.add(csvRow("هزینه‌ها", "", "", "", "", activeExpenseSum, "", "", ""))
        rows.add(csvRow("پرداختی‌ها", "", "", "", "", activePayoutSum, "", "", ""))

        val body = rows.joinToString("\n")
        return if (includeBom) "\uFEFF" + body.replace("\n", "\r\n") else body
    }
}
