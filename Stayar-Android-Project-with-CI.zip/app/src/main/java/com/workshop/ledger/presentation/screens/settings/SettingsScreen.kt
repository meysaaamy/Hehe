package com.workshop.ledger.presentation.screens.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.workshop.ledger.data.local.backup.BackupSlotInfo
import com.workshop.ledger.data.local.datastore.AppPreferences
import com.workshop.ledger.data.local.datastore.NotifVerbosity
import com.workshop.ledger.data.local.datastore.ThemeMode
import com.workshop.ledger.domain.engine.DigitsMode
import com.workshop.ledger.domain.engine.JalaliCalendarEngine
import com.workshop.ledger.domain.engine.TextNormalizer
import com.workshop.ledger.domain.model.Project
import com.workshop.ledger.presentation.components.TactileSheet
import com.workshop.ledger.presentation.theme.StayarTheme

/**
 * Settings & Backup Screen (`«تنظیمات و پشتیبان»`, Section 13).
 * Structured into 5 comprehensive cards:
 * 1. Project Settings: Profit basis, Overtime factor, Absence deduction, Report range, Period lock toggle, Rename.
 * 2. Backup & Restore: Full backup export/import, Project export/import, Emergency snapshot restore, Rolling backups.
 * 3. Appearance, Digits & Sound: Theme selector, Digits selector, Splash/Sound/Haptics toggles.
 * 4. Sound & Notifications: Volume slider + test button, Notification verbosity.
 * 5. Other: Practice tutorial, 12-step guide, Sample project, Danger clear financial data, Offline footer.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(
    project: Project,
    prefs: AppPreferences,
    emergencySnapshot: BackupSlotInfo?,
    rollingSnapshots: List<BackupSlotInfo>,
    onUpdateProfitBasis: (String) -> Unit,
    onUpdateOvertimeFactor: (Double) -> Unit,
    onUpdateAbsentPenalty: (Double) -> Unit,
    onTogglePeriodLock: () -> Unit,
    onOpenReportRangeDialog: () -> Unit,
    onRenameProject: () -> Unit,
    onExportFullBackup: () -> Unit,
    onImportFullBackup: () -> Unit,
    onExportProjectJson: () -> Unit,
    onImportProjectJson: () -> Unit,
    onRestoreEmergencySnapshot: () -> Unit,
    onCreateRollingSnapshotNow: () -> Unit,
    onRestoreRollingSnapshot: (BackupSlotInfo) -> Unit,
    onSelectThemeMode: (ThemeMode) -> Unit,
    onSelectDigitsMode: (DigitsMode) -> Unit,
    onToggleSplash: (Boolean) -> Unit,
    onToggleSound: (Boolean) -> Unit,
    onToggleHaptics: (Boolean) -> Unit,
    onUpdateVolume: (Int) -> Unit,
    onTestSound: () -> Unit,
    onSelectNotifVerbosity: (NotifVerbosity) -> Unit,
    onStartPracticeTutorial: () -> Unit,
    onOpen12StepGuide: () -> Unit,
    onCreateSampleProject: () -> Unit,
    onClearFinancialData: () -> Unit
) {
    val colors = StayarTheme.colors
    val digitsMode = StayarTheme.digitsMode
    val f = { s: String -> TextNormalizer.formatDisplayDigits(s, digitsMode) }

    var showClearConfirm by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // ==========================================
        // CARD 1: تنظیمات پروژه
        // ==========================================
        SettingsCard(title = "تنظیمات پروژه «${f(project.name)}»") {
            // Profit Basis
            Text(text = "مبنای محاسبه سود:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                val isCash = project.settings.profitBasis == "cash"
                FilterChip(
                    selected = isCash,
                    onClick = { onUpdateProfitBasis("cash") },
                    label = { Text("نقدی (پیش‌فرض)") },
                    modifier = Modifier.weight(1f)
                )
                FilterChip(
                    selected = !isCash,
                    onClick = { onUpdateProfitBasis("commitment") },
                    label = { Text("تعهدی — تسویه نهایی") },
                    modifier = Modifier.weight(1f)
                )
            }

            HorizontalDivider(color = colors.border)

            // Overtime factor
            val currentOt = project.settings.overtimeFactor
            Text(
                text = "ضریب اضافه‌کار (ساعات بالای ۸ ساعت): ${f(currentOt.toString())} برابر",
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
            )
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(1.0 to "۱× (بدون افزایش)", 1.25 to "۱٫۲۵×", 1.5 to "۱٫۵×", 2.0 to "۲×").forEach { (otVal, label) ->
                    FilterChip(
                        selected = kotlin.math.abs(currentOt - otVal) < 0.01,
                        onClick = { onUpdateOvertimeFactor(otVal) },
                        label = { Text(label) }
                    )
                }
            }

            HorizontalDivider(color = colors.border)

            // Absent penalty
            val currentPen = project.settings.absentPenalty
            Text(
                text = "کسر غیبت از کارکرد: ${f(currentPen.toString())} روز",
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
            )
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(0.0 to "بدون کسر", 0.25 to "۰٫۲۵ روز", 0.5 to "۰٫۵ روز", 1.0 to "۱ روز", 2.0 to "۲ روز").forEach { (penVal, label) ->
                    FilterChip(
                        selected = kotlin.math.abs(currentPen - penVal) < 0.01,
                        onClick = { onUpdateAbsentPenalty(penVal) },
                        label = { Text(label) }
                    )
                }
            }

            HorizontalDivider(color = colors.border)

            // Actions: Range, Lock, Rename
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = onOpenReportRangeDialog,
                    modifier = Modifier.weight(1f)
                ) {
                    Text("بازه گزارش", fontSize = 12.sp)
                }
                OutlinedButton(
                    onClick = onTogglePeriodLock,
                    colors = if (project.settings.locked) ButtonDefaults.outlinedButtonColors(contentColor = colors.warn) else ButtonDefaults.outlinedButtonColors(),
                    modifier = Modifier.weight(1f)
                ) {
                    Text(if (project.settings.locked) "باز کردن قفل" else "قفل دوره مالی", fontSize = 12.sp)
                }
                OutlinedButton(
                    onClick = onRenameProject,
                    modifier = Modifier.weight(1f)
                ) {
                    Text("تغییر نام", fontSize = 12.sp)
                }
            }
        }

        // ==========================================
        // CARD 2: پشتیبان‌گیری و بازیابی
        // ==========================================
        SettingsCard(title = "پشتیبان‌گیری و بازیابی") {
            Text(text = "پشتیبان کل پایگاه داده:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = onExportFullBackup,
                    colors = ButtonDefaults.buttonColors(containerColor = colors.accent, contentColor = colors.onAccent),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("خروجی کامل JSON", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                OutlinedButton(
                    onClick = onImportFullBackup,
                    modifier = Modifier.weight(1f)
                ) {
                    Text("بازیابی کامل", fontSize = 12.sp)
                }
            }

            Text(text = "پشتیبان پروژه فعال:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = onExportProjectJson,
                    modifier = Modifier.weight(1f)
                ) {
                    Text("خروجی همین پروژه", fontSize = 12.sp)
                }
                OutlinedButton(
                    onClick = onImportProjectJson,
                    modifier = Modifier.weight(1f)
                ) {
                    Text("ورود پروژه جدید", fontSize = 12.sp)
                }
            }

            HorizontalDivider(color = colors.border)

            // Emergency Snapshot
            Text(text = "نسخه امن اضطراری (قبل از عملیات حساس):", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            if (emergencySnapshot != null) {
                val dateStr = JalaliCalendarEngine.tsText(emergencySnapshot.lastModifiedMs)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "ذخیره شده در: ${f(dateStr)}", fontSize = 12.sp, color = colors.textDim)
                    Button(
                        onClick = onRestoreEmergencySnapshot,
                        colors = ButtonDefaults.buttonColors(containerColor = colors.warn, contentColor = colors.onAccent)
                    ) {
                        Text("بازیابی اضطراری", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            } else {
                Text(text = "هنوز نسخه اضطراری ایجاد نشده است.", fontSize = 12.sp, color = colors.textDim)
            }

            HorizontalDivider(color = colors.border)

            // Rolling Auto-Backup
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "پشتیبان خودکار چرخشی (۳ نسخه اخیر):", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Button(
                    onClick = onCreateRollingSnapshotNow,
                    colors = ButtonDefaults.buttonColors(containerColor = colors.accent, contentColor = colors.onAccent)
                ) {
                    Text("اکنون نسخه بساز", fontSize = 11.sp)
                }
            }

            if (rollingSnapshots.isNotEmpty()) {
                rollingSnapshots.forEach { snap ->
                    val dateStr = JalaliCalendarEngine.tsText(snap.lastModifiedMs)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(colors.bgElev2)
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "نسخه ${f(snap.slot.toString())} — ${f(dateStr)}", fontSize = 12.sp)
                        OutlinedButton(onClick = { onRestoreRollingSnapshot(snap) }) {
                            Text("بازیابی", fontSize = 11.sp)
                        }
                    }
                }
            } else {
                Text(text = "نسخه چرخشی ثبت نشده است.", fontSize = 12.sp, color = colors.textDim)
            }
        }

        // ==========================================
        // CARD 3: ظاهر، ارقام و صدا
        // ==========================================
        SettingsCard(title = "ظاهر، ارقام و صدا") {
            // Theme Mode
            Text(text = "پوسته نمایشی:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                ThemeMode.entries.forEach { mode ->
                    FilterChip(
                        selected = prefs.themeMode == mode,
                        onClick = { onSelectThemeMode(mode) },
                        label = { Text(mode.labelFa) }
                    )
                }
            }

            HorizontalDivider(color = colors.border)

            // Digits Mode
            Text(text = "قالب ارقام:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = prefs.digitsMode == DigitsMode.FA,
                    onClick = { onSelectDigitsMode(DigitsMode.FA) },
                    label = { Text("فارسی (۱۲۳)") },
                    modifier = Modifier.weight(1f)
                )
                FilterChip(
                    selected = prefs.digitsMode == DigitsMode.EN,
                    onClick = { onSelectDigitsMode(DigitsMode.EN) },
                    label = { Text("انگلیسی (123)") },
                    modifier = Modifier.weight(1f)
                )
            }

            HorizontalDivider(color = colors.border)

            // Checkboxes
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = prefs.splashEnabled, onCheckedChange = onToggleSplash)
                Text("نمایش انیمیشن هنگام باز شدن برنامه", fontSize = 13.sp)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = prefs.soundEnabled, onCheckedChange = onToggleSound)
                Text("صدا (انیمیشن شروع و صدای لمس‌ها)", fontSize = 13.sp)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = prefs.hapticsEnabled, onCheckedChange = onToggleHaptics)
                Text("لرزش هنگام لمس", fontSize = 13.sp)
            }
        }

        // ==========================================
        // CARD 4: صدا و اعلان‌ها
        // ==========================================
        SettingsCard(title = "صدا و اعلان‌ها") {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "بلندی صدا: ${f(prefs.volume.toString())}٪", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Button(
                    onClick = onTestSound,
                    colors = ButtonDefaults.buttonColors(containerColor = colors.accent, contentColor = colors.onAccent)
                ) {
                    Text("آزمایش صدا", fontSize = 11.sp)
                }
            }

            Slider(
                value = prefs.volume.toFloat(),
                onValueChange = { onUpdateVolume(it.toInt()) },
                valueRange = 0f..100f,
                steps = 19
            )

            HorizontalDivider(color = colors.border)

            Text(text = "میزان نمایش اعلان‌ها:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                NotifVerbosity.entries.forEach { verb ->
                    FilterChip(
                        selected = prefs.notifVerbosity == verb,
                        onClick = { onSelectNotifVerbosity(verb) },
                        label = { Text(verb.labelFa) },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        // ==========================================
        // CARD 5: سایر
        // ==========================================
        SettingsCard(title = "سایر") {
            Button(
                onClick = onStartPracticeTutorial,
                colors = ButtonDefaults.buttonColors(containerColor = colors.accent, contentColor = colors.onAccent),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("تمرین عملی کارگاه (۲۸ گام)", fontWeight = FontWeight.Bold)
            }

            OutlinedButton(
                onClick = onOpen12StepGuide,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("آموزش گام‌به‌گام ۱۲ مرحله‌ای", fontWeight = FontWeight.Bold)
            }

            OutlinedButton(
                onClick = onCreateSampleProject,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("ساخت پروژه نمونه", fontWeight = FontWeight.Bold)
            }

            Button(
                onClick = { showClearConfirm = true },
                colors = ButtonDefaults.buttonColors(containerColor = colors.danger, contentColor = colors.onAccent),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("پاک‌کردن داده‌های مالی پروژه", fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "استایار هیچ دسترسی اینترنتی ندارد؛ همه اطلاعات فقط روی همین دستگاه ذخیره می‌شود. نسخه ۱٫۰",
                fontSize = 11.sp,
                lineHeight = 16.sp,
                color = colors.textDim
            )
        }

        Spacer(modifier = Modifier.height(48.dp))
    }

    if (showClearConfirm) {
        AlertDialog(
            onDismissRequest = { showClearConfirm = false },
            title = { Text("پاک‌کردن داده‌های مالی") },
            text = { Text("تمام رکوردهای حضور، هزینه‌ها، واریزی‌ها، پرداختی‌ها و تسویه‌ها پاک می‌شوند اما کاربران، دستمزدها و دسته‌ها باقی می‌مانند. نسخه امن ذخیره خواهد شد. ادامه می‌دهید؟") },
            confirmButton = {
                Button(
                    onClick = {
                        onClearFinancialData()
                        showClearConfirm = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = colors.danger, contentColor = colors.onAccent)
                ) {
                    Text("بله، پاک کن")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showClearConfirm = false }) {
                    Text("انصراف")
                }
            }
        )
    }
}

@Composable
private fun SettingsCard(
    title: String,
    content: @Composable () -> Unit
) {
    val colors = StayarTheme.colors
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(colors.bgElev)
            .border(1.dp, colors.borderStrong, RoundedCornerShape(16.dp))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = title,
            fontWeight = FontWeight.ExtraBold,
            fontSize = 16.sp,
            color = colors.text
        )
        content()
    }
}
