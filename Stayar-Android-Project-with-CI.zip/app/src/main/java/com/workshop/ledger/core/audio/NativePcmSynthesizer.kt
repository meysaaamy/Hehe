package com.workshop.ledger.core.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.roundToInt
import kotlin.math.sin

enum class WaveformType {
    SINE,
    SQUARE,
    TRIANGLE
}

class NativePcmSynthesizer {

    companion object {
        const val SAMPLE_RATE = 44_100
    }

    var soundEnabled: Boolean = true
    var volumePercent: Int = 100 // 0..100

    private val audioAttributes: AudioAttributes by lazy {
        AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
    }

    private val staticClickBuffer: ShortArray by lazy {
        synthesizeTone(freqHz = 1100.0, durationSec = 0.018, waveform = WaveformType.SINE)
    }

    private val staticChimeOkBuffer: ShortArray by lazy {
        val part1 = synthesizeTone(freqHz = 1320.0, durationSec = 0.11, waveform = WaveformType.SINE)
        val part2 = synthesizeTone(freqHz = 1760.0, durationSec = 0.16, waveform = WaveformType.SINE)
        part1 + part2
    }

    private val staticChimeErrorBuffer: ShortArray by lazy {
        val part1 = synthesizeTone(freqHz = 330.0, durationSec = 0.16, waveform = WaveformType.TRIANGLE)
        val part2 = synthesizeTone(freqHz = 247.0, durationSec = 0.20, waveform = WaveformType.TRIANGLE)
        part1 + part2
    }

    private val splashChordBuffer: ShortArray by lazy {
        synthesizeSplashSoundtrack()
    }

    /**
     * Synthesizes 16-bit mono PCM waveforms at 44,100 Hz directly into ShortArray
     * with exponential attack over 8 ms and exponential decay to 0.0001 at duration + 20 ms tail.
     */
    fun synthesizeTone(
        freqHz: Double,
        durationSec: Double,
        waveform: WaveformType = WaveformType.SINE,
        amplitude: Double = 0.35
    ): ShortArray {
        val attackSamples = (0.008 * SAMPLE_RATE).roundToInt().coerceAtLeast(1)
        val totalDurationSec = durationSec + 0.020
        val totalSamples = (totalDurationSec * SAMPLE_RATE).roundToInt().coerceAtLeast(attackSamples + 1)
        val decaySamples = (totalSamples - attackSamples).coerceAtLeast(1)
        val decayRate = ln(0.0001) / decaySamples.toDouble()

        val pcm = ShortArray(totalSamples)
        val twoPiF = 2.0 * PI * freqHz / SAMPLE_RATE.toDouble()

        for (i in 0 until totalSamples) {
            val env = if (i < attackSamples) {
                i.toDouble() / attackSamples.toDouble()
            } else {
                exp(decayRate * (i - attackSamples).toDouble())
            }
            val phase = (i.toDouble() * freqHz / SAMPLE_RATE.toDouble()) % 1.0
            val rawWave = when (waveform) {
                WaveformType.SINE -> sin(twoPiF * i)
                WaveformType.SQUARE -> if (phase < 0.5) 1.0 else -1.0
                WaveformType.TRIANGLE -> if (phase < 0.5) (4.0 * phase - 1.0) else (3.0 - 4.0 * phase)
            }
            val sample = (rawWave * env * amplitude * Short.MAX_VALUE).roundToInt()
                .coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
            pcm[i] = sample.toShort()
        }
        return pcm
    }

    private fun synthesizeSplashSoundtrack(): ShortArray {
        val notes = listOf(440.0 to 0.22, 554.37 to 0.22, 659.25 to 0.25, 880.0 to 0.45)
        var out = ShortArray(0)
        for ((f, d) in notes) {
            out += synthesizeTone(f, d, WaveformType.SINE, amplitude = 0.25)
        }
        return out
    }

    fun tick(freqHz: Int = 1100) {
        if (!soundEnabled || volumePercent <= 0) return
        if (freqHz == 1100) {
            playStaticBuffer(staticClickBuffer)
        } else {
            val dynamicBuf = synthesizeTone(
                freqHz = freqHz.coerceIn(200, 4000).toDouble(),
                durationSec = 0.016,
                waveform = WaveformType.SINE,
                amplitude = 0.28
            )
            playStreamBuffer(dynamicBuf)
        }
    }

    fun wheelDetent(index: Int) {
        val freq = 1500 + (index.coerceIn(0, 60) * 6)
        tick(freq)
    }

    fun hourSliderTick(hours: Double) {
        val freq = 850 + (hours * 55.0).roundToInt()
        tick(freq)
    }

    fun chime(ok: Boolean) {
        if (!soundEnabled || volumePercent <= 0) return
        playStaticBuffer(if (ok) staticChimeOkBuffer else staticChimeErrorBuffer)
    }

    fun playSplashAudio() {
        if (!soundEnabled || volumePercent <= 0) return
        playStaticBuffer(splashChordBuffer)
    }

    private fun playStaticBuffer(pcm: ShortArray) {
        try {
            val byteSize = pcm.size * 2
            val format = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(SAMPLE_RATE)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                .build()
            val track = AudioTrack.Builder()
                .setAudioAttributes(audioAttributes)
                .setAudioFormat(format)
                .setBufferSizeInBytes(byteSize)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()

            val gain = (volumePercent.coerceIn(0, 100) / 100f)
            track.setVolume(gain)
            track.write(pcm, 0, pcm.size)
            track.setNotificationMarkerPosition(pcm.size)
            track.setPlaybackPositionUpdateListener(object : AudioTrack.OnPlaybackPositionUpdateListener {
                override fun onMarkerReached(t: AudioTrack?) {
                    try {
                        t?.stop()
                        t?.release()
                    } catch (_: Throwable) {
                    }
                }

                override fun onPeriodicNotification(t: AudioTrack?) = Unit
            })
            track.play()
        } catch (_: Throwable) {
        }
    }

    private fun playStreamBuffer(pcm: ShortArray) {
        try {
            val minBuf = AudioTrack.getMinBufferSize(
                SAMPLE_RATE,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            ).coerceAtLeast(pcm.size * 2)
            val format = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(SAMPLE_RATE)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                .build()
            val track = AudioTrack.Builder()
                .setAudioAttributes(audioAttributes)
                .setAudioFormat(format)
                .setBufferSizeInBytes(minBuf)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()

            val gain = (volumePercent.coerceIn(0, 100) / 100f)
            track.setVolume(gain)
            track.play()
            track.write(pcm, 0, pcm.size)
            track.stop()
            track.release()
        } catch (_: Throwable) {
        }
    }
}
