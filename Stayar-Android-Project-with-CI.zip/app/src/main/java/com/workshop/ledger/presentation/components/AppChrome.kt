package com.workshop.ledger.presentation.components

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.workshop.ledger.data.local.datastore.ThemeMode
import com.workshop.ledger.data.local.db.ProjectEntity
import com.workshop.ledger.presentation.theme.StayarIcon
import com.workshop.ledger.presentation.theme.StayarTheme
import com.workshop.ledger.presentation.tutorial.QuestCoordinator
import com.workshop.ledger.presentation.tutorial.questTarget

data class NavPageDestination(
    val id: String,
    val icon: String,
    val titleFa: String,
    val inBottomNav: Boolean = false,
    val bottomLabelFa: String = titleFa,
    val dividerBeforeInSidebar: Boolean = false
)

val ALL_14_PAGES: List<NavPageDestination> = listOf(
    NavPageDestination("dashboard", "home", "داشبورد", inBottomNav = true, bottomLabelFa = "داشبورد"),
    NavPageDestination("attendance", "calendar", "حضور و غیاب", inBottomNav = true, bottomLabelFa = "حضور", dividerBeforeInSidebar = true),
    NavPageDestination("expenses", "cart", "هزینه‌ها", inBottomNav = true, bottomLabelFa = "هزینه‌ها"),
    NavPageDestination("receipts", "wallet", "واریزی‌های کارفرما"),
    NavPageDestination("payouts", "receipt", "پرداختی‌های شاگردها"),
    NavPageDestination("transfers", "transfer", "انتقال بین اوستاها"),
    NavPageDestination("adjustments", "bolt", "پاداش، جریمه و مساعده"),
    NavPageDestination("wages", "layers", "دستمزدها"),
    NavPageDestination("users", "users", "کاربران"),
    NavPageDestination("reports", "chart", "گزارش‌ها و خروجی", inBottomNav = true, bottomLabelFa = "گزارش‌ها", dividerBeforeInSidebar = true),
    NavPageDestination("health", "shield", "سنجش سلامت داده"),
    NavPageDestination("projects", "folder", "پروژه‌ها", dividerBeforeInSidebar = true),
    NavPageDestination("guide", "help", "راهنما و آموزش"),
    NavPageDestination("settings", "settings", "تنظیمات و پشتیبان")
)

enum class SpeedDialAction(val id: String, val icon: String, val labelFa: String) {
    ATTENDANCE_TODAY("att", "calendar", "ثبت حضور امروز"),
    NEW_EXPENSE("expense", "cart", "ثبت هزینه جدید"),
    NEW_RECEIPT("receipt", "wallet", "واریزی کارفرما"),
    NEW_PAYOUT("payout", "receipt", "پرداخت به شاگرد")
}

@Composable
fun AppChrome(
    currentPageId: String,
    onNavigate: (String) -> Unit,
    activeProjectName: String,
    isSandboxProject: Boolean,
    isPeriodLocked: Boolean,
    onTogglePeriodLock: () -> Unit,
    themeMode: ThemeMode,
    onCycleThemeMode: () -> Unit,
    allProjects: List<ProjectEntity>,
    activeProjectId: String,
    onSelectProject: (String) -> Unit,
    onSpeedDialAction: (SpeedDialAction) -> Unit,
    databaseLoadError: String?,
    questCoordinator: QuestCoordinator? = null,
    content: @Composable () -> Unit
) {
    val config = LocalConfiguration.current
    val isWideScreen = config.screenWidthDp >= 900
    val colors = StayarTheme.colors

    var projectSwitcherOpen by remember { mutableStateOf(false) }
    var morePagesSheetOpen by remember { mutableStateOf(false) }
    var speedDialOpen by remember { mutableStateOf(false) }

    val currentPage = ALL_14_PAGES.find { it.id == currentPageId } ?: ALL_14_PAGES.first()

    // Predictive Back Contract priority order
    BackHandler(enabled = projectSwitcherOpen || morePagesSheetOpen || speedDialOpen || currentPageId != "dashboard") {
        when {
            projectSwitcherOpen -> projectSwitcherOpen = false
            morePagesSheetOpen -> morePagesSheetOpen = false
            speedDialOpen -> speedDialOpen = false
            currentPageId != "dashboard" -> onNavigate("dashboard")
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(colors.bg)
    ) {
        Row(modifier = Modifier.fillMaxSize()) {
            // Adaptive Sidebar on wide screens (>= 900.dp)
            if (isWideScreen) {
                SidebarNavigation(
                    currentPageId = currentPageId,
                    activeProjectName = activeProjectName,
                    isSandbox = isSandboxProject,
                    onOpenProjectSwitcher = { projectSwitcherOpen = true },
                    onNavigate = onNavigate,
                    questCoordinator = questCoordinator
                )
            }

            // Main Content Column
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
            ) {
                TopBarChrome(
                    titleFa = currentPage.titleFa,
                    showCompactProjectChip = !isWideScreen,
                    activeProjectName = activeProjectName,
                    isSandbox = isSandboxProject,
                    isPeriodLocked = isPeriodLocked,
                    themeMode = themeMode,
                    onOpenProjectSwitcher = { projectSwitcherOpen = true },
                    onTogglePeriodLock = onTogglePeriodLock,
                    onCycleThemeMode = onCycleThemeMode,
                    questCoordinator = questCoordinator
                )

                // Database Error Banner (if Room startup failed)
                if (databaseLoadError != null) {
                    DatabaseErrorBanner(loadError = databaseLoadError)
                }

                // Period Lock Warning Banner on data pages
                if (isPeriodLocked) {
                    PeriodLockBanner(onUnlockClick = onTogglePeriodLock)
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                ) {
                    content()
                }

                if (!isWideScreen) {
                    BottomNavBarChrome(
                        currentPageId = currentPageId,
                        onNavigate = onNavigate,
                        onOpenMoreSheet = { morePagesSheetOpen = true },
                        questCoordinator = questCoordinator
                    )
                }
            }
        }

        // Speed-Dial FAB & Backdrop
        SpeedDialFabOverlay(
            isOpen = speedDialOpen,
            isBottomNavVisible = !isWideScreen,
            onToggle = { speedDialOpen = !speedDialOpen },
            onAction = { action ->
                speedDialOpen = false
                onSpeedDialAction(action)
            }
        )

        // Project Switcher Bottom Sheet
        if (projectSwitcherOpen) {
            ProjectSwitcherSheet(
                projects = allProjects,
                activeProjectId = activeProjectId,
                onSelectProject = { pid ->
                    projectSwitcherOpen = false
                    onSelectProject(pid)
                },
                onManageProjects = {
                    projectSwitcherOpen = false
                    onNavigate("projects")
                },
                onDismiss = { projectSwitcherOpen = false }
            )
        }

        // "همهٔ بخش‌ها" (More Pages) Bottom Sheet
        if (morePagesSheetOpen) {
            AllPagesGridSheet(
                currentPageId = currentPageId,
                onSelectPage = { pageId ->
                    morePagesSheetOpen = false
                    onNavigate(pageId)
                },
                onDismiss = { morePagesSheetOpen = false }
            )
        }
    }
}

@Composable
private fun SidebarNavigation(
    currentPageId: String,
    activeProjectName: String,
    isSandbox: Boolean,
    onOpenProjectSwitcher: () -> Unit,
    onNavigate: (String) -> Unit,
    questCoordinator: QuestCoordinator?
) {
    val colors = StayarTheme.colors
    Surface(
        color = colors.bgElev,
        border = BorderStroke(colors.defaultBorderWidth, colors.border),
        modifier = Modifier
            .width(240.dp)
            .fillMaxHeight()
            .statusBarsPadding()
            .semantics { contentDescription = "بخش‌ها" }
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(14.dp)
        ) {
            // Brand Header
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    color = colors.accent,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.size(38.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        StayarIcon("receipt", tint = colors.onAccent, size = 20.dp)
                    }
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text("استایار", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = colors.text)
                    Text("دفتر حساب کارگاه", fontSize = 11.5.sp, color = colors.textDim)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Project Chip
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = colors.bgElev2,
                border = BorderStroke(colors.defaultBorderWidth, colors.borderStrong),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onOpenProjectSwitcher)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        StayarIcon("folder", tint = colors.accent, size = 18.dp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = activeProjectName,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.5.sp,
                            color = colors.text
                        )
                    }
                    if (isSandbox) {
                        BadgePill("تمرینی", colors.warn)
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            for (page in ALL_14_PAGES) {
                if (page.dividerBeforeInSidebar) {
                    HorizontalDivider(
                        color = colors.border,
                        modifier = Modifier.padding(vertical = 6.dp)
                    )
                }
                val isSelected = page.id == currentPageId
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (isSelected) colors.accent else Color.Transparent,
                    modifier = Modifier
                        .fillMaxWidth()
                        .questTarget("nav_${page.id}", questCoordinator)
                        .clickable { onNavigate(page.id) }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        StayarIcon(
                            name = page.icon,
                            tint = if (isSelected) colors.onAccent else colors.textDim,
                            size = 20.dp
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = page.titleFa,
                            color = if (isSelected) colors.onAccent else colors.text,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            fontSize = 14.sp
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun TopBarChrome(
    titleFa: String,
    showCompactProjectChip: Boolean,
    activeProjectName: String,
    isSandbox: Boolean,
    isPeriodLocked: Boolean,
    themeMode: ThemeMode,
    onOpenProjectSwitcher: () -> Unit,
    onTogglePeriodLock: () -> Unit,
    onCycleThemeMode: () -> Unit,
    questCoordinator: QuestCoordinator?
) {
    val colors = StayarTheme.colors
    Surface(
        color = colors.bgElev,
        border = BorderStroke(colors.defaultBorderWidth, colors.border),
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .pointerInput(Unit) {
                var dragY = 0f
                detectVerticalDragGestures(
                    onDragStart = { dragY = 0f },
                    onVerticalDrag = { _, dragAmount ->
                        dragY += dragAmount
                        if (dragY > 48f) {
                            dragY = 0f
                            onOpenProjectSwitcher()
                        }
                    }
                )
            }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = titleFa.ifBlank { "استایار" },
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = colors.text,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (showCompactProjectChip) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = colors.bgElev2,
                        border = BorderStroke(colors.defaultBorderWidth, colors.borderStrong),
                        modifier = Modifier.combinedClickable(
                            onClick = onOpenProjectSwitcher,
                            onLongClick = onOpenProjectSwitcher
                        )
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            StayarIcon("folder", tint = colors.accent, size = 16.dp)
                            Text(
                                text = activeProjectName.take(18),
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = colors.text,
                                maxLines = 1
                            )
                            if (isSandbox) {
                                BadgePill("تمرینی", colors.warn)
                            }
                        }
                    }
                }

                if (isPeriodLocked) {
                    IconButton(
                        onClick = onTogglePeriodLock,
                        modifier = Modifier
                            .questTarget("topbar_lock_btn", questCoordinator)
                            .semantics { contentDescription = "قفل مالی فعال است" }
                    ) {
                        StayarIcon("lock", tint = colors.warn, size = 22.dp)
                    }
                }

                IconButton(
                    onClick = onCycleThemeMode,
                    modifier = Modifier.semantics {
                        contentDescription = "پوسته: ${themeMode.labelFa}"
                    }
                ) {
                    StayarIcon("theme", tint = colors.accent, size = 22.dp)
                }
            }
        }
    }
}

@Composable
private fun BottomNavBarChrome(
    currentPageId: String,
    onNavigate: (String) -> Unit,
    onOpenMoreSheet: () -> Unit,
    questCoordinator: QuestCoordinator?
) {
    val colors = StayarTheme.colors
    val mainTabs = remember { ALL_14_PAGES.filter { it.inBottomNav } }
    val isCurrentInMore = mainTabs.none { it.id == currentPageId }

    Surface(
        color = colors.bgElev,
        border = BorderStroke(colors.defaultBorderWidth, colors.border),
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(64.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            for (tab in mainTabs) {
                val selected = tab.id == currentPageId
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .questTarget("nav_${tab.id}", questCoordinator)
                        .clickable { onNavigate(tab.id) },
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    StayarIcon(
                        name = tab.icon,
                        tint = if (selected) colors.accent else colors.textDim,
                        size = 22.dp
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = tab.bottomLabelFa,
                        fontSize = 11.5.sp,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                        color = if (selected) colors.accent else colors.textDim
                    )
                }
            }

            // 5th tab: «بیشتر»
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .semantics { contentDescription = "بیشتر" }
                    .clickable(onClick = onOpenMoreSheet),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                StayarIcon(
                    name = "more",
                    tint = if (isCurrentInMore) colors.accent else colors.textDim,
                    size = 22.dp
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "بیشتر",
                    fontSize = 11.5.sp,
                    fontWeight = if (isCurrentInMore) FontWeight.Bold else FontWeight.Medium,
                    color = if (isCurrentInMore) colors.accent else colors.textDim
                )
            }
        }
    }
}

@Composable
private fun SpeedDialFabOverlay(
    isOpen: Boolean,
    isBottomNavVisible: Boolean,
    onToggle: () -> Unit,
    onAction: (SpeedDialAction) -> Unit
) {
    val colors = StayarTheme.colors
    val rotation by animateFloatAsState(
        targetValue = if (isOpen) 135f else 0f,
        animationSpec = spring(dampingRatio = 0.65f, stiffness = 380f),
        label = "fabRotation"
    )

    AnimatedVisibility(
        visible = isOpen,
        enter = fadeIn(),
        exit = fadeOut()
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.45f))
                .clickable(onClick = onToggle)
        )
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .navigationBarsPadding()
            .padding(
                end = 20.dp,
                bottom = if (isBottomNavVisible) 80.dp else 20.dp
            ),
        contentAlignment = Alignment.BottomEnd
    ) {
        Column(
            horizontalAlignment = Alignment.End,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            AnimatedVisibility(visible = isOpen) {
                Column(
                    horizontalAlignment = Alignment.End,
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.padding(bottom = 6.dp)
                ) {
                    for (item in SpeedDialAction.entries) {
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = colors.bgElev,
                            border = BorderStroke(colors.defaultBorderWidth, colors.accent),
                            shadowElevation = 6.dp,
                            modifier = Modifier.clickable { onAction(item) }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                StayarIcon(item.icon, tint = colors.accent, size = 18.dp)
                                Text(
                                    text = item.labelFa,
                                    fontSize = 13.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = colors.text
                                )
                            }
                        }
                    }
                }
            }

            Surface(
                shape = CircleShape,
                color = colors.accent,
                shadowElevation = 8.dp,
                modifier = Modifier
                    .size(58.dp)
                    .semantics { contentDescription = "عملیات سریع" }
                    .clickable(onClick = onToggle)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    StayarIcon(
                        name = "plus",
                        tint = colors.onAccent,
                        size = 24.dp,
                        modifier = Modifier.rotate(rotation)
                    )
                }
            }
        }
    }
}

@Composable
fun PeriodLockBanner(onUnlockClick: () -> Unit) {
    val colors = StayarTheme.colors
    Surface(
        color = colors.warn.copy(alpha = 0.16f),
        border = BorderStroke(colors.defaultBorderWidth, colors.warn),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                StayarIcon("lock", tint = colors.warn, size = 18.dp)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "دوره مالی قفل است؛ ثبت، ویرایش و حذف غیرفعال است",
                    fontSize = 12.5.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = colors.text
                )
            }
            OutlinedButton(
                onClick = onUnlockClick,
                border = BorderStroke(colors.defaultBorderWidth, colors.warn),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Text("باز کردن قفل", fontSize = 12.sp, color = colors.text, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun DatabaseErrorBanner(loadError: String) {
    val colors = StayarTheme.colors
    Surface(
        color = colors.danger,
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(
            text = "خواندن پایگاه داده ناموفق بود؛ برای محافظت از اطلاعات، ذخیره‌سازی غیرفعال شد. برنامه را ببندید و دوباره باز کنید. ($loadError)",
            color = Color.White,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(14.dp)
        )
    }
}

@Composable
fun ProjectSwitcherSheet(
    projects: List<ProjectEntity>,
    activeProjectId: String,
    onSelectProject: (String) -> Unit,
    onManageProjects: () -> Unit,
    onDismiss: () -> Unit
) {
    val colors = StayarTheme.colors
    TactileSheet(
        titleFa = "تعویض پروژه",
        onDismissRequest = onDismiss
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            for (proj in projects) {
                val isCurrent = proj.id == activeProjectId
                val isSandbox = proj.id.startsWith("demo_quest_")
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = if (isCurrent) colors.accent else colors.bgElev2,
                    border = BorderStroke(
                        colors.defaultBorderWidth,
                        if (isCurrent) colors.accent else colors.borderStrong
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelectProject(proj.id) }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            StayarIcon(
                                name = if (isCurrent) "check" else "folder",
                                tint = if (isCurrent) colors.onAccent else colors.accent,
                                size = 18.dp
                            )
                            Text(
                                text = proj.name,
                                fontWeight = FontWeight.Bold,
                                color = if (isCurrent) colors.onAccent else colors.text
                            )
                        }
                        if (isSandbox) {
                            BadgePill("تمرینی", colors.warn)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            OutlinedButton(
                onClick = onManageProjects,
                border = BorderStroke(colors.defaultBorderWidth, colors.borderStrong),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
            ) {
                Text("مدیریت پروژه‌ها", color = colors.text, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun AllPagesGridSheet(
    currentPageId: String,
    onSelectPage: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val colors = StayarTheme.colors
    TactileSheet(
        titleFa = "همهٔ بخش‌ها",
        onDismissRequest = onDismiss
    ) {
        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(380.dp)
        ) {
            items(ALL_14_PAGES, key = { it.id }) { page ->
                val selected = page.id == currentPageId
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = if (selected) colors.accent else colors.bgElev2,
                    border = BorderStroke(colors.defaultBorderWidth, colors.borderStrong),
                    modifier = Modifier
                        .height(86.dp)
                        .clickable { onSelectPage(page.id) }
                ) {
                    Column(
                        modifier = Modifier.padding(8.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        StayarIcon(
                            name = page.icon,
                            tint = if (selected) colors.onAccent else colors.accent,
                            size = 26.dp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = page.titleFa,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (selected) colors.onAccent else colors.text,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun BadgePill(
    textFa: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = color.copy(alpha = 0.16f),
        border = BorderStroke(1.dp, color),
        modifier = modifier
    ) {
        Text(
            text = textFa,
            color = color,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
        )
    }
}
