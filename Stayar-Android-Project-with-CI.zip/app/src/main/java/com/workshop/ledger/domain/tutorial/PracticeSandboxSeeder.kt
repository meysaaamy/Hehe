package com.workshop.ledger.domain.tutorial

import com.workshop.ledger.domain.engine.AccountingEngine
import com.workshop.ledger.domain.engine.JalaliCalendarEngine
import com.workshop.ledger.domain.model.AttendanceValue
import com.workshop.ledger.domain.model.Category
import com.workshop.ledger.domain.model.DomainConstants
import com.workshop.ledger.domain.model.Project
import com.workshop.ledger.domain.model.ProjectSettings
import com.workshop.ledger.domain.model.Receipt
import com.workshop.ledger.domain.model.User
import com.workshop.ledger.domain.model.UserType
import com.workshop.ledger.domain.model.Wage
import java.util.Locale
import kotlin.math.abs

object PracticeSandboxSeeder {

    const val MASTER_ME_ID = "u_master_me"
    const val MASTER_PARTNER_ID = "u_master_partner"
    const val APPRENTICE_ALI_ID = "u_apprentice_ali"

    fun seed(todayStr: String = JalaliCalendarEngine.jTodayStr()): Project {
        val now = System.currentTimeMillis()
        val parsedToday = JalaliCalendarEngine.jParse(todayStr) ?: JalaliCalendarEngine.jTodayDate()
        val firstOfMonth = "%04d/%02d/01".format(Locale.US, parsedToday.year, parsedToday.month)
        val rangeStart = JalaliCalendarEngine.jAddDays(todayStr, -5)

        val users = listOf(
            User(
                id = MASTER_ME_ID,
                name = "اوستای اصلی (شما)",
                role = "اوستا",
                type = UserType.MASTER,
                workFactor = 1.0,
                active = true,
                main = true,
                createdAt = now - 30_000L
            ),
            User(
                id = MASTER_PARTNER_ID,
                name = "اوستا کاظم (شریک)",
                role = "اوستا",
                type = UserType.MASTER,
                workFactor = 1.0,
                active = true,
                main = false,
                createdAt = now - 20_000L
            ),
            User(
                id = APPRENTICE_ALI_ID,
                name = "علی (شاگرد)",
                role = "شاگرد",
                type = UserType.APPRENTICE,
                workFactor = 1.0,
                active = true,
                main = false,
                createdAt = now - 10_000L
            )
        )

        val effectiveWageDate = if (firstOfMonth <= rangeStart) firstOfMonth else rangeStart
        val wages = listOf(
            Wage(
                id = "w_ali_init",
                userId = APPRENTICE_ALI_ID,
                rate = 1_000_000L,
                effectiveDate = effectiveWageDate
            )
        )

        val receipts = listOf(
            Receipt(
                id = "r_quest_init",
                dateFrom = todayStr,
                dateTo = todayStr,
                amount = 10_000_000L,
                description = "واریزی مرحله اول کارفرما",
                active = true,
                createdAt = now
            )
        )

        val attendance = LinkedHashMap<String, Map<String, AttendanceValue>>()
        for (i in 5 downTo 1) {
            val d = JalaliCalendarEngine.jAddDays(todayStr, -i)
            attendance[d] = mapOf(
                MASTER_ME_ID to AttendanceValue.Full,
                MASTER_PARTNER_ID to AttendanceValue.Full,
                APPRENTICE_ALI_ID to AttendanceValue.Full
            )
        }

        val categories = listOf(
            Category(id = "cat_q_1", name = "مصالح"),
            Category(id = "cat_q_2", name = "کرایه و حمل"),
            Category(id = "cat_q_3", name = "غذا و پذیرایی"),
            Category(id = "cat_q_4", name = "متفرقه")
        )

        return Project(
            id = "demo_quest_${DomainConstants.uid()}",
            name = "🛠️ کارگاه تمرینی (آموزش زنده)",
            createdAt = now,
            settings = ProjectSettings(
                rangeFrom = rangeStart,
                rangeTo = todayStr,
                overtimeFactor = 1.0,
                absentPenalty = 0.5,
                profitBasis = "commitment",
                locked = false,
                calcVersion = 2
            ),
            users = users,
            wages = wages,
            attendance = attendance,
            receipts = receipts,
            categories = categories
        )
    }

    fun sandboxScenarioOk(project: Project): Boolean {
        val r = AccountingEngine.compute(project)
        val me = r.masters.find { it.id == MASTER_ME_ID } ?: return false
        val partner = r.masters.find { it.id == MASTER_PARTNER_ID } ?: return false
        val ali = r.staff.find { it.id == APPRENTICE_ALI_ID } ?: return false

        return r.totalReceipts == 10_000_000L &&
            r.totalWages == 5_000_000L &&
            abs(r.totalWorkFinal - 10.0) < 1e-6 &&
            abs(me.percent - 0.5) < 1e-6 &&
            abs(partner.percent - 0.5) < 1e-6 &&
            me.share == 2_500_000L &&
            partner.share == 2_500_000L &&
            me.finalBalance == 2_500_000L &&
            partner.finalBalance == 2_500_000L &&
            abs(ali.days - 5.0) < 1e-6 &&
            ali.entitled == 5_000_000L &&
            ali.debt == 5_000_000L &&
            r.profit == 5_000_000L
    }
}
