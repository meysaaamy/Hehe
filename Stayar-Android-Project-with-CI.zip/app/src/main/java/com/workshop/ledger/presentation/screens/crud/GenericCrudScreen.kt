package com.workshop.ledger.presentation.screens.crud

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.workshop.ledger.core.audio.NativePcmSynthesizer
import com.workshop.ledger.core.haptics.RichHapticsManager
import com.workshop.ledger.domain.engine.AccountingEngine
import com.workshop.ledger.domain.engine.JalaliCalendarEngine
import com.workshop.ledger.domain.engine.StatementBuilder
import com.workshop.ledger.domain.engine.TextNormalizer
import com.workshop.ledger.domain.model.AccountingResult
import com.workshop.ledger.domain.model.Adjustment
import com.workshop.ledger.domain.model.Category
import com.workshop.ledger.domain.model.DomainConstants
import com.workshop.ledger.domain.model.Expense
import com.workshop.ledger.domain.model.Payout
import com.workshop.ledger.domain.model.Project
import com.workshop.ledger.domain.model.Receipt
import com.workshop.ledger.domain.model.Transfer
import com.workshop.ledger.domain.model.User
import com.workshop.ledger.domain.model.UserType
import com.workshop.ledger.domain.model.Wage
import com.workshop.ledger.presentation.components.BadgePill
import com.workshop.ledger.presentation.components.JalaliWheelDatePickerSheet
import com.workshop.ledger.presentation.components.TactileSheet
import com.workshop.ledger.presentation.components.WorkshopMoneyFieldWithKeypad
import com.workshop.ledger.presentation.theme.MoneyText
import com.workshop.ledger.presentation.theme.StayarIcon
import com.workshop.ledger.presentation.theme.StayarTheme
import com.workshop.ledger.presentation.tutorial.QuestCoordinator
import com.workshop.ledger.presentation.tutorial.questTarget
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

data class CrudDisplayRow(
    val id: String,
    val titleFa: String,
    val subtitleFa: String,
    val dateFa: String,
    val amount: Long? = null,
    val amountNoteFa: String? = null,
    val isPositiveAmount: Boolean = false,
    val active: Boolean = true,
    val badges: List<Pair<String, androidx.compose.ui.graphics.Color>> = emptyList(),
    val rawItem: Any
)

@Composable
fun GenericCrudScreen(
    config: CrudPageConfig,
    project: Project,
    r: AccountingResult,
    initialFormOpen: Boolean = false,
    preselectedUserId: String? = null,
    onConsumeInitialForm: () -> Unit = {},
    onNavigate: (String) -> Unit,
    onNavigateToWagesWithUser: (userId: String, userName: String) -> Unit,
    onUpsertReceipt: (Receipt) -> Unit,
    onDeleteReceiptWithUndo: (Receipt) -> Unit,
    onUpsertExpense: (Expense) -> Unit,
    onDeleteExpenseWithUndo: (Expense) -> Unit,
    onUpsertPayout: (Payout) -> Unit,
    onDeletePayoutWithUndo: (Payout) -> Unit,
    onUpsertTransfer: (Transfer) -> Unit,
    onDeleteTransferWithUndo: (Transfer) -> Unit,
    onUpsertAdjustment: (Adjustment) -> Unit,
    onDeleteAdjustmentWithUndo: (Adjustment) -> Unit,
    onUpsertWage: (Wage) -> Unit,
    onDeleteWageWithUndo: (Wage) -> Unit,
    onUpsertUser: (User) -> Unit,
    onHardDeleteUser: (User) -> Unit,
    onUpsertCategory: (Category) -> Unit,
    onDeleteCategory: (String) -> Unit,
    onPreconditionError: (messageFa: String, redirectPage: String?) -> Unit,
    synthesizer: NativePcmSynthesizer? = null,
    haptics: RichHapticsManager? = null,
    questCoordinator: QuestCoordinator? = null
) {
    val colors = StayarTheme.colors
    val digitsMode = StayarTheme.digitsMode
    val f = { s: String -> TextNormalizer.formatDisplayDigits(s, digitsMode) }
    val scope = rememberCoroutineScope()

    var searchQuery by remember(config.pageId) { mutableStateOf("") }
    var filterByReportRange by remember(config.pageId) { mutableStateOf(false) }
    var formSheetOpen by remember(config.pageId) { mutableStateOf(false) }
    var editingItem by remember(config.pageId) { mutableStateOf<Any?>(null) }
    var categoryManagerOpen by remember { mutableStateOf(false) }
    var deletingRow by remember { mutableStateOf<CrudDisplayRow?>(null) }
    var deletingUser by remember { mutableStateOf<User?>(null) }

    val liveUsers = remember(project.users) { project.liveUsers() }
    val staffUsers = remember(liveUsers) { liveUsers.filter { it.type != UserType.MASTER } }
    val masterUsers = remember(liveUsers) { liveUsers.filter { it.type == UserType.MASTER } }
    val userMap = remember(liveUsers) { liveUsers.associateBy { it.id } }
    val catMap = remember(project.categories) { project.categories.associateBy { it.id } }

    fun openNewFormWithPreconditionCheck() {
        if (config == CrudPageConfig.Payouts && staffUsers.isEmpty()) {
            onPreconditionError("ابتدا یک شاگرد یا پرسنل در بخش «کاربران» تعریف کنید", "users")
            return
        }
        if (config == CrudPageConfig.Transfers && masterUsers.isEmpty()) {
            onPreconditionError("حداقل یک اوستا لازم است", "users")
            return
        }
        editingItem = null
        formSheetOpen = true
    }

    LaunchedEffect(initialFormOpen) {
        if (initialFormOpen) {
            onConsumeInitialForm()
            openNewFormWithPreconditionCheck()
        }
    }

    // Build rows according to config + range filter + search
    val allRows: List<CrudDisplayRow> = remember(project, r, config, filterByReportRange) {
        val range = r.range
        when (config) {
            CrudPageConfig.Receipts -> {
                project.receipts.filter { rec ->
                    if (!filterByReportRange) true
                    else AccountingEngine.receiptShare(rec, range, project.settings.calcVersion) > 0L ||
                        range.inRange(rec.dateFrom) || range.inRange(rec.dateTo)
                }.map { rec ->
                    val share = AccountingEngine.receiptShare(rec, range, project.settings.calcVersion)
                    val partialNote = if (share != rec.amount && (range.from.isNotEmpty() || range.to.isNotEmpty())) {
                        "سهم بازه: ${TextNormalizer.fmt(share)}"
                    } else null
                    CrudDisplayRow(
                        id = rec.id,
                        titleFa = rec.description.ifBlank { "واریزی کارفرما" },
                        subtitleFa = "از ${rec.dateFrom} تا ${rec.dateTo}",
                        dateFa = rec.dateFrom,
                        amount = if (filterByReportRange) share else rec.amount,
                        amountNoteFa = partialNote,
                        isPositiveAmount = true,
                        active = rec.active,
                        rawItem = rec
                    )
                }
            }
            CrudPageConfig.Expenses -> {
                project.expenses.filter { exp ->
                    !filterByReportRange || range.inRange(exp.date)
                }.map { exp ->
                    val catName = exp.categoryId?.let { catMap[it]?.name }
                    val catBadge = if (catName != null) catName to colors.info else "بدون دسته" to colors.warn
                    val payerBadge = if (exp.payerId == "shared") {
                        "مشترک" to colors.textDim
                    } else {
                        "شخصی: ${userMap[exp.payerId]?.name ?: exp.payerId}" to colors.accent
                    }
                    CrudDisplayRow(
                        id = exp.id,
                        titleFa = exp.description,
                        subtitleFa = exp.date,
                        dateFa = exp.date,
                        amount = exp.amount,
                        isPositiveAmount = false,
                        active = exp.active,
                        badges = listOf(catBadge, payerBadge),
                        rawItem = exp
                    )
                }
            }
            CrudPageConfig.Payouts -> {
                project.payouts.filter { p ->
                    !filterByReportRange || range.inRange(p.date)
                }.map { p ->
                    val u = userMap[p.userId]
                    val uName = u?.name ?: p.userId
                    val uRole = u?.type?.labelFa ?: "شاگرد"
                    CrudDisplayRow(
                        id = p.id,
                        titleFa = uName,
                        subtitleFa = p.description.ifBlank { "پرداخت نقدی" },
                        dateFa = p.date,
                        amount = p.amount,
                        isPositiveAmount = false,
                        active = p.active,
                        badges = listOf(uRole to colors.info),
                        rawItem = p
                    )
                }
            }
            CrudPageConfig.Transfers -> {
                project.transfers.filter { t ->
                    !filterByReportRange || range.inRange(t.date)
                }.map { t ->
                    val isAdv = t.kind == "advance"
                    val fromName = if (isAdv || t.fromId == null) "صندوق" else (userMap[t.fromId]?.name ?: t.fromId)
                    val toName = userMap[t.toId]?.name ?: t.toId
                    val kindBadge = if (isAdv) "پیش‌برداشت" to colors.warn else "انتقال" to colors.info
                    CrudDisplayRow(
                        id = t.id,
                        titleFa = "$fromName ← $toName",
                        subtitleFa = t.description.ifBlank { if (isAdv) "پیش‌برداشت از صندوق" else "انتقال بین دو اوستا" },
                        dateFa = t.date,
                        amount = t.amount,
                        isPositiveAmount = false,
                        active = t.active,
                        badges = listOf(kindBadge),
                        rawItem = t
                    )
                }
            }
            CrudPageConfig.Adjustments -> {
                project.adjustments.filter { a ->
                    !filterByReportRange || range.inRange(a.date)
                }.map { a ->
                    val uName = userMap[a.userId]?.name ?: a.userId
                    val kindLabel = DomainConstants.KIND_FA[a.kind] ?: a.kind
                    val badgeColor = when (a.kind) {
                        "penalty" -> colors.danger
                        "bonus" -> colors.success
                        else -> colors.info
                    }
                    CrudDisplayRow(
                        id = a.id,
                        titleFa = uName,
                        subtitleFa = a.description.ifBlank { kindLabel },
                        dateFa = a.date,
                        amount = a.amount,
                        isPositiveAmount = a.kind != "penalty",
                        active = a.active,
                        badges = listOf(kindLabel to badgeColor),
                        rawItem = a
                    )
                }
            }
            CrudPageConfig.Wages -> {
                project.wages.sortedByDescending { it.effectiveDate }.map { w ->
                    val uName = userMap[w.userId]?.name ?: w.userId
                    CrudDisplayRow(
                        id = w.id,
                        titleFa = uName,
                        subtitleFa = "معتبر از ${w.effectiveDate}",
                        dateFa = w.effectiveDate,
                        amount = w.rate,
                        isPositiveAmount = true,
                        active = true,
                        rawItem = w
                    )
                }
            }
            CrudPageConfig.Users -> {
                liveUsers.map { u ->
                    val bList = mutableListOf<Pair<String, androidx.compose.ui.graphics.Color>>()
                    if (u.main) bList.add("اصلی" to colors.success)
                    bList.add(u.type.labelFa to colors.info)
                    if (u.type == UserType.MASTER) {
                        bList.add("ضریب ${TextNormalizer.fmtDays(u.workFactor)}" to colors.accent)
                    }
                    bList.add((if (u.active) "فعال" else "غیرفعال") to (if (u.active) colors.success else colors.textDim))

                    CrudDisplayRow(
                        id = u.id,
                        titleFa = u.name,
                        subtitleFa = u.effectiveRole,
                        dateFa = "",
                        amount = null,
                        active = u.active,
                        badges = bList,
                        rawItem = u
                    )
                }
            }
        }
    }

    val filteredRows = remember(allRows, searchQuery) {
        if (searchQuery.isBlank()) {
            allRows
        } else {
            val q = TextNormalizer.srchNorm(searchQuery)
            allRows.filter { row ->
                val combined = "${row.titleFa} ${row.subtitleFa} ${row.dateFa} ${row.amount ?: ""}"
                TextNormalizer.srchNorm(combined).contains(q)
            }
        }
    }

    // Active Staff without any wage warning banner for Wages screen
    val staffWithoutWageNames = remember(config, staffUsers, project.wages) {
        if (config != CrudPageConfig.Wages) emptyList()
        else staffUsers.filter { u ->
            u.active && project.wages.none { it.userId == u.id }
        }.map { it.name }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(10.dp))

        // Intro Card
        Surface(
            shape = RoundedCornerShape(14.dp),
            color = colors.bgElev,
            border = BorderStroke(colors.defaultBorderWidth, colors.border),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = config.introFa,
                fontSize = 12.5.sp,
                color = colors.textDim,
                modifier = Modifier.padding(12.dp)
            )
        }

        // Warn banner on Wages page when active staff have no wage
        if (staffWithoutWageNames.isNotEmpty()) {
            Spacer(modifier = Modifier.height(8.dp))
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = colors.warn.copy(alpha = 0.16f),
                border = BorderStroke(1.dp, colors.warn),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "برای این افراد هنوز نرخ ثبت نشده: ${staffWithoutWageNames.joinToString(" ،")}",
                    fontSize = 12.5.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.text,
                    modifier = Modifier.padding(10.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Top Action Bar: Search + Range Toggle + Extra Button + Add Button
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("جستجو...") },
                singleLine = true,
                modifier = Modifier.weight(1f)
            )

            if (config.hasRangeToggle) {
                OutlinedButton(
                    onClick = { filterByReportRange = !filterByReportRange },
                    border = BorderStroke(
                        colors.defaultBorderWidth,
                        if (filterByReportRange) colors.accent else colors.borderStrong
                    )
                ) {
                    Text(
                        text = if (filterByReportRange) "نمایش همه ثبت‌ها" else "فقط بازه گزارش",
                        fontSize = 11.5.sp,
                        color = if (filterByReportRange) colors.accent else colors.text,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            if (config.extraBtnFa != null) {
                OutlinedButton(
                    onClick = { categoryManagerOpen = true },
                    border = BorderStroke(colors.defaultBorderWidth, colors.borderStrong)
                ) {
                    Text(config.extraBtnFa, fontSize = 12.sp, color = colors.text, fontWeight = FontWeight.Bold)
                }
            }

            Button(
                onClick = ::openNewFormWithPreconditionCheck,
                colors = ButtonDefaults.buttonColors(containerColor = colors.accent),
                modifier = Modifier
                    .height(52.dp)
                    .questTarget("crud_add_${config.pageId}", questCoordinator)
            ) {
                StayarIcon("plus", tint = colors.onAccent, size = 16.dp)
                Spacer(modifier = Modifier.width(6.dp))
                Text(config.addBtnFa, color = colors.onAccent, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // List or Empty State
        if (filteredRows.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    val emptyTitle = if (searchQuery.isNotBlank()) "موردی پیدا نشد" else "هنوز چیزی ثبت نشده"
                    val emptySub = if (searchQuery.isNotBlank()) {
                        "عبارت جستجو را تغییر دهید."
                    } else {
                        "با دکمهٔ «${config.addBtnFa}» شروع کنید."
                    }
                    Text(emptyTitle, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = colors.text)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(emptySub, fontSize = 13.sp, color = colors.textDim)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filteredRows, key = { it.id }) { row ->
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = colors.bgElev,
                        border = BorderStroke(colors.defaultBorderWidth, colors.borderStrong),
                        modifier = Modifier
                            .fillMaxWidth()
                            .alpha(if (row.active) 1f else 0.62f)
                            .clickable {
                                editingItem = row.rawItem
                                formSheetOpen = true
                            }
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text(
                                            text = row.titleFa,
                                            fontSize = 15.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = colors.text
                                        )
                                        if (!row.active && config != CrudPageConfig.Users) {
                                            BadgePill("غیرفعال", colors.textDim)
                                        }
                                    }
                                    Text(
                                        text = f(row.subtitleFa),
                                        fontSize = 12.5.sp,
                                        color = colors.textDim
                                    )
                                }

                                if (row.amount != null) {
                                    Column(horizontalAlignment = Alignment.End) {
                                        MoneyText(
                                            amount = row.amount,
                                            showUnit = true,
                                            fontSize = 15.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = if (row.isPositiveAmount) colors.success else colors.danger
                                        )
                                        if (row.amountNoteFa != null) {
                                            Text(
                                                text = f(row.amountNoteFa),
                                                fontSize = 11.sp,
                                                color = colors.accent,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    if (row.dateFa.isNotEmpty()) {
                                        Text(f(row.dateFa), fontSize = 11.5.sp, color = colors.textDim)
                                    }
                                    for ((bText, bColor) in row.badges) {
                                        BadgePill(f(bText), bColor)
                                    }
                                }

                                val isProtectedMainMaster = (row.rawItem as? User)?.main == true
                                if (!isProtectedMainMaster) {
                                    OutlinedButton(
                                        onClick = {
                                            if (row.rawItem is User) {
                                                deletingUser = row.rawItem
                                            } else {
                                                deletingRow = row
                                            }
                                        },
                                        border = BorderStroke(1.dp, colors.danger)
                                    ) {
                                        Text("حذف", fontSize = 11.5.sp, color = colors.danger, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Footer Totals (applies to receipts, expenses, payouts)
        if (config.hasFooterTotal) {
            val activeRows = filteredRows.filter { it.active }
            val activeCount = activeRows.size
            val totalAmount = activeRows.sumOf { it.amount ?: 0L }
            val rangeText = StatementBuilder.rangeTextFa(r.range, digitsMode)
            val footerLabel = if (!filterByReportRange) {
                f("جمع $activeCount مورد فعال (همهٔ ثبت‌ها، بدون توجه به بازهٔ گزارش)")
            } else {
                val propNote = if (config == CrudPageConfig.Receipts) "؛ سهم متناسب با روزهای داخل بازه" else ""
                f("جمع $activeCount مورد فعال (فقط بازه $rangeText$propNote)")
            }

            Surface(
                shape = RoundedCornerShape(12.dp),
                color = colors.bgElev2,
                border = BorderStroke(colors.defaultBorderWidth, colors.borderStrong),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = footerLabel,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = colors.text,
                        modifier = Modifier.weight(1f)
                    )
                    MoneyText(
                        amount = totalAmount,
                        showUnit = true,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = colors.accent
                    )
                }
            }
        }
    }

    // Form Bottom Sheet
    if (formSheetOpen) {
        CrudFormSheet(
            config = config,
            project = project,
            editingItem = editingItem,
            preselectedUserId = preselectedUserId,
            onSave = { savedObj, saveAndAddAnother ->
                haptics?.save()
                when (savedObj) {
                    is Receipt -> onUpsertReceipt(savedObj)
                    is Expense -> onUpsertExpense(savedObj)
                    is Payout -> onUpsertPayout(savedObj)
                    is Transfer -> onUpsertTransfer(savedObj)
                    is Adjustment -> onUpsertAdjustment(savedObj)
                    is Wage -> onUpsertWage(savedObj)
                    is User -> {
                        val isNewUser = editingItem == null
                        onUpsertUser(savedObj)
                        // Outside tutorial: creating a non-master user opens wage form after 350 ms if no wage exists
                        if (isNewUser && savedObj.type != UserType.MASTER && !project.isSandbox) {
                            val hasWage = project.wages.any { it.userId == savedObj.id }
                            if (!hasWage) {
                                scope.launch {
                                    delay(350L)
                                    onNavigateToWagesWithUser(savedObj.id, savedObj.name)
                                }
                            }
                        }
                    }
                }
                formSheetOpen = false
                if (saveAndAddAnother) {
                    scope.launch {
                        delay(380L)
                        editingItem = null
                        formSheetOpen = true
                    }
                }
            },
            onDismiss = { formSheetOpen = false },
            synthesizer = synthesizer,
            haptics = haptics
        )
    }

    // Category Manager Sheet
    if (categoryManagerOpen) {
        CategoryManagerSheet(
            categories = project.categories,
            expenses = project.expenses,
            onUpsertCategory = onUpsertCategory,
            onDeleteCategory = onDeleteCategory,
            onDismiss = { categoryManagerOpen = false }
        )
    }

    // Standard Record Delete Confirmation Dialog (with 8s Undo)
    if (deletingRow != null) {
        val row = deletingRow!!
        AlertDialog(
            onDismissRequest = { deletingRow = null },
            containerColor = colors.bgElev,
            title = {
                Text("حذف ${config.singleFa}", fontWeight = FontWeight.Bold, color = colors.text)
            },
            text = {
                Text("این ${config.singleFa} برای همیشه حذف می‌شود.", color = colors.text)
            },
            confirmButton = {
                Button(
                    onClick = {
                        haptics?.confirm(15L)
                        val item = row.rawItem
                        deletingRow = null
                        when (item) {
                            is Receipt -> onDeleteReceiptWithUndo(item)
                            is Expense -> onDeleteExpenseWithUndo(item)
                            is Payout -> onDeletePayoutWithUndo(item)
                            is Transfer -> onDeleteTransferWithUndo(item)
                            is Adjustment -> onDeleteAdjustmentWithUndo(item)
                            is Wage -> onDeleteWageWithUndo(item)
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = colors.danger)
                ) {
                    Text("حذف", color = colors.onAccent, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { deletingRow = null }) {
                    Text("انصراف", color = colors.text)
                }
            }
        )
    }

    // User Delete Sheet
    if (deletingUser != null) {
        UserDeleteSheet(
            project = project,
            accountingResult = r,
            user = deletingUser!!,
            onDeactivateUser = { u ->
                onUpsertUser(u.copy(active = false))
            },
            onConfirmHardDelete = { u ->
                onHardDeleteUser(u)
            },
            onDismiss = { deletingUser = null }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun CrudFormSheet(
    config: CrudPageConfig,
    project: Project,
    editingItem: Any?,
    preselectedUserId: String?,
    onSave: (savedObj: Any, saveAndAddAnother: Boolean) -> Unit,
    onDismiss: () -> Unit,
    synthesizer: NativePcmSynthesizer?,
    haptics: RichHapticsManager?
) {
    val colors = StayarTheme.colors
    val todayStr = remember { JalaliCalendarEngine.jTodayStr() }
    val liveUsers = remember(project.users) { project.liveUsers() }
    val staffUsers = remember(liveUsers) { liveUsers.filter { it.type != UserType.MASTER } }
    val masterUsers = remember(liveUsers) { liveUsers.filter { it.type == UserType.MASTER } }

    // Shared form state fields
    var date by remember(editingItem) {
        mutableStateOf(
            when (editingItem) {
                is Expense -> editingItem.date
                is Payout -> editingItem.date
                is Transfer -> editingItem.date
                is Adjustment -> editingItem.date
                is Wage -> editingItem.effectiveDate
                else -> todayStr
            }
        )
    }
    var dateFrom by remember(editingItem) {
        mutableStateOf((editingItem as? Receipt)?.dateFrom ?: todayStr)
    }
    var dateTo by remember(editingItem) {
        mutableStateOf((editingItem as? Receipt)?.dateTo ?: todayStr)
    }
    var amount by remember(editingItem) {
        mutableLongStateOf(
            when (editingItem) {
                is Receipt -> editingItem.amount
                is Expense -> editingItem.amount
                is Payout -> editingItem.amount
                is Transfer -> editingItem.amount
                is Adjustment -> editingItem.amount
                is Wage -> editingItem.rate
                else -> 0L
            }
        )
    }
    var description by remember(editingItem) {
        mutableStateOf(
            when (editingItem) {
                is Receipt -> editingItem.description
                is Expense -> editingItem.description
                is Payout -> editingItem.description
                is Transfer -> editingItem.description
                is Adjustment -> editingItem.description
                else -> ""
            }
        )
    }
    var categoryId by remember(editingItem) {
        mutableStateOf((editingItem as? Expense)?.categoryId ?: project.categories.firstOrNull()?.id)
    }
    var payerId by remember(editingItem) {
        mutableStateOf((editingItem as? Expense)?.payerId ?: "shared")
    }
    var userId by remember(editingItem, preselectedUserId) {
        mutableStateOf(
            when (editingItem) {
                is Payout -> editingItem.userId
                is Adjustment -> editingItem.userId
                is Wage -> editingItem.userId
                else -> preselectedUserId ?: when (config) {
                    CrudPageConfig.Payouts, CrudPageConfig.Wages -> staffUsers.firstOrNull()?.id.orEmpty()
                    else -> liveUsers.firstOrNull()?.id.orEmpty()
                }
            }
        )
    }
    var transferKind by remember(editingItem) {
        mutableStateOf((editingItem as? Transfer)?.kind ?: "peer")
    }
    var fromId by remember(editingItem) {
        mutableStateOf((editingItem as? Transfer)?.fromId ?: masterUsers.firstOrNull()?.id)
    }
    var toId by remember(editingItem) {
        mutableStateOf(
            (editingItem as? Transfer)?.toId
                ?: masterUsers.getOrElse(1) { masterUsers.firstOrNull() }?.id.orEmpty()
        )
    }
    var adjustmentKind by remember(editingItem) {
        mutableStateOf((editingItem as? Adjustment)?.kind ?: "bonus")
    }

    // User form fields
    var userName by remember(editingItem) {
        mutableStateOf((editingItem as? User)?.name ?: "")
    }
    var userType by remember(editingItem) {
        mutableStateOf((editingItem as? User)?.type ?: UserType.APPRENTICE)
    }
    var userRole by remember(editingItem) {
        mutableStateOf((editingItem as? User)?.role ?: "")
    }
    var workFactorStr by remember(editingItem) {
        mutableStateOf(TextNormalizer.fmtDays((editingItem as? User)?.workFactor ?: 1.0))
    }

    var activeFlag by remember(editingItem) {
        mutableStateOf(
            when (editingItem) {
                is Receipt -> editingItem.active
                is Expense -> editingItem.active
                is Payout -> editingItem.active
                is Transfer -> editingItem.active
                is Adjustment -> editingItem.active
                is User -> editingItem.active
                else -> true
            }
        )
    }

    var datePickerField by remember { mutableStateOf<String?>(null) } // "date" | "dateFrom" | "dateTo"

    val sheetTitle = if (editingItem == null) config.addBtnFa else "ویرایش ${config.singleFa}"

    fun buildAndSubmit(saveAndAddAnother: Boolean) {
        val now = System.currentTimeMillis()
        when (config) {
            CrudPageConfig.Receipts -> {
                val obj = Receipt(
                    id = (editingItem as? Receipt)?.id ?: "rec_${DomainConstants.uid()}",
                    dateFrom = dateFrom,
                    dateTo = dateTo,
                    amount = amount,
                    description = description.trim().take(200),
                    active = activeFlag,
                    createdAt = (editingItem as? Receipt)?.createdAt ?: now,
                    updatedAt = now
                )
                onSave(obj, saveAndAddAnother)
            }
            CrudPageConfig.Expenses -> {
                val obj = Expense(
                    id = (editingItem as? Expense)?.id ?: "exp_${DomainConstants.uid()}",
                    date = date,
                    amount = amount,
                    description = description.trim().take(200),
                    categoryId = categoryId,
                    payerId = payerId,
                    active = activeFlag,
                    createdAt = (editingItem as? Expense)?.createdAt ?: now,
                    updatedAt = now
                )
                onSave(obj, saveAndAddAnother)
            }
            CrudPageConfig.Payouts -> {
                val obj = Payout(
                    id = (editingItem as? Payout)?.id ?: "pay_${DomainConstants.uid()}",
                    date = date,
                    userId = userId,
                    amount = amount,
                    description = description.trim().take(200),
                    active = activeFlag,
                    createdAt = (editingItem as? Payout)?.createdAt ?: now,
                    updatedAt = now
                )
                onSave(obj, saveAndAddAnother)
            }
            CrudPageConfig.Transfers -> {
                val obj = Transfer(
                    id = (editingItem as? Transfer)?.id ?: "tr_${DomainConstants.uid()}",
                    date = date,
                    kind = transferKind,
                    fromId = if (transferKind == "peer") fromId else null,
                    toId = toId,
                    amount = amount,
                    description = description.trim().take(200),
                    active = activeFlag,
                    createdAt = (editingItem as? Transfer)?.createdAt ?: now,
                    updatedAt = now
                )
                onSave(obj, saveAndAddAnother)
            }
            CrudPageConfig.Adjustments -> {
                val obj = Adjustment(
                    id = (editingItem as? Adjustment)?.id ?: "adj_${DomainConstants.uid()}",
                    date = date,
                    userId = userId,
                    kind = adjustmentKind,
                    amount = amount,
                    description = description.trim().take(200),
                    active = activeFlag,
                    createdAt = (editingItem as? Adjustment)?.createdAt ?: now,
                    updatedAt = now
                )
                onSave(obj, saveAndAddAnother)
            }
            CrudPageConfig.Wages -> {
                val obj = Wage(
                    id = (editingItem as? Wage)?.id ?: "w_${DomainConstants.uid()}",
                    userId = userId,
                    rate = amount,
                    effectiveDate = date
                )
                onSave(obj, false)
            }
            CrudPageConfig.Users -> {
                val wf = TextNormalizer.fa2en(workFactorStr).toDoubleOrNull()?.coerceIn(0.0, 100.0) ?: 1.0
                val obj = User(
                    id = (editingItem as? User)?.id ?: "u_${DomainConstants.uid()}",
                    name = userName.trim().take(60),
                    role = userRole.trim().take(40),
                    type = userType,
                    workFactor = if (userType == UserType.MASTER) wf else 1.0,
                    active = activeFlag,
                    main = (editingItem as? User)?.main ?: false,
                    createdAt = (editingItem as? User)?.createdAt ?: now
                )
                onSave(obj, false)
            }
        }
    }

    TactileSheet(
        titleFa = sheetTitle,
        onDismissRequest = onDismiss
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            when (config) {
                CrudPageConfig.Receipts -> {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        DateFieldButton("از تاریخ", dateFrom, { datePickerField = "dateFrom" }, Modifier.weight(1f))
                        DateFieldButton("تا تاریخ", dateTo, { datePickerField = "dateTo" }, Modifier.weight(1f))
                    }
                    WorkshopMoneyFieldWithKeypad(
                        labelFa = "مبلغ (تومان)",
                        amountTomans = amount,
                        onAmountChange = { amount = it },
                        onTick = { synthesizer?.tick() }
                    )
                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it.take(200) },
                        label = { Text("توضیحات") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                CrudPageConfig.Expenses -> {
                    DateFieldButton("تاریخ", date, { datePickerField = "date" }, Modifier.fillMaxWidth())
                    WorkshopMoneyFieldWithKeypad(
                        labelFa = "مبلغ (تومان)",
                        amountTomans = amount,
                        onAmountChange = { amount = it },
                        onTick = { synthesizer?.tick() }
                    )
                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it.take(200) },
                        label = { Text("شرح هزینه") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text("دسته‌بندی", fontSize = 13.sp, color = colors.textDim, fontWeight = FontWeight.SemiBold)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        ChoiceChip("— بدون دسته —", categoryId == null) { categoryId = null }
                        for (c in project.categories) {
                            ChoiceChip(c.name, categoryId == c.id) { categoryId = c.id }
                        }
                    }
                    Text("پرداخت‌کننده", fontSize = 13.sp, color = colors.textDim, fontWeight = FontWeight.SemiBold)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        ChoiceChip("صندوق مشترک کارگاه", payerId == "shared") { payerId = "shared" }
                        for (m in masterUsers) {
                            ChoiceChip("شخصی: ${m.name}", payerId == m.id) { payerId = m.id }
                        }
                    }
                }

                CrudPageConfig.Payouts -> {
                    DateFieldButton("تاریخ", date, { datePickerField = "date" }, Modifier.fillMaxWidth())
                    Text("دریافت‌کننده", fontSize = 13.sp, color = colors.textDim, fontWeight = FontWeight.SemiBold)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        for (s in staffUsers) {
                            ChoiceChip("${s.name} (${s.type.labelFa})", userId == s.id) { userId = s.id }
                        }
                    }
                    WorkshopMoneyFieldWithKeypad(
                        labelFa = "مبلغ (تومان)",
                        amountTomans = amount,
                        onAmountChange = { amount = it },
                        onTick = { synthesizer?.tick() }
                    )
                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it.take(200) },
                        label = { Text("توضیحات") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                CrudPageConfig.Transfers -> {
                    DateFieldButton("تاریخ", date, { datePickerField = "date" }, Modifier.fillMaxWidth())
                    Text("نوع", fontSize = 13.sp, color = colors.textDim, fontWeight = FontWeight.SemiBold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ChoiceChip("انتقال بین دو اوستا", transferKind == "peer") { transferKind = "peer" }
                        ChoiceChip("پیش‌برداشت از کار (صندوق)", transferKind == "advance") { transferKind = "advance" }
                    }
                    if (transferKind == "peer") {
                        Text("پرداخت‌کننده (اوستا)", fontSize = 13.sp, color = colors.textDim, fontWeight = FontWeight.SemiBold)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            for (m in masterUsers) {
                                ChoiceChip(m.name, fromId == m.id) { fromId = m.id }
                            }
                        }
                    }
                    Text("دریافت‌کننده (اوستا)", fontSize = 13.sp, color = colors.textDim, fontWeight = FontWeight.SemiBold)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        for (m in masterUsers) {
                            ChoiceChip(m.name, toId == m.id) { toId = m.id }
                        }
                    }
                    WorkshopMoneyFieldWithKeypad(
                        labelFa = "مبلغ (تومان)",
                        amountTomans = amount,
                        onAmountChange = { amount = it },
                        onTick = { synthesizer?.tick() }
                    )
                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it.take(200) },
                        label = { Text("توضیحات") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                CrudPageConfig.Adjustments -> {
                    DateFieldButton("تاریخ", date, { datePickerField = "date" }, Modifier.fillMaxWidth())
                    Text("شخص", fontSize = 13.sp, color = colors.textDim, fontWeight = FontWeight.SemiBold)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        for (u in liveUsers) {
                            ChoiceChip(u.name, userId == u.id) { userId = u.id }
                        }
                    }
                    Text("نوع", fontSize = 13.sp, color = colors.textDim, fontWeight = FontWeight.SemiBold)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        ChoiceChip("پاداش", adjustmentKind == "bonus") { adjustmentKind = "bonus" }
                        ChoiceChip("جریمه", adjustmentKind == "penalty") { adjustmentKind = "penalty" }
                        ChoiceChip("مساعده (نقد فوری)", adjustmentKind == "assistance") { adjustmentKind = "assistance" }
                        ChoiceChip("تسویه نقدی (فقط اوستا)", adjustmentKind == "settle") { adjustmentKind = "settle" }
                    }
                    WorkshopMoneyFieldWithKeypad(
                        labelFa = "مبلغ (تومان)",
                        amountTomans = amount,
                        onAmountChange = { amount = it },
                        onTick = { synthesizer?.tick() }
                    )
                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it.take(200) },
                        label = { Text("توضیحات") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                CrudPageConfig.Wages -> {
                    Text("شاگرد / پرسنل", fontSize = 13.sp, color = colors.textDim, fontWeight = FontWeight.SemiBold)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        for (s in staffUsers) {
                            ChoiceChip(s.name, userId == s.id) { userId = s.id }
                        }
                    }
                    WorkshopMoneyFieldWithKeypad(
                        labelFa = "دستمزد روزانه (تومان)",
                        amountTomans = amount,
                        onAmountChange = { amount = it },
                        onTick = { synthesizer?.tick() }
                    )
                    DateFieldButton("تاریخ شروع اعتبار", date, { datePickerField = "date" }, Modifier.fillMaxWidth())
                }

                CrudPageConfig.Users -> {
                    OutlinedTextField(
                        value = userName,
                        onValueChange = { userName = it.take(60) },
                        label = { Text("نام") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    val isMainMaster = (editingItem as? User)?.main == true
                    if (!isMainMaster) {
                        Text("نوع", fontSize = 13.sp, color = colors.textDim, fontWeight = FontWeight.SemiBold)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            ChoiceChip("اوستا (شریک در سود)", userType == UserType.MASTER) { userType = UserType.MASTER }
                            ChoiceChip("شاگرد", userType == UserType.APPRENTICE) { userType = UserType.APPRENTICE }
                            ChoiceChip("پرسنل سایر", userType == UserType.CUSTOM) { userType = UserType.CUSTOM }
                        }
                    }
                    OutlinedTextField(
                        value = userRole,
                        onValueChange = { userRole = it.take(40) },
                        label = { Text("نقش / عنوان") },
                        placeholder = { Text("مثلاً کارگر ساده") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (userType == UserType.MASTER) {
                        OutlinedTextField(
                            value = workFactorStr,
                            onValueChange = { workFactorStr = it },
                            label = { Text("ضریب کارکرد اوستا") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            if (config.hasActiveFlag) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { activeFlag = !activeFlag }
                ) {
                    Checkbox(checked = activeFlag, onCheckedChange = { activeFlag = it })
                    Text(
                        text = if (config == CrudPageConfig.Users) "فعال" else "فعال در محاسبات",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = colors.text
                    )
                }
            }

            HorizontalDivider(color = colors.border)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (config.hasSaveAndAddAnother && editingItem == null) {
                    OutlinedButton(
                        onClick = { buildAndSubmit(saveAndAddAnother = true) },
                        border = BorderStroke(colors.defaultBorderWidth, colors.accent),
                        modifier = Modifier
                            .weight(1.1f)
                            .height(50.dp)
                    ) {
                        Text("ذخیره و ثبت بعدی", color = colors.accent, fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
                    }
                }
                Button(
                    onClick = { buildAndSubmit(saveAndAddAnother = false) },
                    colors = ButtonDefaults.buttonColors(containerColor = colors.accent),
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp)
                ) {
                    Text("ذخیره", color = colors.onAccent, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
            }
        }
    }

    if (datePickerField != null) {
        val currentVal = when (datePickerField) {
            "dateFrom" -> dateFrom
            "dateTo" -> dateTo
            else -> date
        }
        JalaliWheelDatePickerSheet(
            initialDateStr = currentVal,
            onDateSelected = { picked ->
                when (datePickerField) {
                    "dateFrom" -> dateFrom = picked
                    "dateTo" -> dateTo = picked
                    else -> date = picked
                }
            },
            onDismiss = { datePickerField = null },
            synthesizer = synthesizer,
            haptics = haptics
        )
    }
}

@Composable
private fun DateFieldButton(
    labelFa: String,
    dateStr: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = StayarTheme.colors
    val digitsMode = StayarTheme.digitsMode
    val f = { s: String -> TextNormalizer.formatDisplayDigits(s, digitsMode) }

    Column(modifier = modifier) {
        Text(labelFa, fontSize = 12.5.sp, color = colors.textDim, fontWeight = FontWeight.SemiBold)
        Spacer(modifier = Modifier.height(4.dp))
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = colors.bgElev2,
            border = BorderStroke(colors.defaultBorderWidth, colors.borderStrong),
            modifier = Modifier
                .fillMaxWidth()
                .clickable(onClick = onClick)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(f(dateStr), fontSize = 14.sp, fontWeight = FontWeight.Bold, color = colors.text)
                StayarIcon("calendar", tint = colors.accent, size = 16.dp)
            }
        }
    }
}

@Composable
private fun ChoiceChip(
    labelFa: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    val colors = StayarTheme.colors
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = if (selected) colors.accent else colors.bgElev2,
        border = BorderStroke(colors.defaultBorderWidth, if (selected) colors.accent else colors.borderStrong),
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Text(
            text = labelFa,
            fontSize = 12.5.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            color = if (selected) colors.onAccent else colors.text,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
        )
    }
}
