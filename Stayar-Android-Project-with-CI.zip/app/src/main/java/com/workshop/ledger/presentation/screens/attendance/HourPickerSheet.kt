package com.workshop.ledger.presentation.screens.attendance

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.workshop.ledger.core.audio.NativePcmSynthesizer
import com.workshop.ledger.core.haptics.RichHapticsManager
import com.workshop.ledger.domain.engine.AccountingEngine
import com.workshop.ledger.domain.engine.TextNormalizer
import com.workshop.ledger.domain.model.AttendanceValue
import com.workshop.ledger.presentation.components.BadgePill
import com.workshop.ledger.presentation.components.TactileSheet
import com.workshop.ledger.presentation.theme.StayarTheme
import kotlin.math.roundToInt

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HourPickerSheet(
    personName: String,
    initialHours: Double = 8.0,
    overtimeFactor: Double = 1.0,
    onConfirmHours: (Double) -> Unit,
    onDismiss: () -> Unit,
    synthesizer: NativePcmSynthesizer? = null,
    haptics: RichHapticsManager? = null
) {
    val colors = StayarTheme.colors
    val view = LocalView.current
    var hours by remember { mutableDoubleStateOf(initialHours.coerceIn(0.5, 24.0)) }

    fun updateHours(newHours: Double) {
        val snapped = ((newHours * 2.0).roundToInt() / 2.0).coerceIn(0.5, 24.0)
        if (snapped != hours) {
            hours = snapped
            haptics?.clockTick(view)
            synthesizer?.hourSliderTick(snapped)
        }
    }

    val equivDays = AccountingEngine.attFraction(AttendanceValue.Hourly(hours), overtimeFactor) ?: 0.0
    val hoursFa = TextNormalizer.hrFa(hours)
    val factorFa = TextNormalizer.hrFa(overtimeFactor)
    val equivFa = TextNormalizer.hrFa(equivDays)

    TactileSheet(
        titleFa = "ثبت ساعت کارکرد — $personName",
        onDismissRequest = onDismiss
    ) {
        Text(
            text = "ساعت کار پایه ۸ ساعت است؛ ساعت‌های بیشتر با ضریب اضافه‌کار ($factorFa) حساب می‌شود.",
            fontSize = 12.5.sp,
            color = colors.textDim
        )
        Spacer(modifier = Modifier.height(12.dp))

        HourPickerControlsContent(
            hours = hours,
            hoursFa = hoursFa,
            equivFa = equivFa,
            onUpdateHours = ::updateHours,
            onConfirm = {
                onConfirmHours(hours)
                onDismiss()
            }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HourPickerControlsContent(
    hours: Double,
    hoursFa: String,
    equivFa: String,
    onUpdateHours: (Double) -> Unit,
    onConfirm: () -> Unit
) {
    val colors = StayarTheme.colors

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "ثبت ساعتی: $hoursFa ساعت",
            fontSize = 16.sp,
            fontWeight = FontWeight.ExtraBold,
            color = colors.text
        )
        BadgePill(textFa = "معادل $equivFa روز", color = colors.info)
    }

    Spacer(modifier = Modifier.height(10.dp))

    // Workshop Quick Presets Row: 5 tactile chips
    val presets = listOf(
        6.0 to "۶ ساعت",
        8.0 to "۸ ساعت",
        9.0 to "۹ ساعت (۱س اضافه‌کار)",
        10.0 to "۱۰ ساعت (۲س اضافه‌کار)",
        12.0 to "۱۲ ساعت"
    )
    FlowRow(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        for ((presetH, label) in presets) {
            val active = hours == presetH
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = if (active) colors.accent else colors.bgElev2,
                border = BorderStroke(colors.defaultBorderWidth, if (active) colors.accent else colors.borderStrong),
                modifier = Modifier.clickable { onUpdateHours(presetH) }
            ) {
                Text(
                    text = label,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (active) colors.onAccent else colors.text,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                )
            }
        }
    }

    Spacer(modifier = Modifier.height(12.dp))

    // RTL Range Slider 0.5..24 step 0.5 (46 steps between 0.5 and 24.0)
    Slider(
        value = hours.toFloat(),
        onValueChange = { onUpdateHours(it.toDouble()) },
        valueRange = 0.5f..24f,
        steps = 46,
        colors = SliderDefaults.colors(
            thumbColor = colors.accent,
            activeTrackColor = colors.accent,
            inactiveTrackColor = colors.borderStrong
        ),
        modifier = Modifier
            .fillMaxWidth()
            .semantics { contentDescription = "ساعت کارکرد" }
    )

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        OutlinedButton(
            onClick = { onUpdateHours(hours - 0.5) },
            border = BorderStroke(colors.defaultBorderWidth, colors.borderStrong),
            modifier = Modifier
                .weight(1f)
                .height(48.dp)
        ) {
            Text("− نیم ساعت", color = colors.text, fontWeight = FontWeight.Bold)
        }
        OutlinedButton(
            onClick = { onUpdateHours(hours + 0.5) },
            border = BorderStroke(colors.defaultBorderWidth, colors.borderStrong),
            modifier = Modifier
                .weight(1f)
                .height(48.dp)
        ) {
            Text("+ نیم ساعت", color = colors.text, fontWeight = FontWeight.Bold)
        }
    }

    Spacer(modifier = Modifier.height(14.dp))

    Button(
        onClick = onConfirm,
        colors = ButtonDefaults.buttonColors(containerColor = colors.accent),
        modifier = Modifier
            .fillMaxWidth()
            .height(52.dp)
    ) {
        Text(
            text = "ثبت $hoursFa ساعت",
            color = colors.onAccent,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold
        )
    }
}
