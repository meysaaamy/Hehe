package com.workshop.ledger.presentation.screens.attendance

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.workshop.ledger.core.audio.NativePcmSynthesizer
import com.workshop.ledger.core.haptics.RichHapticsManager
import com.workshop.ledger.data.local.datastore.AttendanceViewMode
import com.workshop.ledger.domain.engine.AccountingEngine
import com.workshop.ledger.domain.engine.JalaliCalendarEngine
import com.workshop.ledger.domain.engine.TextNormalizer
import com.workshop.ledger.domain.model.AttendanceValue
import com.workshop.ledger.domain.model.Project
import com.workshop.ledger.domain.model.User
import com.workshop.ledger.domain.model.UserType
import com.workshop.ledger.presentation.components.JalaliWheelDatePickerSheet
import com.workshop.ledger.presentation.theme.StayarIcon
import com.workshop.ledger.presentation.theme.StayarTheme
import com.workshop.ledger.presentation.tutorial.QuestCoordinator
import com.workshop.ledger.presentation.tutorial.questTarget

private data class PendingFutureAction(
    val dateStr: String,
    val execute: () -> Unit
)

private data class HourPickerTarget(
    val user: User,
    val dateStr: String,
    val initialHours: Double
)

@Composable
fun AttendanceScreen(
    project: Project,
    viewModePref: AttendanceViewMode,
    coachDismissed: Boolean,
    onSetViewMode: (AttendanceViewMode) -> Unit,
    onDismissCoach: () -> Unit,
    onSetAttendance: (dateStr: String, userId: String, value: AttendanceValue?) -> Unit,
    onMarkAllPresent: (dateStr: String) -> Unit,
    onShowAbsentTipToast: (user: User, dateStr: String) -> Unit,
    synthesizer: NativePcmSynthesizer? = null,
    haptics: RichHapticsManager? = null,
    questCoordinator: QuestCoordinator? = null
) {
    val colors = StayarTheme.colors
    val digitsMode = StayarTheme.digitsMode
    val f = { s: String -> TextNormalizer.formatDisplayDigits(s, digitsMode) }
    val config = LocalConfiguration.current

    val effectiveViewMode = when (viewModePref) {
        AttendanceViewMode.CARD -> AttendanceViewMode.CARD
        AttendanceViewMode.MATRIX -> AttendanceViewMode.MATRIX
        AttendanceViewMode.AUTO -> if (config.screenWidthDp < 700) AttendanceViewMode.CARD else AttendanceViewMode.MATRIX
    }

    val todayStr = remember { JalaliCalendarEngine.jTodayStr() }
    var selectedDateStr by remember { mutableStateOf(todayStr) }
    var currentYearMonth by remember { mutableStateOf(todayStr.substring(0, 7)) }
    var showDatePicker by remember { mutableStateOf(false) }
    var hourPickerTarget by remember { mutableStateOf<HourPickerTarget?>(null) }

    // Session cache of confirmed future dates
    val confirmedFutureDates = remember { mutableStateListOf<String>() }
    var pendingFutureAction by remember { mutableStateOf<PendingFutureAction?>(null) }
    var shownAbsentTipInSession by remember { mutableStateOf(false) }

    fun guardFutureDate(dateStr: String, block: () -> Unit) {
        if (dateStr > todayStr && dateStr !in confirmedFutureDates) {
            pendingFutureAction = PendingFutureAction(dateStr, block)
        } else {
            block()
        }
    }

    // Active, non-deleted users ordered master -> apprentice -> custom, then by createdAt
    val orderedActiveUsers = remember(project.users) {
        project.liveUsers()
            .filter { it.active }
            .sortedWith(
                compareBy<User> {
                    when (it.type) {
                        UserType.MASTER -> 0
                        UserType.APPRENTICE -> 1
                        UserType.CUSTOM -> 2
                    }
                }.thenBy { it.createdAt }
            )
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // View Switch Segmented Control («کارتی (موبایل)» | «ماتریس ماهانه»)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp)
                .semantics { contentDescription = "نوع نمایش حضور" },
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            val isCard = effectiveViewMode == AttendanceViewMode.CARD
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = if (isCard) colors.accent else colors.bgElev,
                border = BorderStroke(colors.defaultBorderWidth, if (isCard) colors.accent else colors.borderStrong),
                modifier = Modifier
                    .weight(1f)
                    .clickable { onSetViewMode(AttendanceViewMode.CARD) }
            ) {
                Row(
                    modifier = Modifier.padding(vertical = 10.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    StayarIcon("users", tint = if (isCard) colors.onAccent else colors.text, size = 18.dp)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "کارتی (موبایل)",
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isCard) colors.onAccent else colors.text
                    )
                }
            }

            val isMatrix = effectiveViewMode == AttendanceViewMode.MATRIX
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = if (isMatrix) colors.accent else colors.bgElev,
                border = BorderStroke(colors.defaultBorderWidth, if (isMatrix) colors.accent else colors.borderStrong),
                modifier = Modifier
                    .weight(1f)
                    .questTarget("att_view_matrix", questCoordinator)
                    .clickable { onSetViewMode(AttendanceViewMode.MATRIX) }
            ) {
                Row(
                    modifier = Modifier.padding(vertical = 10.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    StayarIcon("calendar", tint = if (isMatrix) colors.onAccent else colors.text, size = 18.dp)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "ماتریس ماهانه",
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isMatrix) colors.onAccent else colors.text
                    )
                }
            }
        }

        if (effectiveViewMode == AttendanceViewMode.CARD) {
            AttendanceCardView(
                project = project,
                activeUsers = orderedActiveUsers,
                selectedDateStr = selectedDateStr,
                coachDismissed = coachDismissed,
                onDismissCoach = onDismissCoach,
                onSelectPrevDay = {
                    haptics?.detent(6L)
                    selectedDateStr = JalaliCalendarEngine.jAddDays(selectedDateStr, -1)
                    currentYearMonth = selectedDateStr.substring(0, 7)
                },
                onSelectNextDay = {
                    haptics?.detent(6L)
                    selectedDateStr = JalaliCalendarEngine.jAddDays(selectedDateStr, 1)
                    currentYearMonth = selectedDateStr.substring(0, 7)
                },
                onOpenDatePicker = { showDatePicker = true },
                onMarkAllPresent = {
                    guardFutureDate(selectedDateStr) {
                        haptics?.confirm(15L)
                        onMarkAllPresent(selectedDateStr)
                    }
                },
                onToggleAttendance = { user, value ->
                    guardFutureDate(selectedDateStr) {
                        haptics?.tap()
                        synthesizer?.tick(1200)
                        val existing = project.attendance[selectedDateStr]?.get(user.id)
                        onSetAttendance(selectedDateStr, user.id, value)
                        if (value == AttendanceValue.Absent && existing != AttendanceValue.Absent && !shownAbsentTipInSession) {
                            shownAbsentTipInSession = true
                            onShowAbsentTipToast(user, selectedDateStr)
                        }
                    }
                },
                onOpenHourPicker = { user, initH ->
                    guardFutureDate(selectedDateStr) {
                        hourPickerTarget = HourPickerTarget(user, selectedDateStr, initH)
                    }
                },
                questCoordinator = questCoordinator
            )
        } else {
            LazyTwoDimensionalMatrix(
                project = project,
                activeUsers = orderedActiveUsers,
                yearMonth = currentYearMonth,
                onPrevMonth = { currentYearMonth = JalaliCalendarEngine.jAddMonths(currentYearMonth, -1) },
                onNextMonth = { currentYearMonth = JalaliCalendarEngine.jAddMonths(currentYearMonth, 1) },
                onThisMonth = { currentYearMonth = todayStr.substring(0, 7) },
                onCycleCell = { dateStr, user ->
                    guardFutureDate(dateStr) {
                        haptics?.tap()
                        synthesizer?.tick(1300)
                        val cur = project.attendance[dateStr]?.get(user.id)
                        val next: AttendanceValue? = when (cur) {
                            null -> AttendanceValue.Full
                            AttendanceValue.Full -> AttendanceValue.Half
                            AttendanceValue.Half -> AttendanceValue.Absent
                            else -> null
                        }
                        onSetAttendance(dateStr, user.id, next)
                    }
                },
                onSetCellExplicit = { dateStr, user, value ->
                    guardFutureDate(dateStr) {
                        haptics?.tap()
                        onSetAttendance(dateStr, user.id, value)
                    }
                },
                onMarkAllPresentForDate = { dateStr ->
                    guardFutureDate(dateStr) {
                        haptics?.confirm(15L)
                        onMarkAllPresent(dateStr)
                    }
                },
                synthesizer = synthesizer,
                haptics = haptics
            )
        }
    }

    if (showDatePicker) {
        JalaliWheelDatePickerSheet(
            initialDateStr = selectedDateStr,
            onDateSelected = { picked ->
                selectedDateStr = picked
                currentYearMonth = picked.substring(0, 7)
            },
            onDismiss = { showDatePicker = false },
            synthesizer = synthesizer,
            haptics = haptics
        )
    }

    if (hourPickerTarget != null) {
        val target = hourPickerTarget!!
        HourPickerSheet(
            personName = target.user.name,
            initialHours = target.initialHours,
            overtimeFactor = AccountingEngine.sanitizeOvertimeFactor(project.settings.overtimeFactor),
            onConfirmHours = { h ->
                onSetAttendance(target.dateStr, target.user.id, AttendanceValue.Hourly(h))
            },
            onDismiss = { hourPickerTarget = null },
            synthesizer = synthesizer,
            haptics = haptics
        )
    }

    if (pendingFutureAction != null) {
        val pending = pendingFutureAction!!
        AlertDialog(
            onDismissRequest = { pendingFutureAction = null },
            containerColor = colors.bgElev,
            title = {
                Text("ثبت حضور برای آینده", fontWeight = FontWeight.Bold, color = colors.text)
            },
            text = {
                Text(
                    text = "تاریخ «${f(pending.dateStr)}» هنوز نرسیده است و ثبت حضور برای روزهای آینده معمولاً اشتباه است. مطمئنید؟",
                    color = colors.text
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        confirmedFutureDates.add(pending.dateStr)
                        val action = pending.execute
                        pendingFutureAction = null
                        action()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = colors.accent)
                ) {
                    Text("بله، ثبت کن", color = colors.onAccent, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { pendingFutureAction = null }) {
                    Text("انصراف", color = colors.text)
                }
            }
        )
    }
}
