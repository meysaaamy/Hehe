package com.workshop.ledger.domain.validation

import com.workshop.ledger.domain.engine.JalaliCalendarEngine
import com.workshop.ledger.domain.engine.TextNormalizer
import com.workshop.ledger.domain.model.AppState
import com.workshop.ledger.domain.model.DomainConstants
import com.workshop.ledger.domain.model.Project
import com.workshop.ledger.domain.model.UserType

data class SanitizeReport<T>(
    val value: T,
    val fixes: Int
)

object ProjectSanitizer {

    private val SAFE_ID_CHAR = Regex("[^\\w.-]")
    private val PROTOTYPE_POLLUTION_KEYS = setOf("__proto__", "constructor", "prototype")

    fun sanId(v: String?, onFix: () -> Unit): String {
        val raw = v?.trim().orEmpty()
        var s = raw.replace(SAFE_ID_CHAR, "_").take(64)
        if (s.isEmpty()) {
            onFix()
            return "x_${DomainConstants.uid()}"
        }
        if (s in PROTOTYPE_POLLUTION_KEYS) {
            onFix()
            s = "_$s"
        }
        if (s != raw) onFix()
        return s
    }

    fun sanRef(v: String?, onFix: () -> Unit): String? {
        if (v == null || v.isEmpty() || v == "shared") return v
        return sanId(v, onFix)
    }

    fun sanDay(v: String?, onFix: () -> Unit): String {
        val raw = v?.trim().orEmpty()
        if (raw.isEmpty()) return ""
        val ascii = TextNormalizer.fa2en(raw)
        val filtered = buildString(10) {
            for (ch in ascii) {
                if ((ch in '0'..'9' || ch == '/') && length < 10) append(ch)
            }
        }
        val parsed = JalaliCalendarEngine.jParse(filtered)
        val formatted = parsed?.toFormattedString() ?: filtered
        if (formatted != raw) onFix()
        return formatted
    }

    fun sanNum(v: Double, default: Double, min: Double, max: Double, onFix: () -> Unit): Double {
        if (!v.isFinite() || v < min || v > max) {
            onFix()
            return default
        }
        return v
    }

    fun sanMoney(v: Long, default: Long = 0L, onFix: () -> Unit): Long {
        if (v < 0L) {
            onFix()
            return default
        }
        if (v > DomainConstants.MAX_MONEY) {
            onFix()
            return DomainConstants.MAX_MONEY
        }
        return v
    }

    fun sanText(v: String?, max: Int, onFix: () -> Unit): String {
        val raw = v.orEmpty()
        return if (raw.length > max) {
            onFix()
            raw.take(max)
        } else {
            raw
        }
    }

    fun sanitizeProject(project: Project, legacyVersion: Int = 3): SanitizeReport<Project> {
        var fixes = 0
        val countFix = { fixes++ }

        val pid = sanId(project.id, countFix)
        val pName = sanText(project.name.ifBlank { "پروژه جدید" }, DomainConstants.MAX_NAME_LENGTH, countFix)

        var ot = sanNum(project.settings.overtimeFactor, 1.0, 1.0, 5.0, countFix)
        var calcVer = project.settings.calcVersion
        if (legacyVersion < 3) {
            if (ot == 1.4) {
                ot = 1.0
                fixes++
            }
            calcVer = 1
        }

        val pen = sanNum(project.settings.absentPenalty, 0.5, 0.0, 3.0, countFix)
        val basis = if (project.settings.profitBasis == "commitment") "commitment" else "cash"
        val rFrom = if (project.settings.rangeFrom.isNotEmpty()) sanDay(project.settings.rangeFrom, countFix) else ""
        val rTo = if (project.settings.rangeTo.isNotEmpty()) sanDay(project.settings.rangeTo, countFix) else ""

        val cleanSettings = project.settings.copy(
            rangeFrom = rFrom,
            rangeTo = rTo,
            overtimeFactor = ot,
            absentPenalty = pen,
            profitBasis = basis,
            calcVersion = if (calcVer == 1) 1 else 2
        )

        val cleanCategories = project.categories.map { c ->
            c.copy(
                id = sanId(c.id, countFix),
                name = sanText(c.name.ifBlank { "دسته" }, DomainConstants.MAX_NAME_LENGTH, countFix)
            )
        }

        val cleanUsers = project.users.map { u ->
            val wf = if (u.type == UserType.MASTER) {
                sanNum(u.workFactor, 1.0, 0.0, 100.0, countFix)
            } else {
                1.0
            }
            u.copy(
                id = sanId(u.id, countFix),
                name = sanText(u.name.ifBlank { "کاربر" }, DomainConstants.MAX_NAME_LENGTH, countFix),
                role = sanText(u.role, DomainConstants.MAX_NAME_LENGTH, countFix),
                workFactor = wf
            )
        }

        val cleanWages = project.wages.map { w ->
            w.copy(
                id = sanId(w.id, countFix),
                userId = sanId(w.userId, countFix),
                rate = sanMoney(w.rate, 0L, countFix),
                effectiveDate = sanDay(w.effectiveDate, countFix)
            )
        }

        val cleanAttendance = LinkedHashMap<String, Map<String, com.workshop.ledger.domain.model.AttendanceValue>>()
        for ((date, dayMap) in project.attendance) {
            if (dayMap.isEmpty()) continue
            val cleanDate = sanDay(date, countFix)
            val inner = LinkedHashMap<String, com.workshop.ledger.domain.model.AttendanceValue>()
            for ((uid, attVal) in dayMap) {
                inner[sanId(uid, countFix)] = attVal
            }
            if (inner.isNotEmpty()) {
                cleanAttendance[cleanDate] = inner
            }
        }

        val cleanExpenses = project.expenses.map { e ->
            e.copy(
                id = sanId(e.id, countFix),
                date = sanDay(e.date, countFix),
                amount = sanMoney(e.amount, 1L, countFix),
                description = sanText(e.description, DomainConstants.MAX_DESCRIPTION_LENGTH, countFix),
                categoryId = sanRef(e.categoryId, countFix),
                payerId = sanRef(e.payerId, countFix) ?: "shared"
            )
        }

        val cleanReceipts = project.receipts.map { r ->
            r.copy(
                id = sanId(r.id, countFix),
                dateFrom = sanDay(r.dateFrom, countFix),
                dateTo = sanDay(r.dateTo, countFix),
                amount = sanMoney(r.amount, 1L, countFix),
                description = sanText(r.description, DomainConstants.MAX_DESCRIPTION_LENGTH, countFix)
            )
        }

        val cleanPayouts = project.payouts.map { p ->
            p.copy(
                id = sanId(p.id, countFix),
                date = sanDay(p.date, countFix),
                userId = sanId(p.userId, countFix),
                amount = sanMoney(p.amount, 1L, countFix),
                description = sanText(p.description, DomainConstants.MAX_DESCRIPTION_LENGTH, countFix)
            )
        }

        val cleanTransfers = project.transfers.map { t ->
            t.copy(
                id = sanId(t.id, countFix),
                date = sanDay(t.date, countFix),
                fromId = sanRef(t.fromId, countFix),
                toId = sanId(t.toId, countFix),
                amount = sanMoney(t.amount, 1L, countFix),
                description = sanText(t.description, DomainConstants.MAX_DESCRIPTION_LENGTH, countFix)
            )
        }

        val cleanAdjustments = project.adjustments.map { a ->
            a.copy(
                id = sanId(a.id, countFix),
                date = sanDay(a.date, countFix),
                userId = sanId(a.userId, countFix),
                amount = sanMoney(a.amount, 1L, countFix),
                description = sanText(a.description, DomainConstants.MAX_DESCRIPTION_LENGTH, countFix)
            )
        }

        return SanitizeReport(
            value = project.copy(
                id = pid,
                name = pName,
                settings = cleanSettings,
                users = cleanUsers,
                wages = cleanWages,
                attendance = cleanAttendance,
                expenses = cleanExpenses,
                receipts = cleanReceipts,
                payouts = cleanPayouts,
                transfers = cleanTransfers,
                adjustments = cleanAdjustments,
                categories = cleanCategories
            ),
            fixes = fixes
        )
    }

    fun sanitizeAppState(state: AppState): SanitizeReport<AppState> {
        var totalFixes = 0
        val sanitizedProjects = state.projects.take(DomainConstants.MAX_PROJECTS).map { p ->
            val r = sanitizeProject(p, state.version)
            totalFixes += r.fixes
            r.value
        }
        val activeId = if (sanitizedProjects.any { it.id == state.activeProjectId }) {
            state.activeProjectId
        } else {
            sanitizedProjects.firstOrNull()?.id.orEmpty()
        }
        val clampedStep = state.onboarding.questStep.coerceIn(0, 27)
        val clampedChapter = state.onboarding.chapter.coerceIn(1, 3)
        if (clampedStep != state.onboarding.questStep || clampedChapter != state.onboarding.chapter) {
            totalFixes++
        }
        return SanitizeReport(
            value = state.copy(
                version = 3,
                activeProjectId = activeId,
                onboarding = state.onboarding.copy(
                    questStep = clampedStep,
                    chapter = clampedChapter
                ),
                projects = sanitizedProjects
            ),
            fixes = totalFixes
        )
    }
}
