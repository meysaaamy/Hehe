package com.workshop.ledger.presentation.screens.reports

import android.graphics.Bitmap
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.workshop.ledger.core.document.StayarDocumentEngine
import com.workshop.ledger.core.export.FileDeliveryManager
import com.workshop.ledger.domain.engine.StatementBuilder
import com.workshop.ledger.domain.engine.TextNormalizer
import com.workshop.ledger.domain.model.AccountingResult
import com.workshop.ledger.domain.model.Project
import com.workshop.ledger.domain.model.UserType
import com.workshop.ledger.presentation.components.BadgePill
import com.workshop.ledger.presentation.components.LockBanner
import com.workshop.ledger.presentation.theme.MoneyText
import com.workshop.ledger.presentation.theme.StayarIcon
import com.workshop.ledger.presentation.theme.StayarTheme
import kotlinx.coroutines.launch
import java.io.File

/**
 * Reports & Export Screen (`«خروجی و گزارش‌ها»`, Section 11).
 * Layout:
 * - Lock banner (if project.settings.locked)
 * - Row: Report-range button + small button «سنجش سلامت پیش از تسویه» (shield)
 * - Section «خروجی‌ها» with 5 action cards:
 *   1. Full PDF Report
 *   2. Financial Report CSV (UTF-8 BOM)
 *   3. Detailed Audit CSV (UTF-8 BOM)
 *   4. Project JSON Backup
 *   5. Full Database JSON Backup
 * - Section «صورتحساب افراد» with table of live users:
 *   Columns: Name, Type, Days worked, Balance.
 *   Row actions: «مشاهده», «تصویر A4», «PDF», «کپی متن».
 */
@Composable
fun ReportsScreen(
    project: Project,
    r: AccountingResult,
    documentEngine: StayarDocumentEngine,
    fileDelivery: FileDeliveryManager,
    onOpenRangeDialog: () -> Unit,
    onNavigateToHealth: () -> Unit,
    onExportProjectJson: () -> Unit,
    onExportFullDatabaseJson: () -> Unit,
    onToast: (String) -> Unit
) {
    val colors = StayarTheme.colors
    val digitsMode = StayarTheme.digitsMode
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()
    val f = { s: String -> TextNormalizer.formatDisplayDigits(s, digitsMode) }

    var selectedUserIdForStatement by remember { mutableStateOf<String?>(null) }
    var a4PreviewTitle by remember { mutableStateOf<String?>(null) }
    var a4PreviewPages by remember { mutableStateOf<List<Bitmap>>(emptyList()) }
    var a4PreviewBaseName by remember { mutableStateOf("statement") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Lock Banner
        if (project.settings.locked) {
            LockBanner()
        }

        // Top Row: Range Button + Health Check Button
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val rangeText = StatementBuilder.rangeTextFa(r.range, digitsMode)
            OutlinedButton(
                onClick = onOpenRangeDialog,
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = f("بازه: $rangeText"),
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
            }

            Button(
                onClick = onNavigateToHealth,
                colors = ButtonDefaults.buttonColors(
                    containerColor = colors.accent,
                    contentColor = colors.onAccent
                )
            ) {
                StayarIcon("shield", size = 16.dp, tint = colors.onAccent)
                Spacer(modifier = Modifier.size(6.dp))
                Text("سنجش سلامت پیش از تسویه", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }

        // Section «خروجی‌ها»
        Text(
            text = "خروجی‌ها و اسناد رسمی",
            fontWeight = FontWeight.ExtraBold,
            fontSize = 15.sp,
            color = colors.text
        )

        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Card 1: Full PDF Report
            ReportActionCard(
                icon = "file",
                title = "گزارش PDF کامل",
                description = "بدون بریدگی سطر، صفحه‌بندی هوشمند A4",
                onClick = {
                    scope.launch {
                        val blocks = documentEngine.buildProjectFullReportBlocks(project, r, digitsMode)
                        val fileName = fileDelivery.buildExportFileName("report", "pdf")
                        val cacheDir = File(documentEngine.context.cacheDir, "exports").apply { mkdirs() }
                        val outFile = File(cacheDir, fileName)
                        documentEngine.renderVectorPdfToFile(blocks, outFile)
                        fileDelivery.shareFile(outFile, "application/pdf", "اشتراک‌گذاری گزارش کارگاه")
                    }
                }
            )

            // Card 2: Financial Summary CSV
            ReportActionCard(
                icon = "download",
                title = "گزارش جامع مالی CSV",
                description = "سازگار با اکسل (UTF-8 BOM)",
                onClick = {
                    scope.launch {
                        val csv = StatementBuilder.buildFinancialReportCsv(project, r, includeBom = true)
                        val fileName = fileDelivery.buildExportFileName("financial", "csv")
                        val file = fileDelivery.writeUtf8FileToExportsCache(fileName, csv)
                        fileDelivery.shareFile(file, "text/csv", "گزارش جامع مالی CSV")
                    }
                }
            )

            // Card 3: Detailed Audit CSV
            ReportActionCard(
                icon = "layers",
                title = "CSV ریز حسابرسی",
                description = "همه رکوردها سطر به سطر",
                onClick = {
                    scope.launch {
                        val csv = StatementBuilder.buildDetailedAuditCsv(project, r, includeBom = true)
                        val fileName = fileDelivery.buildExportFileName("audit", "csv")
                        val file = fileDelivery.writeUtf8FileToExportsCache(fileName, csv)
                        fileDelivery.shareFile(file, "text/csv", "ریز حسابرسی CSV")
                    }
                }
            )

            // Card 4: Project JSON Backup
            ReportActionCard(
                icon = "shield",
                title = "پشتیبان JSON پروژه",
                description = "فقط پروژه فعال",
                onClick = onExportProjectJson
            )

            // Card 5: Full Database JSON Backup
            ReportActionCard(
                icon = "folder",
                title = "پشتیبان کامل JSON",
                description = "همه پروژه‌ها",
                onClick = onExportFullDatabaseJson
            )
        }

        // Section «صورتحساب افراد»
        Text(
            text = "صورتحساب افراد",
            fontWeight = FontWeight.ExtraBold,
            fontSize = 15.sp,
            color = colors.text
        )

        val liveUsers = project.liveUsers()
        if (liveUsers.isEmpty()) {
            Text(
                text = "کاربری تعریف نشده است.",
                fontSize = 13.sp,
                color = colors.textDim
            )
        } else {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                liveUsers.forEach { user ->
                    val acc = r.acc[user.id]
                    val days = acc?.days ?: 0.0
                    val isMaster = user.type == UserType.MASTER
                    val masterRes = r.masters.find { it.id == user.id }
                    val staffRes = r.staff.find { it.id == user.id }
                    val balance = if (isMaster) (masterRes?.finalBalance ?: 0L) else (staffRes?.debt ?: 0L)

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(colors.bgElev)
                            .border(1.dp, colors.border, RoundedCornerShape(12.dp))
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = f(user.name),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = colors.text
                                )
                                BadgePill(text = user.type.labelFa, color = colors.accent)
                            }

                            Text(
                                text = f("کارکرد: ${TextNormalizer.fmtDays(days)} روز"),
                                fontSize = 12.sp,
                                color = colors.textDim
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = if (isMaster) "مانده تسویه: " else "مانده حساب: ",
                                    fontSize = 12.sp,
                                    color = colors.textDim
                                )
                                MoneyText(
                                    amount = balance,
                                    unit = "تومان",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (balance >= 0L) colors.success else colors.danger
                                )
                            }

                            // Actions: View, A4, PDF, Copy
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedButton(
                                    onClick = { selectedUserIdForStatement = user.id }
                                ) {
                                    Text("مشاهده", fontSize = 11.sp)
                                }

                                OutlinedButton(
                                    onClick = {
                                        scope.launch {
                                            val model = StatementBuilder.statementModel(project, user.id, r)
                                            if (model != null) {
                                                val blocks = documentEngine.buildStatementBlocks(project, model, digitsMode)
                                                val rendered = documentEngine.renderA4Bitmaps(blocks, cropLastPage = true, digitsMode = digitsMode)
                                                val baseName = fileDelivery.buildStatementFileName(user.id, "png")
                                                if (rendered.pages.size == 1) {
                                                    val outFile = documentEngine.saveBitmapToPngFile(rendered.pages.first(), baseName)
                                                    fileDelivery.shareFile(outFile, "image/png", "صورتحساب A4 ${user.name}")
                                                } else {
                                                    a4PreviewTitle = "تصویر A4 — صورتحساب ${user.name}"
                                                    a4PreviewPages = rendered.pages
                                                    a4PreviewBaseName = "stayar-statement-${user.id}"
                                                }
                                            }
                                        }
                                    }
                                ) {
                                    Text("تصویر A4", fontSize = 11.sp)
                                }

                                OutlinedButton(
                                    onClick = {
                                        scope.launch {
                                            val model = StatementBuilder.statementModel(project, user.id, r)
                                            if (model != null) {
                                                val blocks = documentEngine.buildStatementBlocks(project, model, digitsMode)
                                                val fileName = fileDelivery.buildStatementFileName(user.id, "pdf")
                                                val cacheDir = File(documentEngine.context.cacheDir, "exports").apply { mkdirs() }
                                                val outFile = File(cacheDir, fileName)
                                                documentEngine.renderVectorPdfToFile(blocks, outFile)
                                                fileDelivery.shareFile(outFile, "application/pdf", "صورتحساب ${user.name}")
                                            }
                                        }
                                    }
                                ) {
                                    Text("PDF", fontSize = 11.sp)
                                }

                                IconButton(
                                    onClick = {
                                        val text = StatementBuilder.statementText(project, user.id, r)
                                        clipboard.setText(AnnotatedString(text))
                                        onToast("متن صورتحساب ${user.name} کپی شد")
                                    },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    StayarIcon("file", size = 18.dp, tint = colors.accent)
                                }
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(48.dp))
    }

    // Statement Modal Sheet
    selectedUserIdForStatement?.let { uid ->
        StatementSheet(
            userId = uid,
            project = project,
            accountingResult = r,
            documentEngine = documentEngine,
            onDismiss = { selectedUserIdForStatement = null },
            onShowA4Preview = { title, pages, baseName ->
                a4PreviewTitle = title
                a4PreviewPages = pages
                a4PreviewBaseName = baseName
            },
            onExportPdfFile = { file, name ->
                fileDelivery.shareFile(file, "application/pdf", name)
            },
            onToast = onToast
        )
    }

    // A4 Multi-page Preview Sheet
    a4PreviewTitle?.let { title ->
        A4PreviewSheet(
            title = title,
            pages = a4PreviewPages,
            baseName = a4PreviewBaseName,
            documentEngine = documentEngine,
            onSharePngFile = { file, name ->
                fileDelivery.shareFile(file, "image/png", name)
            },
            onDismiss = {
                a4PreviewTitle = null
                a4PreviewPages = emptyList()
            }
        )
    }
}

@Composable
private fun ReportActionCard(
    icon: String,
    title: String,
    description: String,
    onClick: () -> Unit
) {
    val colors = StayarTheme.colors
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(colors.bgElev)
            .border(1.dp, colors.border, RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.weight(1f)
        ) {
            StayarIcon(icon, size = 24.dp, tint = colors.accent)
            Column {
                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = colors.text
                )
                Text(
                    text = description,
                    fontSize = 12.sp,
                    color = colors.textDim
                )
            }
        }

        StayarIcon("more", size = 18.dp, tint = colors.textDim)
    }
}
