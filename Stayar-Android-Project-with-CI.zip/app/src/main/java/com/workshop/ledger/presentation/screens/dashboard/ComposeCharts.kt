package com.workshop.ledger.presentation.screens.dashboard

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.workshop.ledger.domain.engine.TextNormalizer
import com.workshop.ledger.domain.model.AccountingResult
import com.workshop.ledger.domain.model.Project
import com.workshop.ledger.presentation.theme.MoneyText
import com.workshop.ledger.presentation.theme.StayarTheme
import com.workshop.ledger.presentation.theme.VizColors
import kotlin.math.atan2
import kotlin.math.max

private data class ShareSlice(
    val name: String,
    val amount: Long,
    val pct: Double,
    val color: Color
)

@Composable
fun AnalyticsChartsSection(
    project: Project,
    r: AccountingResult,
    onTick: () -> Unit = {}
) {
    val colors = StayarTheme.colors
    val digitsMode = StayarTheme.digitsMode
    val f = { s: String -> TextNormalizer.formatDisplayDigits(s, digitsMode) }
    var viewFilter by remember { mutableStateOf("all") } // "all" | "masters" | "staff"

    val rawItems: List<Pair<String, Long>> = remember(r, viewFilter) {
        when (viewFilter) {
            "masters" -> r.masters.filter { it.finalBalance > 0L }.map { it.name to it.finalBalance }
            "staff" -> r.staff.filter { it.debt > 0L }.map { it.name to it.debt }
            else -> {
                val mList = r.masters.filter { it.finalBalance > 0L }.map { it.name to it.finalBalance }
                val sList = r.staff.filter { it.debt > 0L }.map { it.name to it.debt }
                mList + sList
            }
        }
    }

    val totalPositive = rawItems.sumOf { it.second }
    val slices = remember(rawItems, totalPositive) {
        rawItems.mapIndexed { idx, (name, amt) ->
            ShareSlice(
                name = name,
                amount = amt,
                pct = if (totalPositive > 0L) amt.toDouble() / totalPositive.toDouble() else 0.0,
                color = VizColors[idx % VizColors.size]
            )
        }
    }

    val centerLabel = when (viewFilter) {
        "masters" -> "خالص اوستاها"
        "staff" -> "مانده شاگرد/سایر"
        else -> "خالص همه افراد"
    }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "تحلیل و نمودارها",
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
                color = colors.text
            )
            // Segmented control («نوع نمودار سهم»)
            Row(
                modifier = Modifier.semantics { contentDescription = "نوع نمودار سهم" },
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf("all" to "همه افراد", "masters" to "اوستاها", "staff" to "شاگرد/سایر").forEach { (key, label) ->
                    val active = viewFilter == key
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (active) colors.accent else colors.bgElev2,
                        border = BorderStroke(colors.defaultBorderWidth, colors.borderStrong),
                        modifier = Modifier.clickable {
                            onTick()
                            viewFilter = key
                        }
                    ) {
                        Text(
                            text = label,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (active) colors.onAccent else colors.text,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }
            }
        }

        // Chart 1: Pseudo-3D Donut («سهم خالص (سه‌بعدی)»)
        ChartCard(titleFa = "سهم خالص (سه‌بعدی)") {
            if (slices.isEmpty()) {
                EmptyChartText("مانده مثبتی برای نمایش وجود ندارد.")
            } else {
                var selectedIdx by remember(slices) { mutableIntStateOf(-1) }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(210.dp)
                    ) {
                        Canvas(
                            modifier = Modifier
                                .size(220.dp, 180.dp)
                                .pointerInput(slices) {
                                    detectTapGestures { offset ->
                                        val cx = size.width / 2f
                                        val cy = size.height / 2f
                                        val dx = offset.x - cx
                                        val dy = (offset.y - cy) / 0.62f
                                        var deg = Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat()
                                        if (deg < 0f) deg += 360f
                                        var accDeg = 0f
                                        for (i in slices.indices) {
                                            val sweep = (slices[i].pct * 360.0).toFloat()
                                            if (deg in accDeg..(accDeg + sweep)) {
                                                selectedIdx = if (selectedIdx == i) -1 else i
                                                onTick()
                                                break
                                            }
                                            accDeg += sweep
                                        }
                                    }
                                }
                        ) {
                            val w = size.width
                            val h = size.height * 0.62f
                            val strokeW = 28.dp.toPx()

                            // 12 stacked darker extrusion layers (`scaleY = 0.62f`)
                            for (layer in 12 downTo 0) {
                                val yOffset = layer * 2.5f + 16f
                                var startAngle = 0f
                                for ((idx, s) in slices.withIndex()) {
                                    val sweep = (s.pct * 360.0).toFloat()
                                    val c = if (layer == 0) {
                                        s.color
                                    } else {
                                        s.color.copy(
                                            red = s.color.red * 0.68f,
                                            green = s.color.green * 0.68f,
                                            blue = s.color.blue * 0.68f
                                        )
                                    }
                                    drawArc(
                                        color = c,
                                        startAngle = startAngle,
                                        sweepAngle = max(1f, sweep - 1.5f),
                                        useCenter = false,
                                        topLeft = Offset(strokeW, yOffset),
                                        size = Size(w - strokeW * 2, h),
                                        style = Stroke(width = if (idx == selectedIdx && layer == 0) strokeW * 1.18f else strokeW)
                                    )
                                    startAngle += sweep
                                }
                            }
                        }

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(centerLabel, fontSize = 11.sp, color = colors.textDim)
                            MoneyText(amount = totalPositive, fontSize = 13.5.sp, fontWeight = FontWeight.ExtraBold)
                        }
                    }

                    if (selectedIdx in slices.indices) {
                        val sel = slices[selectedIdx]
                        Surface(
                            color = colors.bgElev2,
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, sel.color),
                            modifier = Modifier.padding(bottom = 8.dp)
                        ) {
                            Text(
                                text = f("${sel.name}: ${TextNormalizer.fmt(sel.amount)} تومان (${TextNormalizer.pctText(sel.pct)}٪)"),
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = colors.text,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }

                    // Legend
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        for (s in slices) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Surface(shape = CircleShape, color = s.color, modifier = Modifier.size(10.dp)) {}
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(s.name, fontSize = 12.5.sp, color = colors.text)
                                }
                                Text(
                                    text = f("${TextNormalizer.fmt(s.amount)} تومان (${TextNormalizer.pctText(s.pct)}٪)"),
                                    fontSize = 12.sp,
                                    color = colors.textDim
                                )
                            }
                        }
                    }
                }
            }
        }

        // Chart 2: Horizontal Rounded RTL Bars («سهم درصدی و مبلغی»)
        ChartCard(titleFa = "سهم درصدی و مبلغی") {
            if (slices.isEmpty()) {
                EmptyChartText("داده‌ای برای نمودار میله‌ای نیست.")
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (s in slices) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(s.name, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold, color = colors.text)
                                Text(
                                    text = f("٪${TextNormalizer.pctText(s.pct)} · ${TextNormalizer.fmt(s.amount)}"),
                                    fontSize = 12.sp,
                                    color = colors.textDim
                                )
                            }
                            Spacer(modifier = Modifier.height(3.dp))
                            Canvas(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(14.dp)
                            ) {
                                val w = size.width
                                val h = size.height
                                drawRoundRect(
                                    color = colors.bgElev2,
                                    size = Size(w, h),
                                    cornerRadius = CornerRadius(h / 2f)
                                )
                                val barW = (w * s.pct.toFloat()).coerceIn(6f, w)
                                // RTL: start from right edge
                                drawRoundRect(
                                    color = s.color,
                                    topLeft = Offset(w - barW, 0f),
                                    size = Size(barW, h),
                                    cornerRadius = CornerRadius(h / 2f)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Chart 3: Cash-Flow Trend («روند جریان نقدینگی»)
        ChartCard(titleFa = "روند جریان نقدینگی") {
            val hasCashflow = r.totalReceipts > 0L || r.sharedExpenses > 0L || r.totalCashPayouts > 0L
            if (!hasCashflow) {
                EmptyChartText("هنوز جریان نقدی ثبت نشده است.")
            } else {
                Column {
                    Canvas(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp)
                    ) {
                        val w = size.width
                        val h = size.height
                        val maxVal = maxOf(r.totalReceipts, r.sharedExpenses + r.personalExpTotal, r.totalCashPayouts, 1L).toFloat()

                        val recY = h - (r.totalReceipts / maxVal) * (h * 0.78f) - 10f
                        val expY = h - ((r.sharedExpenses + r.personalExpTotal) / maxVal) * (h * 0.78f) - 10f
                        val payY = h - (r.totalCashPayouts / maxVal) * (h * 0.78f) - 10f

                        // Receipt line (success)
                        val recPath = Path().apply {
                            moveTo(w * 0.92f, h - 10f)
                            quadraticBezierTo(w * 0.50f, recY, w * 0.08f, recY)
                        }
                        drawPath(recPath, color = colors.success, style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round))

                        // Expense line (danger)
                        val expPath = Path().apply {
                            moveTo(w * 0.92f, h - 10f)
                            quadraticBezierTo(w * 0.50f, expY, w * 0.08f, expY)
                        }
                        drawPath(expPath, color = colors.danger, style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round))

                        // Payout line (warn)
                        val payPath = Path().apply {
                            moveTo(w * 0.92f, h - 10f)
                            quadraticBezierTo(w * 0.50f, payY, w * 0.08f, payY)
                        }
                        drawPath(payPath, color = colors.warn, style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round))
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("دریافتی کارفرما", fontSize = 11.5.sp, color = colors.success, fontWeight = FontWeight.Bold)
                        Text("هزینه‌ها", fontSize = 11.5.sp, color = colors.danger, fontWeight = FontWeight.Bold)
                        Text("پرداختی به شاگردان", fontSize = 11.5.sp, color = colors.warn, fontWeight = FontWeight.Bold)
                        Text("محور افقی: روز/ماه", fontSize = 11.sp, color = colors.textDim)
                    }
                }
            }
        }

        // Chart 4: Diverging Finance Balance («تراز جریان مالی کارگاه»)
        ChartCard(titleFa = "تراز جریان مالی کارگاه") {
            val rows = listOf(
                Triple("واریزی‌ها", r.totalReceipts, true),
                Triple("هزینه‌های مشترک", r.sharedExpenses, false),
                Triple("دستمزد استحقاقی", r.totalWages, false),
                Triple("پرداختی‌های نقدی", r.totalCashPayouts + r.staffAssistance, false),
                Triple("مانده قابل تقسیم", r.profit, r.profit >= 0L)
            )
            val maxAbs = rows.maxOfOrNull { kotlin.math.abs(it.second) }?.coerceAtLeast(1L) ?: 1L

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                for ((label, value, isPos) in rows) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = label,
                            fontSize = 12.sp,
                            color = colors.text,
                            modifier = Modifier.width(110.dp)
                        )
                        Canvas(
                            modifier = Modifier
                                .weight(1f)
                                .height(14.dp)
                                .padding(horizontal = 8.dp)
                        ) {
                            val w = size.width
                            val h = size.height
                            val midX = w / 2f
                            drawLine(colors.borderStrong, Offset(midX, 0f), Offset(midX, h), strokeWidth = 2f)
                            val frac = (kotlin.math.abs(value).toFloat() / maxAbs.toFloat()).coerceIn(0f, 1f)
                            val barW = (w * 0.46f * frac).coerceAtLeast(3f)
                            if (isPos) {
                                drawRoundRect(
                                    color = colors.success,
                                    topLeft = Offset(midX, 1f),
                                    size = Size(barW, h - 2f),
                                    cornerRadius = CornerRadius(4f)
                                )
                            } else {
                                drawRoundRect(
                                    color = colors.danger,
                                    topLeft = Offset(midX - barW, 1f),
                                    size = Size(barW, h - 2f),
                                    cornerRadius = CornerRadius(4f)
                                )
                            }
                        }
                        Text(
                            text = f(TextNormalizer.vizShort(value)),
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isPos) colors.success else colors.danger
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ChartCard(
    titleFa: String,
    content: @Composable () -> Unit
) {
    val colors = StayarTheme.colors
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = colors.bgElev,
        border = BorderStroke(colors.defaultBorderWidth, colors.borderStrong),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                text = titleFa,
                fontSize = 14.5.sp,
                fontWeight = FontWeight.Bold,
                color = colors.text
            )
            Spacer(modifier = Modifier.height(10.dp))
            content()
        }
    }
}

@Composable
private fun EmptyChartText(textFa: String) {
    Text(
        text = textFa,
        fontSize = 13.sp,
        color = StayarTheme.colors.textDim,
        modifier = Modifier.padding(vertical = 12.dp)
    )
}
