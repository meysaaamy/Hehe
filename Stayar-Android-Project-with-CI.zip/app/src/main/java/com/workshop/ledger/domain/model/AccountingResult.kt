package com.workshop.ledger.domain.model

data class ReportRange(
    val from: String = "",
    val to: String = ""
) {
    fun inRange(date: String): Boolean {
        if (date.isEmpty()) return false
        if (from.isNotEmpty() && date < from) return false
        if (to.isNotEmpty() && date > to) return false
        return true
    }
}

data class PersonAccumulator(
    val id: String,
    val name: String,
    val role: String,
    val type: UserType,
    val active: Boolean,
    val main: Boolean,
    val workFactor: Double,
    var full: Int = 0,
    var half: Int = 0,
    var hourly: Int = 0,
    var overtimeHours: Double = 0.0,
    var absent: Int = 0,
    var days: Double = 0.0,
    var baseWage: Long = 0L,
    var bonus: Long = 0L,
    var penalty: Long = 0L,
    var assistance: Long = 0L,
    var settle: Long = 0L,
    var paid: Long = 0L,
    var given: Long = 0L,
    var taken: Long = 0L,
    var advance: Long = 0L,
    var reimburse: Long = 0L
)

data class MasterResult(
    val id: String,
    val name: String,
    val role: String,
    val active: Boolean,
    val main: Boolean,
    val full: Int,
    val half: Int,
    val hourly: Int,
    val overtimeHours: Double,
    val absent: Int,
    val days: Double,
    val workFactor: Double,
    val workFinal: Double,
    val percent: Double,
    val share: Long,
    val reimburse: Long,
    val sharedPersonalExp: Long,
    val given: Long,
    val taken: Long,
    val advance: Long,
    val assistance: Long,
    val bonus: Long,
    val penalty: Long,
    val settle: Long,
    val finalBalance: Long
)

data class StaffResult(
    val id: String,
    val name: String,
    val role: String,
    val type: UserType,
    val active: Boolean,
    val full: Int,
    val half: Int,
    val hourly: Int,
    val overtimeHours: Double,
    val absent: Int,
    val days: Double,
    val baseWage: Long,
    val bonus: Long,
    val penalty: Long,
    val entitled: Long,
    val paid: Long,
    val assistance: Long,
    val totalPaid: Long,
    val debt: Long
)

data class AccountingResult(
    val basis: String,
    val range: ReportRange,
    val totalReceipts: Long,
    val sharedExpenses: Long,
    val personalExpTotal: Long,
    val totalWages: Long,
    val totalCashPayouts: Long,
    val staffAssistance: Long,
    val masterBonus: Long,
    val masterPenalty: Long,
    val profit: Long,
    val unallocated: Long,
    val totalWorkFinal: Double,
    val unpaidWages: Long,
    val acc: Map<String, PersonAccumulator>,
    val masters: List<MasterResult>,
    val staff: List<StaffResult>,
    val apprentices: List<StaffResult>,
    val others: List<StaffResult>,
    val negativeMasters: List<MasterResult>,
    val errors: List<String>
)

data class DailyStatementRow(
    val date: String,
    val weekdayFa: String,
    val value: AttendanceValue,
    val statusLabelFa: String,
    val fraction: Double,
    val rate: Long,
    val amount: Long
)

data class StatementTransferRow(
    val date: String,
    val labelFa: String,
    val amount: Long,
    val description: String
)

data class StatementModel(
    val userId: String,
    val name: String,
    val role: String,
    val type: UserType,
    val projectName: String,
    val range: ReportRange,
    val person: PersonAccumulator,
    val masterResult: MasterResult?,
    val staffResult: StaffResult?,
    val dailyRows: List<DailyStatementRow>,
    val payouts: List<Payout>,
    val adjustments: List<Adjustment>,
    val transfers: List<StatementTransferRow>,
    val personalExpenses: List<Expense>
)
