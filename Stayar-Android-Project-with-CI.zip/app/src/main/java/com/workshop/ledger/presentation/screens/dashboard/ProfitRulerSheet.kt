package com.workshop.ledger.presentation.screens.dashboard

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.workshop.ledger.domain.engine.TextNormalizer
import com.workshop.ledger.domain.model.AccountingResult
import com.workshop.ledger.presentation.components.TactileSheet
import com.workshop.ledger.presentation.theme.MoneyText
import com.workshop.ledger.presentation.theme.StayarTheme

/**
 * Transparent "Profit Ruler" («حساب شفاف») sheet showing visual step-by-step deduction
 * from client receipts down to each master's final share.
 */
@Composable
fun ProfitRulerSheet(
    r: AccountingResult,
    onDismiss: () -> Unit
) {
    val colors = StayarTheme.colors
    val digitsMode = StayarTheme.digitsMode
    val f = { s: String -> TextNormalizer.formatDisplayDigits(s, digitsMode) }

    TactileSheet(
        titleFa = "حساب شفاف (خط‌کش تقسیم سود)",
        onDismissRequest = onDismiss
    ) {
        Text(
            text = "مسیر دقیق تبدیل واریزی کارفرما به سهم هر اوستا:",
            fontSize = 13.sp,
            color = colors.textDim
        )
        Spacer(modifier = Modifier.height(10.dp))

        RulerStepRow("۱. کل واریزی کارفرما در بازه", r.totalReceipts, colors.success)
        RulerStepRow("۲. کسر هزینه‌های مشترک صندوق", -r.sharedExpenses, colors.danger)
        if (r.basis == "commitment") {
            RulerStepRow("۳. کسر کل دستمزد استحقاقی شاگردان", -r.totalWages, colors.warn)
        } else {
            RulerStepRow("۳. کسر پرداختی نقدی و مساعده پرسنل", -(r.totalCashPayouts + r.staffAssistance), colors.warn)
        }
        HorizontalDivider(color = colors.borderStrong, modifier = Modifier.padding(vertical = 8.dp))
        RulerStepRow("= مانده قابل تقسیم بین اوستاها", r.profit, colors.accent, isBold = true)

        Spacer(modifier = Modifier.height(14.dp))
        Text(
            text = "سهم‌بندی بر اساس (روز کارکرد × ضریب):",
            fontSize = 13.5.sp,
            fontWeight = FontWeight.Bold,
            color = colors.text
        )
        Spacer(modifier = Modifier.height(8.dp))

        for (m in r.masters) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = colors.bgElev2,
                border = BorderStroke(colors.defaultBorderWidth, colors.borderStrong),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${m.name} (${f(TextNormalizer.fmtDays(m.days))} روز × ${f(TextNormalizer.fmtDays(m.workFactor))})",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.5.sp,
                            color = colors.text
                        )
                        Text(
                            text = f("٪${TextNormalizer.pctText(m.percent)}"),
                            fontWeight = FontWeight.Bold,
                            color = colors.accent,
                            fontSize = 13.sp
                        )
                    }
                    LinearProgressIndicator(
                        progress = { m.percent.toFloat().coerceIn(0f, 1f) },
                        color = colors.accent,
                        trackColor = colors.border,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp)
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("سهم پایه: ${f(TextNormalizer.fmt(m.share))}", fontSize = 12.sp, color = colors.textDim)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("مانده تسویه: ", fontSize = 12.sp, color = colors.textDim)
                            MoneyText(
                                amount = m.finalBalance,
                                showUnit = true,
                                fontSize = 13.sp,
                                color = if (m.finalBalance >= 0L) colors.success else colors.danger
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RulerStepRow(
    labelFa: String,
    amount: Long,
    color: androidx.compose.ui.graphics.Color,
    isBold: Boolean = false
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = labelFa,
            fontSize = if (isBold) 14.5.sp else 13.sp,
            fontWeight = if (isBold) FontWeight.Bold else FontWeight.Medium,
            color = StayarTheme.colors.text
        )
        MoneyText(
            amount = amount,
            showUnit = true,
            fontSize = if (isBold) 15.sp else 13.5.sp,
            fontWeight = if (isBold) FontWeight.ExtraBold else FontWeight.SemiBold,
            color = color
        )
    }
}
