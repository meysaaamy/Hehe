package com.workshop.ledger.presentation.screens.dashboard

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.workshop.ledger.data.local.datastore.AppPreferences
import com.workshop.ledger.domain.engine.JalaliCalendarEngine
import com.workshop.ledger.domain.engine.StatementBuilder
import com.workshop.ledger.domain.engine.TextNormalizer
import com.workshop.ledger.domain.model.AccountingResult
import com.workshop.ledger.domain.model.MasterResult
import com.workshop.ledger.domain.model.Project
import com.workshop.ledger.domain.model.ReportRange
import com.workshop.ledger.presentation.components.BadgePill
import com.workshop.ledger.presentation.components.TactileSheet
import com.workshop.ledger.presentation.components.tiltCard
import com.workshop.ledger.presentation.theme.MoneyText
import com.workshop.ledger.presentation.theme.StayarIcon
import com.workshop.ledger.presentation.theme.StayarTheme
import com.workshop.ledger.presentation.tutorial.QuestCoordinator
import com.workshop.ledger.presentation.tutorial.questTarget
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DashboardScreen(
    project: Project,
    r: AccountingResult,
    prefs: AppPreferences,
    isSavingBlocked: Boolean,
    onExportFullBackup: () -> Unit,
    onSnoozeBackupNag: () -> Unit,
    onUpdateReportRange: (from: String, to: String) -> Unit,
    onNavigate: (String) -> Unit,
    onCreateSampleProject: () -> Unit,
    onOpenPracticeChooser: () -> Unit,
    onOpenStatementForUser: (String) -> Unit,
    onOpenProfitRuler: () -> Unit,
    onSettleNegativeMasterToFund: (MasterResult, Long) -> Unit,
    onTransferNegativeMasterToPeer: (MasterResult, MasterResult?, Long) -> Unit,
    questCoordinator: QuestCoordinator? = null
) {
    val colors = StayarTheme.colors
    val digitsMode = StayarTheme.digitsMode
    val f = { s: String -> TextNormalizer.formatDisplayDigits(s, digitsMode) }
    var showRangeSheet by remember { mutableStateOf(false) }

    val hasAnyData = project.attendance.isNotEmpty() ||
        project.receipts.isNotEmpty() ||
        project.expenses.isNotEmpty() ||
        project.payouts.isNotEmpty()

    val nowMs = System.currentTimeMillis()
    val sevenDaysMs = 7L * 24L * 3600L * 1000L
    val showBackupNag = hasAnyData &&
        !isSavingBlocked &&
        !project.isSandbox &&
        nowMs > prefs.backupNagSnoozedUntilMs &&
        (prefs.lastExternalExportMs == 0L || (nowMs - prefs.lastExternalExportMs) > sevenDaysMs)

    val rangeText = StatementBuilder.rangeTextFa(r.range, digitsMode)
    val isTutorialRulerStep = prefs.onboarding.status == "in_quest" && prefs.onboarding.questStep == 12

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Backup Nag Banner
        if (showBackupNag) {
            val lastBackupPrefix = if (prefs.lastExternalExportMs == 0L) {
                "هنوز پشتیبان کامل نگرفته‌اید."
            } else {
                "آخرین پشتیبان بیرونی: ${f(JalaliCalendarEngine.tsText(prefs.lastExternalExportMs))}."
            }
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = colors.warn.copy(alpha = 0.14f),
                border = BorderStroke(colors.defaultBorderWidth, colors.warn),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "$lastBackupPrefix با حذف برنامه یا عوض‌کردن گوشی، اطلاعات از بین می‌رود؛ فایل پشتیبان را بیرون از گوشی نگه دارید.",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = colors.text
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = onExportFullBackup,
                            colors = ButtonDefaults.buttonColors(containerColor = colors.accent)
                        ) {
                            Text("پشتیبان بگیر", color = colors.onAccent, fontWeight = FontWeight.Bold)
                        }
                        OutlinedButton(
                            onClick = onSnoozeBackupNag,
                            border = BorderStroke(colors.defaultBorderWidth, colors.borderStrong)
                        ) {
                            Text("بعداً", color = colors.text)
                        }
                    }
                }
            }
        }

        // 2. Top Controls Row: Report Range, Profit Basis Badge, Health Check Button
        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = colors.bgElev,
                border = BorderStroke(colors.defaultBorderWidth, colors.borderStrong),
                modifier = Modifier.clickable { showRangeSheet = true }
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    StayarIcon("calendar", tint = colors.accent, size = 16.dp)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "بازه: $rangeText",
                        fontSize = 12.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.text
                    )
                }
            }

            val basisText = if (r.basis == "commitment") {
                "مبنای سود: تعهدی (تسویه نهایی)"
            } else {
                "مبنای سود: نقدی"
            }
            BadgePill(
                textFa = basisText,
                color = colors.info,
                modifier = Modifier.padding(vertical = 4.dp)
            )

            Surface(
                shape = RoundedCornerShape(10.dp),
                color = colors.bgElev,
                border = BorderStroke(colors.defaultBorderWidth, colors.borderStrong),
                modifier = Modifier.clickable { onNavigate("health") }
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    StayarIcon("shield", tint = colors.accent, size = 16.dp)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "سنجش سلامت",
                        fontSize = 12.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.text
                    )
                }
            }
        }

        // 3. Engine Errors Banner
        if (r.errors.isNotEmpty()) {
            val extraCount = r.errors.size - 1
            val extraSuffix = if (extraCount > 0) f(" (و $extraCount مورد دیگر)") else ""
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = colors.danger.copy(alpha = 0.12f),
                border = BorderStroke(colors.defaultBorderWidth, colors.danger),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "${r.errors.first()}$extraSuffix",
                        fontSize = 12.5.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = colors.danger,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedButton(
                        onClick = { onNavigate("health") },
                        border = BorderStroke(1.dp, colors.danger)
                    ) {
                        Text("بررسی", color = colors.danger, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // 4. Empty Project Onboarding Card
        if (!hasAnyData) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = colors.bgElev,
                border = BorderStroke(2.dp, colors.accent),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "پروژه هنوز داده‌ای ندارد",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.text
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "از «کاربران» شروع کنید، نرخ دستمزد را ثبت کنید و حضور و غیاب را پر کنید. یا یک پروژه نمونه بسازید تا با برنامه آشنا شوید.",
                        fontSize = 13.5.sp,
                        color = colors.textDim
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { onNavigate("attendance") },
                            colors = ButtonDefaults.buttonColors(containerColor = colors.accent)
                        ) {
                            Text("شروع حضور و غیاب", color = colors.onAccent, fontWeight = FontWeight.Bold)
                        }
                        OutlinedButton(
                            onClick = onCreateSampleProject,
                            border = BorderStroke(colors.defaultBorderWidth, colors.accent)
                        ) {
                            Text("ساخت پروژه نمونه", color = colors.accent, fontWeight = FontWeight.Bold)
                        }
                        OutlinedButton(
                            onClick = onOpenPracticeChooser,
                            border = BorderStroke(colors.defaultBorderWidth, colors.borderStrong)
                        ) {
                            Text("آموزش گام‌به‌گام", color = colors.text, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
        }

        // 5. KPI Bento Grid
        KpiBentoSection(
            r = r,
            isTutorialProfitRulerStep = isTutorialRulerStep,
            onOpenProfitRuler = onOpenProfitRuler,
            questCoordinator = questCoordinator
        )

        // 6. Masters Section («سهم و مانده اوستاها»)
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                text = "سهم و مانده اوستاها",
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
                color = colors.text
            )
            if (r.masters.isEmpty()) {
                Text("اوستایی تعریف نشده است.", color = colors.textDim, fontSize = 13.5.sp)
            } else {
                for (m in r.masters) {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = colors.bgElev,
                        border = BorderStroke(colors.defaultBorderWidth, colors.borderStrong),
                        modifier = Modifier
                            .fillMaxWidth()
                            .tiltCard()
                            .questTarget("master_card_${m.id}", questCoordinator)
                            .clickable { onOpenStatementForUser(m.id) }
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = m.name,
                                    fontSize = 15.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = colors.text
                                )
                                if (m.active) {
                                    BadgePill(
                                        textFa = f("${TextNormalizer.pctText(m.percent)}٪ سهم"),
                                        color = colors.accent
                                    )
                                } else {
                                    BadgePill(textFa = "غیرفعال", color = colors.textDim)
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))
                            LinearProgressIndicator(
                                progress = { m.percent.toFloat().coerceIn(0f, 1f) },
                                color = colors.accent,
                                trackColor = colors.bgElev2,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = f("کارکرد: ${TextNormalizer.fmtDays(m.days)} روز × ${TextNormalizer.fmtDays(m.workFactor)}"),
                                    fontSize = 12.5.sp,
                                    color = colors.textDim
                                )
                                Text(
                                    text = f("سهم پایه: ${TextNormalizer.fmt(m.share)}"),
                                    fontSize = 12.5.sp,
                                    color = colors.textDim
                                )
                            }

                            HorizontalDivider(
                                color = colors.border,
                                modifier = Modifier.padding(vertical = 8.dp)
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "مانده تسویه نهایی",
                                    fontSize = 13.sp,
                                    color = colors.textDim
                                )
                                MoneyText(
                                    amount = m.finalBalance,
                                    showUnit = true,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = if (m.finalBalance >= 0L) colors.success else colors.danger
                                )
                            }
                        }
                    }
                }
            }
        }

        // 7. Negative-Balance Matrix
        NegativeBalanceMatrixSection(
            negativeMasters = r.negativeMasters,
            allMasters = r.masters,
            onSettleToFund = onSettleNegativeMasterToFund,
            onTransferToPeer = onTransferNegativeMasterToPeer,
            questCoordinator = questCoordinator
        )

        // 8. Staff Balance Table («تراز حساب شاگردان و پرسنل سایر»)
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                text = "تراز حساب شاگردان و پرسنل سایر",
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
                color = colors.text
            )
            if (r.staff.isEmpty()) {
                Text("شاگرد یا پرسنلی تعریف نشده است.", color = colors.textDim, fontSize = 13.5.sp)
            } else {
                for (s in r.staff) {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = colors.bgElev,
                        border = BorderStroke(colors.defaultBorderWidth, colors.borderStrong),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onOpenStatementForUser(s.id) }
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text(s.name, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = colors.text)
                                    BadgePill(s.type.labelFa, colors.info)
                                }
                                val statusBadge = when {
                                    s.debt > 0L -> "طلبکار" to colors.success
                                    s.debt < 0L -> "بدهکار" to colors.danger
                                    else -> "تسویه" to colors.textDim
                                }
                                BadgePill(statusBadge.first, statusBadge.second)
                            }

                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = f("روز: ${TextNormalizer.fmtDays(s.days)} (کامل ${s.full} · نصفه ${s.half} · ساعتی ${s.hourly})"),
                                fontSize = 12.sp,
                                color = colors.textDim
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = f("استحقاقی: ${TextNormalizer.fmt(s.entitled)}"),
                                    fontSize = 12.5.sp,
                                    color = colors.textDim
                                )
                                Text(
                                    text = f("پرداختی: ${TextNormalizer.fmt(s.totalPaid)}"),
                                    fontSize = 12.5.sp,
                                    color = colors.textDim
                                )
                            }
                            HorizontalDivider(color = colors.border, modifier = Modifier.padding(vertical = 6.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("مانده", fontSize = 13.sp, color = colors.textDim)
                                MoneyText(
                                    amount = s.debt,
                                    showUnit = true,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = when {
                                        s.debt > 0L -> colors.success
                                        s.debt < 0L -> colors.danger
                                        else -> colors.text
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }

        // 9. Interactive Compose Canvas Charts
        AnalyticsChartsSection(project = project, r = r)
    }

    if (showRangeSheet) {
        ReportRangeSheet(
            currentRange = r.range,
            onApplyRange = { from, to ->
                showRangeSheet = false
                onUpdateReportRange(from, to)
            },
            onDismiss = { showRangeSheet = false }
        )
    }
}

@Composable
fun ReportRangeSheet(
    currentRange: ReportRange,
    onApplyRange: (from: String, to: String) -> Unit,
    onDismiss: () -> Unit
) {
    val colors = StayarTheme.colors
    var fromStr by remember { mutableStateOf(currentRange.from) }
    var toStr by remember { mutableStateOf(currentRange.to) }
    val today = remember { JalaliCalendarEngine.jTodayDate() }

    TactileSheet(titleFa = "بازه گزارش", onDismissRequest = onDismiss) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedButton(
                onClick = {
                    val mLen = JalaliCalendarEngine.jalaaliMonthLength(today.year, today.month)
                    fromStr = "%04d/%02d/01".format(Locale.US, today.year, today.month)
                    toStr = "%04d/%02d/%02d".format(Locale.US, today.year, today.month, mLen)
                },
                modifier = Modifier.weight(1f)
            ) {
                Text("این ماه", fontSize = 12.5.sp, color = colors.text)
            }
            OutlinedButton(
                onClick = {
                    val prevYm = JalaliCalendarEngine.jAddMonths("%04d/%02d".format(Locale.US, today.year, today.month), -1)
                    val parts = prevYm.split("/")
                    val py = parts[0].toInt()
                    val pm = parts[1].toInt()
                    val mLen = JalaliCalendarEngine.jalaaliMonthLength(py, pm)
                    fromStr = "%04d/%02d/01".format(Locale.US, py, pm)
                    toStr = "%04d/%02d/%02d".format(Locale.US, py, pm, mLen)
                },
                modifier = Modifier.weight(1f)
            ) {
                Text("ماه قبل", fontSize = 12.5.sp, color = colors.text)
            }
            OutlinedButton(
                onClick = {
                    fromStr = ""
                    toStr = ""
                },
                modifier = Modifier.weight(1f)
            ) {
                Text("همه دوره", fontSize = 12.5.sp, color = colors.text)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))
        OutlinedTextField(
            value = fromStr,
            onValueChange = { fromStr = it },
            label = { Text("از تاریخ (خالی = از ابتدا)") },
            placeholder = { Text("1405/08/01") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(
            value = toStr,
            onValueChange = { toStr = it },
            label = { Text("تا تاریخ (خالی = تا امروز)") },
            placeholder = { Text("1405/08/30") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(14.dp))
        Button(
            onClick = { onApplyRange(fromStr.trim(), toStr.trim()) },
            colors = ButtonDefaults.buttonColors(containerColor = colors.accent),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
        ) {
            Text("اعمال بازه", color = colors.onAccent, fontWeight = FontWeight.Bold)
        }
    }
}
