package com.workshop.ledger.presentation.screens.attendance

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.workshop.ledger.domain.engine.AccountingEngine
import com.workshop.ledger.domain.engine.JalaliCalendarEngine
import com.workshop.ledger.domain.engine.TextNormalizer
import com.workshop.ledger.domain.model.AttendanceValue
import com.workshop.ledger.domain.model.Project
import com.workshop.ledger.domain.model.User
import com.workshop.ledger.presentation.components.BadgePill
import com.workshop.ledger.presentation.components.tiltCard
import com.workshop.ledger.presentation.theme.StayarIcon
import com.workshop.ledger.presentation.theme.StayarTheme
import com.workshop.ledger.presentation.tutorial.QuestCoordinator
import com.workshop.ledger.presentation.tutorial.questTarget

@Composable
fun AttendanceCardView(
    project: Project,
    activeUsers: List<User>,
    selectedDateStr: String,
    coachDismissed: Boolean,
    onDismissCoach: () -> Unit,
    onSelectPrevDay: () -> Unit,
    onSelectNextDay: () -> Unit,
    onOpenDatePicker: () -> Unit,
    onMarkAllPresent: () -> Unit,
    onToggleAttendance: (user: User, value: AttendanceValue) -> Unit,
    onOpenHourPicker: (user: User, initialHours: Double) -> Unit,
    questCoordinator: QuestCoordinator? = null
) {
    val colors = StayarTheme.colors
    val digitsMode = StayarTheme.digitsMode
    val f = { s: String -> TextNormalizer.formatDisplayDigits(s, digitsMode) }
    var searchQuery by remember { mutableStateOf("") }
    var showMarkAllConfirm by remember { mutableStateOf(false) }

    val todayStr = remember { JalaliCalendarEngine.jTodayStr() }
    val weekdayName = JalaliCalendarEngine.jDowStr(selectedDateStr)
    val daySubtitle = buildString {
        append(weekdayName)
        if (selectedDateStr == todayStr) append(" — امروز")
        else if (selectedDateStr > todayStr) append(" — ⚠ آینده")
    }
    val parsedSelected = JalaliCalendarEngine.jParse(selectedDateStr)
    val bigDateTitle = if (parsedSelected != null) {
        val mName = JalaliCalendarEngine.MONTHS_FA.getOrElse(parsedSelected.month - 1) { "" }
        f("${parsedSelected.day} $mName")
    } else {
        f(selectedDateStr)
    }

    val filteredUsers = remember(activeUsers, searchQuery) {
        if (searchQuery.isBlank()) {
            activeUsers
        } else {
            val q = TextNormalizer.normFa(searchQuery)
            activeUsers.filter { u ->
                TextNormalizer.normFa("${u.name} ${u.role} ${u.type.labelFa}").contains(q)
            }
        }
    }

    val dayMap = project.attendance[selectedDateStr].orEmpty()
    val absentPenalty = AccountingEngine.sanitizeAbsentPenalty(project.settings.absentPenalty)

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { Spacer(modifier = Modifier.height(4.dp)) }

        // First-time coach tip
        if (!coachDismissed) {
            item {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = colors.info.copy(alpha = 0.12f),
                    border = BorderStroke(colors.defaultBorderWidth, colors.info),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "با یک لمس وضعیت هر نفر را ثبت کنید؛ لمس دوبارهٔ همان دکمه، وضعیت را پاک می‌کند. برای تغییر روز، روی تاریخ درخشان بزنید.",
                            fontSize = 12.5.sp,
                            color = colors.text,
                            modifier = Modifier.weight(1f)
                        )
                        TextButton(onClick = onDismissCoach) {
                            Text("فهمیدم", fontWeight = FontWeight.Bold, color = colors.info)
                        }
                    }
                }
            }
        }

        // Glowing 3D-Tilt Date Card
        item {
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = colors.bgElev,
                border = BorderStroke(2.dp, colors.accent),
                shadowElevation = 4.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .tiltCard()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    OutlinedButton(
                        onClick = onSelectPrevDay,
                        border = BorderStroke(colors.defaultBorderWidth, colors.borderStrong)
                    ) {
                        Text("روز قبل", color = colors.text, fontWeight = FontWeight.SemiBold, fontSize = 12.5.sp)
                    }

                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .weight(1f)
                            .clickable(onClick = onOpenDatePicker)
                            .padding(horizontal = 8.dp)
                    ) {
                        Text(daySubtitle, fontSize = 12.sp, color = colors.accent, fontWeight = FontWeight.Bold)
                        Text(bigDateTitle, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = colors.text)
                        Text(f(selectedDateStr), fontSize = 12.sp, color = colors.textDim)
                    }

                    OutlinedButton(
                        onClick = onSelectNextDay,
                        border = BorderStroke(colors.defaultBorderWidth, colors.borderStrong)
                    ) {
                        Text("روز بعد", color = colors.text, fontWeight = FontWeight.SemiBold, fontSize = 12.5.sp)
                    }
                }
            }
        }

        // Search + «حاضر زدن همه» Toolbar
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("جستجوی نام...") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                Button(
                    onClick = { showMarkAllConfirm = true },
                    colors = ButtonDefaults.buttonColors(containerColor = colors.accent),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.height(54.dp)
                ) {
                    StayarIcon("check", tint = colors.onAccent, size = 18.dp)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("حاضر زدن همه", color = colors.onAccent, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }

        // Person Attendance Cards
        items(filteredUsers, key = { it.id }) { user ->
            val currentVal = dayMap[user.id]
            val fraction = AccountingEngine.attFr(currentVal, project)
            PersonAttendanceCard(
                user = user,
                currentVal = currentVal,
                fraction = fraction,
                absentPenalty = absentPenalty,
                onTapFull = { onToggleAttendance(user, AttendanceValue.Full) },
                onTapHalf = { onToggleAttendance(user, AttendanceValue.Half) },
                onTapHourly = {
                    val initH = (currentVal as? AttendanceValue.Hourly)?.hours ?: 8.0
                    onOpenHourPicker(user, initH)
                },
                onTapAbsent = { onToggleAttendance(user, AttendanceValue.Absent) },
                questCoordinator = questCoordinator
            )
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }

    if (showMarkAllConfirm) {
        AlertDialog(
            onDismissRequest = { showMarkAllConfirm = false },
            containerColor = colors.bgElev,
            title = {
                Text("حاضر زدن همه", fontWeight = FontWeight.Bold, color = colors.text)
            },
            text = {
                Text(
                    text = "برای همهٔ پرسنل فعال در تاریخ ${f(selectedDateStr)} وضعیت «کامل (۸ ساعت)» ثبت می‌شود و وضعیت قبلی جایگزین خواهد شد. ادامه می‌دهید؟",
                    color = colors.text
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showMarkAllConfirm = false
                        onMarkAllPresent()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = colors.accent)
                ) {
                    Text("بله، حاضر بزن", color = colors.onAccent, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showMarkAllConfirm = false }) {
                    Text("انصراف", color = colors.text)
                }
            }
        )
    }
}

@Composable
fun PersonAttendanceCard(
    user: User,
    currentVal: AttendanceValue?,
    fraction: Double?,
    absentPenalty: Double,
    onTapFull: () -> Unit,
    onTapHalf: () -> Unit,
    onTapHourly: () -> Unit,
    onTapAbsent: () -> Unit,
    questCoordinator: QuestCoordinator? = null
) {
    val colors = StayarTheme.colors
    val digitsMode = StayarTheme.digitsMode
    val f = { s: String -> TextNormalizer.formatDisplayDigits(s, digitsMode) }

    val roleSubtitle = if (user.role.isNotBlank() && user.role != user.type.labelFa) {
        "${user.role} · ${user.type.labelFa}"
    } else {
        user.type.labelFa
    }

    Surface(
        shape = RoundedCornerShape(16.dp),
        color = colors.bgElev,
        border = BorderStroke(colors.defaultBorderWidth, colors.borderStrong),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = colors.accent.copy(alpha = 0.16f),
                        border = BorderStroke(1.dp, colors.accent),
                        modifier = Modifier.size(42.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = user.name.firstOrNull()?.toString() ?: "ک",
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 16.sp,
                                color = colors.accent
                            )
                        }
                    }
                    Column {
                        Text(user.name, fontSize = 15.5.sp, fontWeight = FontWeight.Bold, color = colors.text)
                        Text(roleSubtitle, fontSize = 12.sp, color = colors.textDim)
                    }
                }

                // Status badge on left (RTL end)
                if (fraction != null) {
                    val badgeColor = if (currentVal == AttendanceValue.Absent) colors.danger else colors.success
                    BadgePill(
                        textFa = f("${TextNormalizer.fmtDays(fraction)} روز"),
                        color = badgeColor
                    )
                } else {
                    BadgePill(textFa = "ثبت نشده", color = colors.textDim)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Four large tactile buttons (min-height 72.dp, spring statusPop scale animation)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StatusTactileButton(
                    titleFa = "کامل",
                    subFa = "۸ ساعت",
                    isActive = currentVal == AttendanceValue.Full,
                    activeColor = colors.success,
                    onClick = onTapFull,
                    modifier = Modifier
                        .weight(1f)
                        .questTarget("att_btn_full_${user.id}", questCoordinator)
                )

                StatusTactileButton(
                    titleFa = "نصفه",
                    subFa = "۴ ساعت",
                    isActive = currentVal == AttendanceValue.Half,
                    activeColor = colors.warn,
                    onClick = onTapHalf,
                    modifier = Modifier
                        .weight(1f)
                        .questTarget("att_btn_half_${user.id}", questCoordinator)
                )

                val hourlyActive = currentVal is AttendanceValue.Hourly
                val hourlyTitle = if (hourlyActive) {
                    val h = (currentVal as AttendanceValue.Hourly).hours
                    "${TextNormalizer.hrFa(h)} ساعت"
                } else {
                    "ساعتی"
                }
                val hourlySub = if (hourlyActive) "تغییر" else "اضافه‌کار"
                StatusTactileButton(
                    titleFa = hourlyTitle,
                    subFa = hourlySub,
                    isActive = hourlyActive,
                    activeColor = colors.info,
                    onClick = onTapHourly,
                    modifier = Modifier
                        .weight(1f)
                        .questTarget("att_btn_hourly_${user.id}", questCoordinator)
                )

                val absentSub = if (absentPenalty > 0.0) {
                    "کسر ${TextNormalizer.hrFa(absentPenalty)} روز"
                } else {
                    "صفر"
                }
                StatusTactileButton(
                    titleFa = "غایب",
                    subFa = absentSub,
                    isActive = currentVal == AttendanceValue.Absent,
                    activeColor = colors.danger,
                    onClick = onTapAbsent,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun StatusTactileButton(
    titleFa: String,
    subFa: String,
    isActive: Boolean,
    activeColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = StayarTheme.colors
    val scale by animateFloatAsState(
        targetValue = if (isActive) 1.04f else 1.0f,
        animationSpec = spring(dampingRatio = 0.5f, stiffness = 500f),
        label = "statusPop"
    )

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = if (isActive) activeColor.copy(alpha = 0.20f) else colors.bgElev2,
        border = BorderStroke(
            width = if (isActive) 2.dp else colors.defaultBorderWidth,
            color = if (isActive) activeColor else colors.borderStrong
        ),
        modifier = modifier
            .heightIn(min = 72.dp)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .clickable(onClick = onClick)
    ) {
        Column(
            modifier = Modifier.padding(vertical = 10.dp, horizontal = 4.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = titleFa,
                fontSize = 13.5.sp,
                fontWeight = FontWeight.ExtraBold,
                color = if (isActive) activeColor else colors.text,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subFa,
                fontSize = 11.sp,
                fontWeight = if (isActive) FontWeight.Bold else FontWeight.Medium,
                color = if (isActive) activeColor else colors.textDim,
                textAlign = TextAlign.Center
            )
        }
    }
}
