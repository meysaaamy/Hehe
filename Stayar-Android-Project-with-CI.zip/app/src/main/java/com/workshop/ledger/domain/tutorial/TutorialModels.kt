package com.workshop.ledger.domain.tutorial

import com.workshop.ledger.domain.model.AccountingResult
import com.workshop.ledger.domain.model.Project
import kotlinx.serialization.Serializable

@Serializable
data class OnboardingState(
    val status: String = "not_started", // "not_started" | "in_quest" | "completed" | "skipped"
    val questStep: Int = 0, // 0..27
    val sandboxProjectId: String? = null,
    val chapter: Int = 1 // 1..3
)

data class AimTarget(
    val page: String,
    val targetId: String,
    val hintFa: String = ""
)

data class TutorialPreset(
    val fields: Map<String, String> = emptyMap(),
    val labelFa: String = "پر کردن خودکار نمونه"
)

data class TutorialStep(
    val index: Int, // 0..27
    val chapter: Int, // 1..3
    val stepInChapter: Int,
    val id: String,
    val titleFa: String,
    val sayFa: String,
    val aim: AimTarget,
    val preset: TutorialPreset? = null,
    val guardMessageFa: String? = null,
    val done: (Project, AccountingResult, TutorialRuntimeEvents) -> Boolean,
    val resultFa: (Project, AccountingResult) -> String
)

data class TutorialRuntimeEvents(
    val currentPage: String = "dashboard",
    val openedProfitRuler: Boolean = false,
    val viewedStatementUserId: String? = null,
    val exportedReportOrBackup: Boolean = false,
    val attemptedLockedEdit: Boolean = false,
    val visitedHealthPage: Boolean = false
)
