package com.workshop.ledger.presentation.screens.crud

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.workshop.ledger.domain.engine.TextNormalizer
import com.workshop.ledger.domain.model.AccountingResult
import com.workshop.ledger.domain.model.Project
import com.workshop.ledger.domain.model.User
import com.workshop.ledger.domain.model.UserType
import com.workshop.ledger.presentation.components.TactileSheet
import com.workshop.ledger.presentation.theme.StayarTheme
import kotlin.math.abs

@Composable
fun UserDeleteSheet(
    project: Project,
    accountingResult: AccountingResult,
    user: User,
    onDeactivateUser: (User) -> Unit,
    onConfirmHardDelete: (User) -> Unit,
    onDismiss: () -> Unit
) {
    val colors = StayarTheme.colors
    val digitsMode = StayarTheme.digitsMode
    val f = { s: String -> TextNormalizer.formatDisplayDigits(s, digitsMode) }

    val attCount = project.attendance.values.count { it.containsKey(user.id) }
    val wageCount = project.wages.count { it.userId == user.id }
    val payoutCount = project.payouts.count { it.userId == user.id }
    val adjCount = project.adjustments.count { it.userId == user.id }
    val transferCount = project.transfers.count { it.fromId == user.id || it.toId == user.id }
    val expCount = project.expenses.count { it.payerId == user.id }
    val totalHistory = attCount + wageCount + payoutCount + adjCount + transferCount + expCount

    val currentBalance = if (user.type == UserType.MASTER) {
        accountingResult.masters.find { it.id == user.id }?.finalBalance ?: 0L
    } else {
        accountingResult.staff.find { it.id == user.id }?.debt ?: 0L
    }

    var armedForHardDelete by remember { mutableStateOf(false) }

    TactileSheet(
        titleFa = "حذف «${user.name}»",
        onDismissRequest = onDismiss
    ) {
        if (totalHistory > 0) {
            Text(
                text = "با حذف کامل این کاربر، سوابق زیر برای همیشه پاک یا بازتخصیص می‌شود:",
                fontSize = 13.5.sp,
                fontWeight = FontWeight.SemiBold,
                color = colors.text
            )
            Spacer(modifier = Modifier.height(8.dp))

            val parts = mutableListOf<String>()
            if (attCount > 0) parts.add(f("$attCount روز حضور"))
            if (wageCount > 0) parts.add(f("$wageCount نرخ دستمزد"))
            if (payoutCount > 0) parts.add(f("$payoutCount پرداختی"))
            if (adjCount > 0) parts.add(f("$adjCount تعدیل (پاداش، جریمه، مساعده)"))
            if (transferCount > 0) parts.add(f("$transferCount انتقال یا پیش‌برداشت"))
            if (expCount > 0) parts.add(f("$expCount هزینه‌ای که او پرداخت‌کننده‌اش بود"))

            Surface(
                shape = RoundedCornerShape(12.dp),
                color = colors.bgElev2,
                border = BorderStroke(colors.defaultBorderWidth, colors.borderStrong),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = parts.joinToString(" · "),
                    fontSize = 13.sp,
                    color = colors.text,
                    modifier = Modifier.padding(12.dp)
                )
            }

            if (currentBalance != 0L) {
                Spacer(modifier = Modifier.height(8.dp))
                val statusWord = if (currentBalance > 0L) "طلبکار" else "بدهکار"
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = colors.danger.copy(alpha = 0.14f),
                    border = BorderStroke(1.dp, colors.danger),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = f("تراز فعلی او ${TextNormalizer.fmt(abs(currentBalance))} تومان $statusWord است؛ با حذف کامل، این مبلغ از حساب‌ها محو می‌شود."),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.danger,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }
        } else {
            Text(
                text = "این کاربر هنوز هیچ سابقهٔ مالی یا حضوری ندارد و قابل حذف است.",
                fontSize = 13.5.sp,
                color = colors.textDim
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (totalHistory > 0 && user.active) {
                Button(
                    onClick = {
                        onDeactivateUser(user)
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = colors.accent),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                ) {
                    Text(
                        text = "غیرفعال‌سازی (پیشنهادی)",
                        color = colors.onAccent,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Button(
                onClick = {
                    if (totalHistory > 0 && !armedForHardDelete) {
                        armedForHardDelete = true
                    } else {
                        onConfirmHardDelete(user)
                        onDismiss()
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = colors.danger),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
            ) {
                val label = when {
                    totalHistory == 0 -> "حذف"
                    armedForHardDelete -> "مطمئنم؛ برای همیشه حذف شود"
                    else -> "حذف کامل با همهٔ سوابق"
                }
                Text(label, color = colors.onAccent, fontWeight = FontWeight.Bold)
            }

            OutlinedButton(
                onClick = onDismiss,
                border = BorderStroke(colors.defaultBorderWidth, colors.borderStrong),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
            ) {
                Text("انصراف", color = colors.text, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}
