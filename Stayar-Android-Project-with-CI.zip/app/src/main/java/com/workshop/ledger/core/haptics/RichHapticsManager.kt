package com.workshop.ledger.core.haptics

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.HapticFeedbackConstants
import android.view.View

class RichHapticsManager(context: Context) {

    var hapticsEnabled: Boolean = true

    private val vibrator: Vibrator? by lazy {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vm?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }
        } catch (_: Throwable) {
            null
        }
    }

    fun clockTick(view: View? = null) {
        if (!hapticsEnabled) return
        if (view != null) {
            view.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
        } else {
            oneShot(4L, 60)
        }
    }

    fun detent(ms: Long = 5L) = oneShot(ms, 70)

    fun tap() = oneShot(8L, 110)

    fun save() = oneShot(10L, 140)

    fun confirm(ms: Long = 15L) = oneShot(ms, 170)

    fun errorOrLock() = oneShot(20L, 210)

    fun lockedPeriodAttempt() = oneShot(25L, 240)

    fun graduation() = oneShot(30L, 255)

    fun oneShot(durationMs: Long, amplitude: Int = VibrationEffect.DEFAULT_AMPLITUDE) {
        if (!hapticsEnabled) return
        try {
            val vib = vibrator ?: return
            if (!vib.hasVibrator()) return
            val safeAmp = if (amplitude == VibrationEffect.DEFAULT_AMPLITUDE) {
                VibrationEffect.DEFAULT_AMPLITUDE
            } else {
                amplitude.coerceIn(1, 255)
            }
            vib.vibrate(VibrationEffect.createOneShot(durationMs.coerceAtLeast(1L), safeAmp))
        } catch (_: Throwable) {
        }
    }
}
