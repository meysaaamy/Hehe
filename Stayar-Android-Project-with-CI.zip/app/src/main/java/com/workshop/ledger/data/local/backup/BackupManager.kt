package com.workshop.ledger.data.local.backup

import android.content.Context
import android.util.AtomicFile
import com.workshop.ledger.domain.model.AppState
import com.workshop.ledger.domain.model.DomainConstants
import com.workshop.ledger.domain.model.Project
import com.workshop.ledger.domain.validation.ProjectSanitizer
import com.workshop.ledger.domain.validation.StateValidator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.decodeFromStream
import kotlinx.serialization.json.encodeToStream
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.util.zip.GZIPInputStream
import java.util.zip.GZIPOutputStream

data class BackupSlotInfo(
    val slot: Int,
    val file: File,
    val lastModifiedMs: Long,
    val sizeBytes: Long
)

sealed interface ImportValidationPreview {
    data class ValidFullBackup(
        val state: AppState,
        val fixesCount: Int
    ) : ImportValidationPreview

    data class ValidSingleProject(
        val project: Project,
        val fixesCount: Int
    ) : ImportValidationPreview

    data class Invalid(val errorMessageFa: String) : ImportValidationPreview
}

class BackupManager(private val context: Context) {

    val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
        prettyPrint = false
        isLenient = true
    }

    private val backupsDir: File
        get() = File(context.filesDir, "backups").apply { mkdirs() }

    val recoverySnapshotFile: File
        get() = File(backupsDir, "recovery_snapshot.json.gz")

    private fun rollingSlotFile(slot: Int): File =
        File(backupsDir, "rolling_snap_${slot.coerceIn(1, 3)}.json.gz")

    private var lastRollingSlot = 0
    private var lastStateHash = 0

    /**
     * Writes an AtomicFile GZIP emergency recovery snapshot BEFORE any destructive action.
     * Strictly aborts and returns false if the snapshot cannot be persisted.
     */
    suspend fun writeEmergencySnapshot(state: AppState, reason: String): Boolean =
        withContext(Dispatchers.IO) {
            writeAtomicGzip(recoverySnapshotFile, state)
        }

    /**
     * Executes a destructive or state-replacing action only if an AtomicFile emergency
     * recovery snapshot is persisted first.
     */
    suspend fun <T> executeDestructiveAction(
        reason: String,
        currentStateProvider: suspend () -> AppState,
        onSnapshotFailed: () -> Unit,
        block: suspend () -> T
    ): T? {
        val currentState = try {
            currentStateProvider()
        } catch (_: Throwable) {
            onSnapshotFailed()
            return null
        }
        val persisted = writeEmergencySnapshot(currentState, reason)
        if (!persisted) {
            onSnapshotFailed()
            return null
        }
        return block()
    }

    suspend fun writeRollingAutoBackup(state: AppState, force: Boolean = false): Boolean =
        withContext(Dispatchers.IO) {
            val hash = state.hashCode()
            if (!force && hash == lastStateHash) return@withContext false
            val nextSlot = (lastRollingSlot % 3) + 1
            val ok = writeAtomicGzip(rollingSlotFile(nextSlot), state)
            if (ok) {
                lastRollingSlot = nextSlot
                lastStateHash = hash
            }
            ok
        }

    fun getEmergencySnapshotInfo(): BackupSlotInfo? {
        val f = recoverySnapshotFile
        if (!f.exists() || f.length() == 0L) return null
        return BackupSlotInfo(0, f, f.lastModified(), f.length())
    }

    fun getRollingSnapshots(): List<BackupSlotInfo> {
        return (1..3).mapNotNull { slot ->
            val f = rollingSlotFile(slot)
            if (f.exists() && f.length() > 0L) {
                BackupSlotInfo(slot, f, f.lastModified(), f.length())
            } else {
                null
            }
        }.sortedByDescending { it.lastModifiedMs }
    }

    suspend fun readSnapshotFile(file: File): AppState? = withContext(Dispatchers.IO) {
        if (!file.exists()) return@withContext null
        try {
            val atomicFile = AtomicFile(file)
            atomicFile.openRead().use { fis ->
                GZIPInputStream(fis).use { gis ->
                    json.decodeFromStream<AppState>(gis)
                }
            }
        } catch (_: Throwable) {
            null
        }
    }

    private fun writeAtomicGzip(target: File, state: AppState): Boolean {
        val atomicFile = AtomicFile(target)
        var fos: java.io.FileOutputStream? = null
        return try {
            fos = atomicFile.startWrite()
            GZIPOutputStream(fos).use { gos ->
                json.encodeToStream(state, gos)
                gos.flush()
            }
            atomicFile.finishWrite(fos)
            true
        } catch (_: Throwable) {
            if (fos != null) {
                try {
                    atomicFile.failWrite(fos)
                } catch (_: Throwable) {
                }
            }
            false
        }
    }

    suspend fun exportFullStateToStream(state: AppState, outputStream: OutputStream): Boolean =
        withContext(Dispatchers.IO) {
            try {
                json.encodeToStream(state, outputStream)
                outputStream.flush()
                true
            } catch (_: Throwable) {
                false
            }
        }

    suspend fun exportProjectToStream(project: Project, outputStream: OutputStream): Boolean =
        withContext(Dispatchers.IO) {
            try {
                json.encodeToStream(project, outputStream)
                outputStream.flush()
                true
            } catch (_: Throwable) {
                false
            }
        }

    /**
     * Validates a streaming JSON import (up to 64 MiB) via ProjectSanitizer and StateValidator
     * BEFORE asking user confirmation.
     */
    suspend fun validateImportStream(
        inputStream: InputStream,
        knownSizeBytes: Long = -1L,
        expectFullState: Boolean = true
    ): ImportValidationPreview = withContext(Dispatchers.IO) {
        if (knownSizeBytes > DomainConstants.MAX_IMPORT_BYTES) {
            return@withContext ImportValidationPreview.Invalid("فایل پشتیبان بیش از ۶۴ مگابایت است")
        }
        val bytes = try {
            val buf = inputStream.readNBytes((DomainConstants.MAX_IMPORT_BYTES + 1L).toInt())
            if (buf.size.toLong() > DomainConstants.MAX_IMPORT_BYTES) {
                return@withContext ImportValidationPreview.Invalid("فایل پشتیبان بیش از ۶۴ مگابایت است")
            }
            buf
        } catch (_: Throwable) {
            return@withContext ImportValidationPreview.Invalid("خواندن فایل پشتیبان ناموفق بود.")
        }

        if (expectFullState) {
            val rawState = try {
                bytes.inputStream().use { json.decodeFromStream<AppState>(it) }
            } catch (_: Throwable) {
                return@withContext ImportValidationPreview.Invalid("ساختار فایل پشتیبان کامل معتبر نیست.")
            }
            val sanitized = ProjectSanitizer.sanitizeAppState(rawState)
            val validation = StateValidator.validateAppState(sanitized.value)
            if (!validation.ok) {
                return@withContext ImportValidationPreview.Invalid(
                    validation.firstError ?: "دادهٔ فایل پشتیبان معتبر نیست."
                )
            }
            ImportValidationPreview.ValidFullBackup(
                state = sanitized.value,
                fixesCount = sanitized.fixes
            )
        } else {
            val rawProject = try {
                bytes.inputStream().use { json.decodeFromStream<Project>(it) }
            } catch (_: Throwable) {
                return@withContext ImportValidationPreview.Invalid("ساختار فایل پروژه معتبر نیست.")
            }
            val sanitized = ProjectSanitizer.sanitizeProject(rawProject)
            val validation = StateValidator.validateProject(sanitized.value)
            if (!validation.ok) {
                return@withContext ImportValidationPreview.Invalid(
                    validation.firstError ?: "دادهٔ پروژه معتبر نیست."
                )
            }
            ImportValidationPreview.ValidSingleProject(
                project = sanitized.value,
                fixesCount = sanitized.fixes
            )
        }
    }
}
