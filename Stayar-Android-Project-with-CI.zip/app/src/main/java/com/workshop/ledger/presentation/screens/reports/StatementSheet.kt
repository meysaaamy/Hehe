package com.workshop.ledger.presentation.screens.reports

import android.graphics.Bitmap
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.workshop.ledger.core.document.StayarDocumentEngine
import com.workshop.ledger.domain.engine.StatementBuilder
import com.workshop.ledger.domain.engine.TextNormalizer
import com.workshop.ledger.domain.model.AccountingResult
import com.workshop.ledger.domain.model.Project
import com.workshop.ledger.domain.model.StatementModel
import com.workshop.ledger.domain.model.UserType
import com.workshop.ledger.presentation.components.BadgePill
import com.workshop.ledger.presentation.components.TactileSheet
import com.workshop.ledger.presentation.theme.MoneyText
import com.workshop.ledger.presentation.theme.StayarTheme
import kotlinx.coroutines.launch
import java.io.File

/**
 * Wide Statement Sheet (`«صورتحساب {name}»`, Section 11).
 * Displays full statement for staff or master according to Section 11 rules.
 * Buttons: `«تصویر A4»`, `«کپی متن»`, `«PDF»`, `«بستن»`.
 */
@Composable
fun StatementSheet(
    userId: String,
    project: Project,
    accountingResult: AccountingResult,
    documentEngine: StayarDocumentEngine,
    onDismiss: () -> Unit,
    onShowA4Preview: (title: String, pages: List<Bitmap>, baseName: String) -> Unit,
    onExportPdfFile: (File, String) -> Unit,
    onToast: (String) -> Unit
) {
    val colors = StayarTheme.colors
    val digitsMode = StayarTheme.digitsMode
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()
    val f = { s: String -> TextNormalizer.formatDisplayDigits(s, digitsMode) }

    val model: StatementModel? = remember(userId, project, accountingResult) {
        StatementBuilder.statementModel(project, userId, accountingResult)
    }

    if (model == null) {
        onDismiss()
        return
    }

    val isMaster = model.type == UserType.MASTER

    TactileSheet(
        title = "صورتحساب ${model.name}",
        onDismiss = onDismiss
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Header Block
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(colors.bgElev)
                    .border(1.dp, colors.borderStrong, RoundedCornerShape(14.dp))
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = f(model.name),
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 17.sp,
                        color = colors.text
                    )
                    BadgePill(
                        text = if (model.role.isNotBlank() && model.role != model.type.labelFa) {
                            "${model.type.labelFa} · ${model.role}"
                        } else {
                            model.type.labelFa
                        },
                        color = colors.accent
                    )
                }
                Text(
                    text = f("پروژه: ${project.name}   |   بازه: ${StatementBuilder.rangeTextFa(model.range, digitsMode)}"),
                    fontSize = 12.sp,
                    color = colors.textDim
                )
            }

            // Action Buttons Row: A4, Copy, PDF
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        scope.launch {
                            val blocks = documentEngine.buildStatementBlocks(project, model, digitsMode)
                            val rendered = documentEngine.renderA4Bitmaps(blocks, cropLastPage = true, digitsMode = digitsMode)
                            onShowA4Preview("تصویر A4 — صورتحساب ${model.name}", rendered.pages, "stayar-statement-${model.userId}")
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = colors.accent, contentColor = colors.onAccent),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("تصویر A4", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = {
                        scope.launch {
                            val blocks = documentEngine.buildStatementBlocks(project, model, digitsMode)
                            val exportDir = File(documentEngine.context.cacheDir, "exports").apply { mkdirs() }
                            val outFile = File(exportDir, "stayar-statement-${model.userId}.pdf")
                            documentEngine.renderVectorPdfToFile(blocks, outFile)
                            onExportPdfFile(outFile, outFile.name)
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = colors.accent2, contentColor = colors.onAccent),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("PDF", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                OutlinedButton(
                    onClick = {
                        val text = StatementBuilder.statementText(project, model.userId, accountingResult)
                        clipboard.setText(AnnotatedString(text))
                        onToast("متن صورتحساب در حافظه کپی شد")
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Text("کپی متن", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }

            // Daily Attendance Table Section
            Text(
                text = "کارکرد روزانه (${f(TextNormalizer.fmtDays(model.person.days))} روز)",
                fontWeight = FontWeight.ExtraBold,
                fontSize = 14.sp,
                color = colors.text
            )

            if (model.dailyRows.isEmpty()) {
                Text(
                    text = "حضوری در این بازه ثبت نشده است.",
                    fontSize = 12.sp,
                    color = colors.textDim
                )
            } else {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .border(1.dp, colors.border, RoundedCornerShape(12.dp))
                ) {
                    model.dailyRows.forEachIndexed { idx, row ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(if (idx % 2 == 0) colors.bgElev else colors.bgElev2)
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = f("${row.date} (${row.weekdayFa}) — ${row.statusLabelFa}"),
                                fontSize = 12.sp,
                                color = colors.text
                            )
                            if (!isMaster) {
                                MoneyText(
                                    amount = row.amount,
                                    unit = "تومان",
                                    fontSize = 12.sp,
                                    color = colors.text
                                )
                            }
                        }
                    }
                }
            }

            // Master Section or Staff Section
            if (isMaster && model.masterResult != null) {
                val m = model.masterResult
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(colors.bgElev)
                        .border(1.dp, colors.border, RoundedCornerShape(14.dp))
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = f("محاسبه سهم و تراز (ضریب ${m.workFactor} × ${TextNormalizer.fmtDays(m.days)} روز)"),
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 13.sp,
                        color = colors.text
                    )
                    StatementRow("درصد سهم از کارکرد", TextNormalizer.pctText(m.percent), formatDigits = f)
                    StatementRow("سود قابل تقسیم", "${f(TextNormalizer.fmt(accountingResult.profit))} تومان", formatDigits = f)
                    StatementRow("سهم پایه از سود", "${f(TextNormalizer.fmt(m.share))} تومان", formatDigits = f)
                    if (m.reimburse > 0L) {
                        StatementRow("+ بازپرداخت هزینه شخصی", "+${f(TextNormalizer.fmt(m.reimburse))} تومان", color = colors.success, formatDigits = f)
                    }
                    if (m.sharedPersonalExp > 0L) {
                        StatementRow("− سهم از هزینه‌های شخصی مشترک", "−${f(TextNormalizer.fmt(m.sharedPersonalExp))} تومان", color = colors.danger, formatDigits = f)
                    }
                    if (m.given > 0L) {
                        StatementRow("+ انتقال داده‌شده به دیگران", "+${f(TextNormalizer.fmt(m.given))} تومان", formatDigits = f)
                    }
                    if (m.taken > 0L) {
                        StatementRow("− انتقال گرفته‌شده از دیگران", "−${f(TextNormalizer.fmt(m.taken))} تومان", formatDigits = f)
                    }
                    if (m.advance > 0L) {
                        StatementRow("− پیش‌برداشت از صندوق", "−${f(TextNormalizer.fmt(m.advance))} تومان", color = colors.danger, formatDigits = f)
                    }
                    if (m.assistance > 0L) {
                        StatementRow("− مساعده", "−${f(TextNormalizer.fmt(m.assistance))} تومان", color = colors.danger, formatDigits = f)
                    }
                    if (m.bonus > 0L) {
                        StatementRow("+ پاداش", "+${f(TextNormalizer.fmt(m.bonus))} تومان", color = colors.success, formatDigits = f)
                    }
                    if (m.penalty > 0L) {
                        StatementRow("− جریمه", "−${f(TextNormalizer.fmt(m.penalty))} تومان", color = colors.danger, formatDigits = f)
                    }
                    if (m.settle > 0L) {
                        StatementRow("+ تسویه نقدی به صندوق", "+${f(TextNormalizer.fmt(m.settle))} تومان", color = colors.success, formatDigits = f)
                    }

                    HorizontalDivider(color = colors.border)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "مانده تسویه نهایی",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 14.sp,
                            color = if (m.finalBalance >= 0L) colors.success else colors.danger
                        )
                        MoneyText(
                            amount = m.finalBalance,
                            unit = "تومان",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 15.sp,
                            color = if (m.finalBalance >= 0L) colors.success else colors.danger
                        )
                    }
                }
            } else if (model.staffResult != null) {
                val s = model.staffResult
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(colors.bgElev)
                        .border(1.dp, colors.border, RoundedCornerShape(14.dp))
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "محاسبه نهایی دستمزد",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 13.sp,
                        color = colors.text
                    )
                    StatementRow("دستمزد پایه", "${f(TextNormalizer.fmt(s.baseWage))} تومان", formatDigits = f)
                    if (s.bonus > 0L) {
                        StatementRow("+ پاداش", "+${f(TextNormalizer.fmt(s.bonus))} تومان", color = colors.success, formatDigits = f)
                    }
                    if (s.penalty > 0L) {
                        StatementRow("− جریمه", "−${f(TextNormalizer.fmt(s.penalty))} تومان", color = colors.danger, formatDigits = f)
                    }
                    StatementRow("= دستمزد استحقاقی", "${f(TextNormalizer.fmt(s.entitled))} تومان", formatDigits = f)
                    if (s.paid > 0L) {
                        StatementRow("− پرداختی‌های نقدی", "−${f(TextNormalizer.fmt(s.paid))} تومان", color = colors.danger, formatDigits = f)
                    }
                    if (s.assistance > 0L) {
                        StatementRow("− مساعده", "−${f(TextNormalizer.fmt(s.assistance))} تومان", color = colors.danger, formatDigits = f)
                    }

                    HorizontalDivider(color = colors.border)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val label = if (s.debt >= 0L) "مانده طلبکار" else "اضافه‌پرداخت (بدهکار)"
                        Text(
                            text = label,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 14.sp,
                            color = if (s.debt >= 0L) colors.success else colors.danger
                        )
                        MoneyText(
                            amount = s.debt,
                            unit = "تومان",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 15.sp,
                            color = if (s.debt >= 0L) colors.success else colors.danger
                        )
                    }
                }
            }

            OutlinedButton(
                onClick = onDismiss,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("بستن", fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
private fun StatementRow(
    label: String,
    value: String,
    color: androidx.compose.ui.graphics.Color = androidx.compose.ui.graphics.Color.Unspecified,
    formatDigits: (String) -> String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, fontSize = 12.sp)
        Text(
            text = formatDigits(value),
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = color
        )
    }
}
