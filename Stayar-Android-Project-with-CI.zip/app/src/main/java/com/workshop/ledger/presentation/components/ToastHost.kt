package com.workshop.ledger.presentation.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.workshop.ledger.data.local.datastore.NotifVerbosity
import com.workshop.ledger.presentation.theme.StayarTheme
import kotlinx.coroutines.delay

enum class ToastKind {
    INFO,
    SUCCESS,
    WARN,
    ERROR
}

data class StayarToastMessage(
    val id: Long = System.nanoTime(),
    val textFa: String,
    val kind: ToastKind = ToastKind.INFO,
    val durationMs: Long = 3500L,
    val forced: Boolean = false,
    val actionLabelFa: String? = null,
    val onAction: (() -> Unit)? = null
)

class StayarToastState {
    var currentToast by mutableStateOf<StayarToastMessage?>(null)
        private set

    fun show(
        textFa: String,
        kind: ToastKind = ToastKind.INFO,
        durationMs: Long = 3500L,
        forced: Boolean = false,
        verbosity: NotifVerbosity = NotifVerbosity.ALL,
        actionLabelFa: String? = null,
        onAction: (() -> Unit)? = null
    ) {
        if (!forced) {
            if (verbosity == NotifVerbosity.MIN && kind != ToastKind.ERROR) return
            if (verbosity == NotifVerbosity.LESS && textFa == "ذخیره شد") return
        }
        currentToast = StayarToastMessage(
            textFa = textFa,
            kind = kind,
            durationMs = durationMs,
            forced = forced,
            actionLabelFa = actionLabelFa,
            onAction = onAction
        )
    }

    fun dismiss() {
        currentToast = null
    }
}

@Composable
fun StayarToastHost(
    state: StayarToastState,
    modifier: Modifier = Modifier
) {
    val toast = state.currentToast
    LaunchedEffect(toast?.id) {
        if (toast != null) {
            delay(toast.durationMs)
            if (state.currentToast?.id == toast.id) {
                state.dismiss()
            }
        }
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        contentAlignment = Alignment.BottomCenter
    ) {
        AnimatedVisibility(
            visible = toast != null,
            enter = slideInVertically { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut()
        ) {
            if (toast != null) {
                val colors = StayarTheme.colors
                val borderColor = when (toast.kind) {
                    ToastKind.ERROR -> colors.danger
                    ToastKind.WARN -> colors.warn
                    ToastKind.SUCCESS -> colors.success
                    ToastKind.INFO -> colors.accent
                }
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = colors.bgElev,
                    border = BorderStroke(2.dp, borderColor),
                    shadowElevation = 8.dp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .semantics { liveRegion = LiveRegionMode.Polite }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = toast.textFa,
                            color = colors.text,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.weight(1f)
                        )
                        if (toast.actionLabelFa != null && toast.onAction != null) {
                            TextButton(
                                onClick = {
                                    toast.onAction.invoke()
                                    state.dismiss()
                                }
                            ) {
                                Text(
                                    text = toast.actionLabelFa,
                                    color = borderColor,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
