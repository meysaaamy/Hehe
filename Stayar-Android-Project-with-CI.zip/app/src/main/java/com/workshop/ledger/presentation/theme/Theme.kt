package com.workshop.ledger.presentation.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material3.Text
import com.workshop.ledger.R
import com.workshop.ledger.data.local.datastore.ThemeMode
import com.workshop.ledger.domain.engine.DigitsMode
import com.workshop.ledger.domain.engine.TextNormalizer

@Immutable
data class StayarPalette(
    val bg: Color,
    val bgElev: Color,
    val bgElev2: Color,
    val border: Color,
    val borderStrong: Color,
    val text: Color,
    val textDim: Color,
    val textMute: Color,
    val accent: Color,
    val accent2: Color,
    val onAccent: Color,
    val success: Color,
    val danger: Color,
    val warn: Color,
    val info: Color,
    val isSunlight: Boolean = false,
    val isDark: Boolean = false,
    val defaultBorderWidth: Dp = 1.dp
)

val LightCreamPalette = StayarPalette(
    bg = Color(0xFFEFE6D3),
    bgElev = Color(0xFFFFFDF8),
    bgElev2 = Color(0xFFF5EDDA),
    border = Color(0xFFE6DBC2),
    borderStrong = Color(0xFFD3C4A4),
    text = Color(0xFF201D15),
    textDim = Color(0xFF6D6454),
    textMute = Color(0xFF665E4C),
    accent = Color(0xFF1F5140),
    accent2 = Color(0xFFB45A3C),
    onAccent = Color(0xFFFFFFFF),
    success = Color(0xFF2F8F5B),
    danger = Color(0xFFCF4A3F),
    warn = Color(0xFFC98A17),
    info = Color(0xFF2F6FB0),
    isSunlight = false,
    isDark = false,
    defaultBorderWidth = 1.dp
)

val DarkLedgerPalette = StayarPalette(
    bg = Color(0xFF0A0A0F),
    bgElev = Color(0xFF12121A),
    bgElev2 = Color(0xFF1A1A24),
    border = Color(0xFF26263A),
    borderStrong = Color(0xFF3A3A52),
    text = Color(0xFFE8E8F0),
    textDim = Color(0xFF9A9AB0),
    textMute = Color(0xFF82829A),
    accent = Color(0xFFD4A574),
    accent2 = Color(0xFF8B6F47),
    onAccent = Color(0xFF1A1208),
    success = Color(0xFF4ADE80),
    danger = Color(0xFFF87171),
    warn = Color(0xFFFBBF24),
    info = Color(0xFF60A5FA),
    isSunlight = false,
    isDark = true,
    defaultBorderWidth = 1.dp
)

val SunlightHighContrastPalette = StayarPalette(
    bg = Color(0xFFFFFFFF),
    bgElev = Color(0xFFFFFFFF),
    bgElev2 = Color(0xFFF2F2F2),
    border = Color(0xFF2B2618),
    borderStrong = Color(0xFF000000),
    text = Color(0xFF000000),
    textDim = Color(0xFF1F1F1F),
    textMute = Color(0xFF1F1F1F),
    accent = Color(0xFF0D3B2E),
    accent2 = Color(0xFF8B3218),
    onAccent = Color(0xFFFFFFFF),
    success = Color(0xFF0E6B38),
    danger = Color(0xFFB01C12),
    warn = Color(0xFF8F5B00),
    info = Color(0xFF0F4C81),
    isSunlight = true,
    isDark = false,
    defaultBorderWidth = 2.dp
)

val VizColors: List<Color> = listOf(
    Color(0xFF2F8F5B),
    Color(0xFFC98A17),
    Color(0xFFB45A3C),
    Color(0xFF2F6FB0),
    Color(0xFF8A5FBF),
    Color(0xFF2A9D9D),
    Color(0xFFD4577B),
    Color(0xFF7A8F2F),
    Color(0xFF5B6EE1),
    Color(0xFFA0522D)
)

val VazirmatnFontFamily = FontFamily(
    Font(R.font.vazirmatn_regular, FontWeight.Normal),
    Font(R.font.vazirmatn_medium, FontWeight.Medium),
    Font(R.font.vazirmatn_semibold, FontWeight.SemiBold),
    Font(R.font.vazirmatn_bold, FontWeight.Bold),
    Font(R.font.vazirmatn_extrabold, FontWeight.ExtraBold)
)

val JetBrainsMonoFontFamily = FontFamily(
    Font(R.font.jetbrains_mono_medium, FontWeight.Medium)
)

val LocalStayarPalette = staticCompositionLocalOf { LightCreamPalette }
val LocalDigitsMode = staticCompositionLocalOf { DigitsMode.FA }
val LocalReducedMotion = staticCompositionLocalOf { false }

object StayarTheme {
    val colors: StayarPalette
        @Composable
        @ReadOnlyComposable
        get() = LocalStayarPalette.current

    val digitsMode: DigitsMode
        @Composable
        @ReadOnlyComposable
        get() = LocalDigitsMode.current

    val reducedMotion: Boolean
        @Composable
        @ReadOnlyComposable
        get() = LocalReducedMotion.current
}

private fun stepWeight(base: FontWeight, isSunlight: Boolean): FontWeight {
    if (!isSunlight) return base
    return when (base) {
        FontWeight.Normal -> FontWeight.Medium
        FontWeight.Medium -> FontWeight.SemiBold
        FontWeight.SemiBold -> FontWeight.Bold
        else -> FontWeight.ExtraBold
    }
}

@Composable
fun StayarTheme(
    themeMode: ThemeMode = ThemeMode.SYSTEM,
    ambientSunlightTriggered: Boolean = false,
    digitsMode: DigitsMode = DigitsMode.FA,
    reducedMotion: Boolean = false,
    content: @Composable () -> Unit
) {
    val systemDark = isSystemInDarkTheme()
    val effectiveMode = if (ambientSunlightTriggered && themeMode == ThemeMode.SYSTEM) {
        ThemeMode.SUNLIGHT
    } else {
        themeMode
    }

    val palette = when (effectiveMode) {
        ThemeMode.LIGHT -> LightCreamPalette
        ThemeMode.DARK -> DarkLedgerPalette
        ThemeMode.SUNLIGHT -> SunlightHighContrastPalette
        ThemeMode.SYSTEM -> if (systemDark) DarkLedgerPalette else LightCreamPalette
    }

    val m3Scheme = if (palette.isDark) {
        darkColorScheme(
            primary = palette.accent,
            onPrimary = palette.onAccent,
            secondary = palette.accent2,
            background = palette.bg,
            surface = palette.bgElev,
            surfaceVariant = palette.bgElev2,
            onBackground = palette.text,
            onSurface = palette.text,
            onSurfaceVariant = palette.textDim,
            error = palette.danger,
            outline = palette.border
        )
    } else {
        lightColorScheme(
            primary = palette.accent,
            onPrimary = palette.onAccent,
            secondary = palette.accent2,
            background = palette.bg,
            surface = palette.bgElev,
            surfaceVariant = palette.bgElev2,
            onBackground = palette.text,
            onSurface = palette.text,
            onSurfaceVariant = palette.textDim,
            error = palette.danger,
            outline = palette.border
        )
    }

    val sunlight = palette.isSunlight
    val typography = Typography(
        headlineLarge = TextStyle(
            fontFamily = VazirmatnFontFamily,
            fontWeight = stepWeight(FontWeight.Bold, sunlight),
            fontSize = 24.sp,
            color = palette.text
        ),
        headlineMedium = TextStyle(
            fontFamily = VazirmatnFontFamily,
            fontWeight = stepWeight(FontWeight.Bold, sunlight),
            fontSize = 20.sp,
            color = palette.text
        ),
        titleLarge = TextStyle(
            fontFamily = VazirmatnFontFamily,
            fontWeight = stepWeight(FontWeight.Bold, sunlight),
            fontSize = 18.sp,
            color = palette.text
        ),
        titleMedium = TextStyle(
            fontFamily = VazirmatnFontFamily,
            fontWeight = stepWeight(FontWeight.SemiBold, sunlight),
            fontSize = 15.sp,
            color = palette.text
        ),
        bodyLarge = TextStyle(
            fontFamily = VazirmatnFontFamily,
            fontWeight = stepWeight(FontWeight.Normal, sunlight),
            fontSize = 15.sp,
            color = palette.text
        ),
        bodyMedium = TextStyle(
            fontFamily = VazirmatnFontFamily,
            fontWeight = stepWeight(FontWeight.Normal, sunlight),
            fontSize = 13.5.sp,
            color = palette.text
        ),
        labelLarge = TextStyle(
            fontFamily = VazirmatnFontFamily,
            fontWeight = stepWeight(FontWeight.SemiBold, sunlight),
            fontSize = 13.5.sp,
            color = palette.text
        ),
        labelSmall = TextStyle(
            fontFamily = VazirmatnFontFamily,
            fontWeight = stepWeight(FontWeight.Medium, sunlight),
            fontSize = 11.5.sp,
            color = palette.textDim
        )
    )

    CompositionLocalProvider(
        LocalLayoutDirection provides LayoutDirection.Rtl,
        LocalStayarPalette provides palette,
        LocalDigitsMode provides digitsMode,
        LocalReducedMotion provides reducedMotion
    ) {
        MaterialTheme(
            colorScheme = m3Scheme,
            typography = typography,
            content = content
        )
    }
}

/**
 * Renders money values inside an LTR monospace composable with OpenType `fontFeatureSettings = "tnum"`
 * so RTL text never reorders digits or negative signs and columns align pixel-perfectly.
 */
@Composable
fun MoneyText(
    amount: Long,
    modifier: Modifier = Modifier,
    showUnit: Boolean = false,
    color: Color = StayarTheme.colors.text,
    fontSize: TextUnit = 15.sp,
    fontWeight: FontWeight = FontWeight.Bold,
    textAlign: TextAlign = TextAlign.End
) {
    val digitsMode = StayarTheme.digitsMode
    val formatted = TextNormalizer.fmtDisplay(amount, digitsMode)
    val fullText = if (showUnit) "$formatted تومان" else formatted
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Text(
            text = fullText,
            modifier = modifier,
            color = color,
            fontSize = fontSize,
            fontWeight = fontWeight,
            fontFamily = JetBrainsMonoFontFamily,
            textAlign = textAlign,
            style = TextStyle(fontFeatureSettings = "tnum")
        )
    }
}

@Composable
fun NumberText(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = StayarTheme.colors.text,
    fontSize: TextUnit = 14.sp,
    fontWeight: FontWeight = FontWeight.Medium,
    textAlign: TextAlign = TextAlign.End
) {
    val digitsMode = StayarTheme.digitsMode
    val formatted = TextNormalizer.formatDisplayDigits(text, digitsMode)
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Text(
            text = formatted,
            modifier = modifier,
            color = color,
            fontSize = fontSize,
            fontWeight = fontWeight,
            fontFamily = JetBrainsMonoFontFamily,
            textAlign = textAlign,
            style = TextStyle(fontFeatureSettings = "tnum")
        )
    }
}
