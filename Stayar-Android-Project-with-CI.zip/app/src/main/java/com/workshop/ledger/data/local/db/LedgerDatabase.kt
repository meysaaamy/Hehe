package com.workshop.ledger.data.local.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        ProjectEntity::class,
        UserEntity::class,
        WageEntity::class,
        AttendanceEntity::class,
        CategoryEntity::class,
        ExpenseEntity::class,
        ReceiptEntity::class,
        PayoutEntity::class,
        TransferEntity::class,
        AdjustmentEntity::class
    ],
    version = 3,
    exportSchema = true
)
abstract class LedgerDatabase : RoomDatabase() {

    abstract fun ledgerDao(): LedgerDao

    companion object {
        private const val DB_NAME = "workshop-ledger.db"

        private val CHILD_TABLES = listOf(
            "users",
            "wages",
            "attendance",
            "expenses",
            "receipts",
            "payouts",
            "transfers",
            "adjustments",
            "categories"
        )

        @Volatile
        private var INSTANCE: LedgerDatabase? = null

        fun getInstance(context: Context): LedgerDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: buildDatabase(context.applicationContext).also { INSTANCE = it }
            }
        }

        private fun buildDatabase(context: Context): LedgerDatabase {
            return Room.databaseBuilder(
                context,
                LedgerDatabase::class.java,
                DB_NAME
            )
                .setJournalMode(JournalMode.WRITE_AHEAD_LOGGING)
                .addCallback(object : Callback() {
                    override fun onOpen(db: SupportSQLiteDatabase) {
                        super.onOpen(db)
                        db.execSQL("PRAGMA foreign_keys = ON;")
                        installPeriodLockTriggers(db)
                    }
                })
                .fallbackToDestructiveMigration()
                .build()
        }

        /**
         * Installs SQLite Period-Lock Triggers on all 9 child tables for
         * BEFORE INSERT, BEFORE UPDATE, and BEFORE DELETE.
         */
        fun installPeriodLockTriggers(db: SupportSQLiteDatabase) {
            for (table in CHILD_TABLES) {
                db.execSQL(
                    """
                    CREATE TRIGGER IF NOT EXISTS trg_${table}_lock_insert
                    BEFORE INSERT ON $table
                    BEGIN
                        SELECT RAISE(ABORT, 'PERIOD_LOCKED')
                        WHERE (SELECT locked FROM projects WHERE id = NEW.projectId) = 1;
                    END;
                    """.trimIndent()
                )
                db.execSQL(
                    """
                    CREATE TRIGGER IF NOT EXISTS trg_${table}_lock_update
                    BEFORE UPDATE ON $table
                    BEGIN
                        SELECT RAISE(ABORT, 'PERIOD_LOCKED')
                        WHERE (SELECT locked FROM projects WHERE id = NEW.projectId) = 1;
                    END;
                    """.trimIndent()
                )
                db.execSQL(
                    """
                    CREATE TRIGGER IF NOT EXISTS trg_${table}_lock_delete
                    BEFORE DELETE ON $table
                    BEGIN
                        SELECT RAISE(ABORT, 'PERIOD_LOCKED')
                        WHERE (SELECT locked FROM projects WHERE id = OLD.projectId) = 1;
                    END;
                    """.trimIndent()
                )
            }
        }
    }
}
