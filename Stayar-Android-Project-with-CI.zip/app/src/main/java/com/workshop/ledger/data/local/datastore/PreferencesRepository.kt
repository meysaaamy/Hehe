package com.workshop.ledger.data.local.datastore

import android.content.Context
import androidx.datastore.core.CorruptionException
import androidx.datastore.core.DataStore
import androidx.datastore.core.Serializer
import androidx.datastore.dataStore
import com.google.protobuf.InvalidProtocolBufferException
import com.workshop.ledger.datastore.proto.AppPreferencesProto
import com.workshop.ledger.datastore.proto.AttendanceViewModeProto
import com.workshop.ledger.datastore.proto.DigitsModeProto
import com.workshop.ledger.datastore.proto.NotifVerbosityProto
import com.workshop.ledger.datastore.proto.OnboardingProto
import com.workshop.ledger.datastore.proto.OnboardingStatusProto
import com.workshop.ledger.datastore.proto.ThemeModeProto
import com.workshop.ledger.domain.engine.DigitsMode
import com.workshop.ledger.domain.tutorial.OnboardingState
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.io.InputStream
import java.io.OutputStream

enum class ThemeMode(val labelFa: String) {
    SYSTEM("خودکار (سیستم)"),
    LIGHT("روشن (کرم)"),
    DARK("تیره"),
    SUNLIGHT("حالت زیر آفتاب (کنتراست بالا)");

    fun next(): ThemeMode = when (this) {
        SYSTEM -> LIGHT
        LIGHT -> DARK
        DARK -> SUNLIGHT
        SUNLIGHT -> SYSTEM
    }
}

enum class NotifVerbosity(val labelFa: String) {
    ALL("همه پیام‌ها"),
    LESS("کمتر (بدون پیام‌های «ذخیره شد»)"),
    MIN("خیلی کم (فقط خطاها)")
}

enum class AttendanceViewMode {
    AUTO,
    CARD,
    MATRIX
}

data class AppPreferences(
    val activeProjectId: String = "",
    val coachDismissed: Boolean = false,
    val splashEnabled: Boolean = true,
    val soundEnabled: Boolean = true,
    val hapticsEnabled: Boolean = true,
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val digitsMode: DigitsMode = DigitsMode.FA,
    val volume: Int = 100, // 0..100 step 5
    val notifVerbosity: NotifVerbosity = NotifVerbosity.ALL,
    val attendanceViewMode: AttendanceViewMode = AttendanceViewMode.AUTO,
    val onboarding: OnboardingState = OnboardingState(),
    val autoBackupIntervalMin: Int = 15, // 0, 5, 15, 30, 60
    val lastAutoBackupMs: Long = 0L,
    val lastExternalExportMs: Long = 0L,
    val backupNagSnoozedUntilMs: Long = 0L,
    val autoSunlightSensor: Boolean = true
)

object AppPreferencesSerializer : Serializer<AppPreferencesProto> {
    override val defaultValue: AppPreferencesProto = AppPreferencesProto.newBuilder()
        .setSplashEnabled(true)
        .setSoundEnabled(true)
        .setHapticsEnabled(true)
        .setThemeMode(ThemeModeProto.THEME_SYSTEM)
        .setDigitsMode(DigitsModeProto.DIGITS_FA)
        .setVolume(100)
        .setNotifVerbosity(NotifVerbosityProto.NOTIF_ALL)
        .setAttendanceViewMode(AttendanceViewModeProto.VIEW_AUTO)
        .setAutoBackupIntervalMin(15)
        .setAutoSunlightSensor(true)
        .setInitialized(true)
        .setOnboarding(
            OnboardingProto.newBuilder()
                .setStatus(OnboardingStatusProto.ONBOARDING_NOT_STARTED)
                .setChapter(1)
                .setQuestStep(0)
                .setSandboxProjectId("")
                .build()
        )
        .build()

    override suspend fun readFrom(input: InputStream): AppPreferencesProto {
        try {
            val parsed = AppPreferencesProto.parseFrom(input)
            return if (!parsed.initialized) defaultValue else parsed
        } catch (exception: InvalidProtocolBufferException) {
            throw CorruptionException("Cannot read proto.", exception)
        }
    }

    override suspend fun writeTo(t: AppPreferencesProto, output: OutputStream) {
        t.writeTo(output)
    }
}

private val Context.appPreferencesDataStore: DataStore<AppPreferencesProto> by dataStore(
    fileName = "app_prefs.pb",
    serializer = AppPreferencesSerializer
)

class PreferencesRepository(private val context: Context) {

    val preferencesFlow: Flow<AppPreferences> = context.appPreferencesDataStore.data.map { proto ->
        AppPreferences(
            activeProjectId = proto.activeProjectId,
            coachDismissed = proto.coachDismissed,
            splashEnabled = proto.splashEnabled,
            soundEnabled = proto.soundEnabled,
            hapticsEnabled = proto.hapticsEnabled,
            themeMode = when (proto.themeMode) {
                ThemeModeProto.THEME_LIGHT -> ThemeMode.LIGHT
                ThemeModeProto.THEME_DARK -> ThemeMode.DARK
                ThemeModeProto.THEME_SUNLIGHT -> ThemeMode.SUNLIGHT
                else -> ThemeMode.SYSTEM
            },
            digitsMode = when (proto.digitsMode) {
                DigitsModeProto.DIGITS_EN -> DigitsMode.EN
                else -> DigitsMode.FA
            },
            volume = proto.volume.coerceIn(0, 100),
            notifVerbosity = when (proto.notifVerbosity) {
                NotifVerbosityProto.NOTIF_LESS -> NotifVerbosity.LESS
                NotifVerbosityProto.NOTIF_MIN -> NotifVerbosity.MIN
                else -> NotifVerbosity.ALL
            },
            attendanceViewMode = when (proto.attendanceViewMode) {
                AttendanceViewModeProto.VIEW_CARD -> AttendanceViewMode.CARD
                AttendanceViewModeProto.VIEW_MATRIX -> AttendanceViewMode.MATRIX
                else -> AttendanceViewMode.AUTO
            },
            onboarding = OnboardingState(
                status = when (proto.onboarding.status) {
                    OnboardingStatusProto.ONBOARDING_IN_QUEST -> "in_quest"
                    OnboardingStatusProto.ONBOARDING_COMPLETED -> "completed"
                    OnboardingStatusProto.ONBOARDING_SKIPPED -> "skipped"
                    else -> "not_started"
                },
                chapter = proto.onboarding.chapter.let { if (it in 1..3) it else 1 },
                questStep = proto.onboarding.questStep.coerceIn(0, 27),
                sandboxProjectId = proto.onboarding.sandboxProjectId.takeIf { it.isNotEmpty() }
            ),
            autoBackupIntervalMin = proto.autoBackupIntervalMin,
            lastAutoBackupMs = proto.lastAutoBackupMs,
            lastExternalExportMs = proto.lastExternalExportMs,
            backupNagSnoozedUntilMs = proto.backupNagSnoozedUntilMs,
            autoSunlightSensor = proto.autoSunlightSensor
        )
    }

    suspend fun setActiveProjectId(projectId: String) {
        context.appPreferencesDataStore.updateData {
            it.toBuilder().setActiveProjectId(projectId).setInitialized(true).build()
        }
    }

    suspend fun setCoachDismissed(dismissed: Boolean) {
        context.appPreferencesDataStore.updateData {
            it.toBuilder().setCoachDismissed(dismissed).setInitialized(true).build()
        }
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        val protoMode = when (mode) {
            ThemeMode.SYSTEM -> ThemeModeProto.THEME_SYSTEM
            ThemeMode.LIGHT -> ThemeModeProto.THEME_LIGHT
            ThemeMode.DARK -> ThemeModeProto.THEME_DARK
            ThemeMode.SUNLIGHT -> ThemeModeProto.THEME_SUNLIGHT
        }
        context.appPreferencesDataStore.updateData {
            it.toBuilder().setThemeMode(protoMode).setInitialized(true).build()
        }
    }

    suspend fun setDigitsMode(mode: DigitsMode) {
        val protoMode = when (mode) {
            DigitsMode.FA -> DigitsModeProto.DIGITS_FA
            DigitsMode.EN -> DigitsModeProto.DIGITS_EN
        }
        context.appPreferencesDataStore.updateData {
            it.toBuilder().setDigitsMode(protoMode).setInitialized(true).build()
        }
    }

    suspend fun setSplashEnabled(enabled: Boolean) {
        context.appPreferencesDataStore.updateData {
            it.toBuilder().setSplashEnabled(enabled).setInitialized(true).build()
        }
    }

    suspend fun setSoundEnabled(enabled: Boolean) {
        context.appPreferencesDataStore.updateData {
            it.toBuilder().setSoundEnabled(enabled).setInitialized(true).build()
        }
    }

    suspend fun setHapticsEnabled(enabled: Boolean) {
        context.appPreferencesDataStore.updateData {
            it.toBuilder().setHapticsEnabled(enabled).setInitialized(true).build()
        }
    }

    suspend fun setVolume(volume: Int) {
        context.appPreferencesDataStore.updateData {
            it.toBuilder().setVolume(volume.coerceIn(0, 100)).setInitialized(true).build()
        }
    }

    suspend fun setNotifVerbosity(verbosity: NotifVerbosity) {
        val protoVerbosity = when (verbosity) {
            NotifVerbosity.ALL -> NotifVerbosityProto.NOTIF_ALL
            NotifVerbosity.LESS -> NotifVerbosityProto.NOTIF_LESS
            NotifVerbosity.MIN -> NotifVerbosityProto.NOTIF_MIN
        }
        context.appPreferencesDataStore.updateData {
            it.toBuilder().setNotifVerbosity(protoVerbosity).setInitialized(true).build()
        }
    }

    suspend fun setAttendanceViewMode(mode: AttendanceViewMode) {
        val protoMode = when (mode) {
            AttendanceViewMode.AUTO -> AttendanceViewModeProto.VIEW_AUTO
            AttendanceViewMode.CARD -> AttendanceViewModeProto.VIEW_CARD
            AttendanceViewMode.MATRIX -> AttendanceViewModeProto.VIEW_MATRIX
        }
        context.appPreferencesDataStore.updateData {
            it.toBuilder().setAttendanceViewMode(protoMode).setInitialized(true).build()
        }
    }

    suspend fun setOnboarding(state: OnboardingState) {
        val statusProto = when (state.status) {
            "in_quest" -> OnboardingStatusProto.ONBOARDING_IN_QUEST
            "completed" -> OnboardingStatusProto.ONBOARDING_COMPLETED
            "skipped" -> OnboardingStatusProto.ONBOARDING_SKIPPED
            else -> OnboardingStatusProto.ONBOARDING_NOT_STARTED
        }
        val obProto = OnboardingProto.newBuilder()
            .setStatus(statusProto)
            .setChapter(state.chapter.coerceIn(1, 3))
            .setQuestStep(state.questStep.coerceIn(0, 27))
            .setSandboxProjectId(state.sandboxProjectId.orEmpty())
            .build()

        context.appPreferencesDataStore.updateData {
            it.toBuilder().setOnboarding(obProto).setInitialized(true).build()
        }
    }

    suspend fun setAutoBackupIntervalMin(intervalMin: Int) {
        context.appPreferencesDataStore.updateData {
            it.toBuilder().setAutoBackupIntervalMin(intervalMin).setInitialized(true).build()
        }
    }

    suspend fun recordAutoBackupTimestamp(epochMs: Long) {
        context.appPreferencesDataStore.updateData {
            it.toBuilder().setLastAutoBackupMs(epochMs).setInitialized(true).build()
        }
    }

    suspend fun recordExternalExportTimestamp(epochMs: Long) {
        context.appPreferencesDataStore.updateData {
            it.toBuilder().setLastExternalExportMs(epochMs).setInitialized(true).build()
        }
    }

    suspend fun snoozeBackupNag(untilMs: Long) {
        context.appPreferencesDataStore.updateData {
            it.toBuilder().setBackupNagSnoozedUntilMs(untilMs).setInitialized(true).build()
        }
    }
}
