package com.workshop.ledger.presentation.screens.guide

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.workshop.ledger.domain.engine.TextNormalizer
import com.workshop.ledger.domain.tutorial.WalkthroughSteps
import com.workshop.ledger.presentation.components.TactileSheet
import com.workshop.ledger.presentation.theme.StayarTheme

/**
 * Guide & Walkthrough Screen (`«راهنما و آموزش»`, Section 13).
 * Contains:
 * 1. Header Card with «آموزش گام‌به‌گام ۱۲ مرحله‌ای»
 *    Buttons: «تمرین عملی (۳ فصل)» and «خواندن آموزش ۱۲ مرحله‌ای» (step-by-step modal).
 * 2. 12 OB_STEPS cards with exact Persian texts:
 *    a: چیست؟
 *    b: چطور کار می‌کند؟
 *    c: چه اثری در حساب دارد؟
 *    and OB_TRY jump buttons («امتحانش کن»).
 * 3. Core Formulas Card (`«فرمول‌های اصلی»`).
 */
@Composable
fun GuideScreen(
    onStartInteractivePractice: () -> Unit,
    onJumpToScreen: (String) -> Unit
) {
    val colors = StayarTheme.colors
    val digitsMode = StayarTheme.digitsMode
    val f = { s: String -> TextNormalizer.formatDisplayDigits(s, digitsMode) }

    var showStepModal by remember { mutableStateOf(false) }
    var currentModalStepIndex by remember { mutableIntStateOf(0) }

    val steps = WalkthroughSteps.OB_STEPS
    val formulas = WalkthroughSteps.MAIN_FORMULAS

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Header Card
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(colors.bgElev)
                .border(1.dp, colors.borderStrong, RoundedCornerShape(16.dp))
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = "آموزش گام‌به‌گام ۱۲ مرحله‌ای",
                fontWeight = FontWeight.ExtraBold,
                fontSize = 17.sp,
                color = colors.text
            )
            Text(
                text = "هر بخش را به زبان کارگاهی توضیح می‌دهد: چیست، چطور کار می‌کند و چه اثری در حساب دارد.",
                fontSize = 13.sp,
                lineHeight = 20.sp,
                color = colors.textDim
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onStartInteractivePractice,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = colors.accent,
                        contentColor = colors.onAccent
                    ),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("تمرین عملی (۳ فصل)", fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
                }
                OutlinedButton(
                    onClick = {
                        currentModalStepIndex = 0
                        showStepModal = true
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Text("خواندن آموزش ۱۲ مرحله‌ای", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // 2. 12 OB_STEPS Cards
        steps.forEach { step ->
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(colors.bgElev)
                    .border(1.dp, colors.border, RoundedCornerShape(14.dp))
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = f(step.titleFa),
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 15.sp,
                        color = colors.text,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedButton(
                        onClick = { onJumpToScreen(step.tryPage) }
                    ) {
                        Text(step.tryButtonLabelFa, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }

                // Section a: چیست؟
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(colors.bgElev2)
                        .padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    Text(
                        text = "📌 چیست؟",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = colors.accent
                    )
                    Text(
                        text = f(step.whatIsItFa),
                        fontSize = 12.sp,
                        lineHeight = 18.sp,
                        color = colors.text
                    )
                }

                // Section b: چطور کار می‌کند؟
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(colors.bgElev2)
                        .padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    Text(
                        text = "⚙️ چطور کار می‌کند؟",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = colors.accent2
                    )
                    Text(
                        text = f(step.howItWorksFa),
                        fontSize = 12.sp,
                        lineHeight = 18.sp,
                        color = colors.text
                    )
                }

                // Section c: چه اثری در حساب دارد؟
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(colors.bgElev2)
                        .padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    Text(
                        text = "📊 چه اثری در حساب دارد؟",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = colors.success
                    )
                    Text(
                        text = f(step.accountingImpactFa),
                        fontSize = 12.sp,
                        lineHeight = 18.sp,
                        color = colors.text
                    )
                }
            }
        }

        // 3. Core Formulas Card (`«فرمول‌های اصلی»`)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(colors.bgElev)
                .border(1.dp, colors.borderStrong, RoundedCornerShape(16.dp))
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = "فرمول‌های اصلی موتور حسابداری",
                fontWeight = FontWeight.ExtraBold,
                fontSize = 16.sp,
                color = colors.text
            )
            formulas.forEach { item ->
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(colors.bgElev2)
                        .border(1.dp, colors.border, RoundedCornerShape(10.dp))
                        .padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = f(item.titleFa),
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = colors.text
                    )
                    Text(
                        text = f(item.formulaFa),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.accent
                    )
                    if (item.noteFa.isNotBlank()) {
                        Text(
                            text = f("نکته: ${item.noteFa}"),
                            fontSize = 11.sp,
                            color = colors.textDim
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(48.dp))
    }

    // 12-Step Reading Modal
    if (showStepModal && steps.isNotEmpty()) {
        val step = steps[currentModalStepIndex.coerceIn(0, steps.lastIndex)]
        val stepNumFa = f((currentModalStepIndex + 1).toString())
        val totalFa = f(steps.size.toString())

        TactileSheet(
            title = "گام $stepNumFa از $totalFa — ${step.titleFa}",
            onDismiss = { showStepModal = false }
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // چیست؟
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(colors.bgElev2)
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text("📌 چیست؟", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = colors.accent)
                    Text(f(step.whatIsItFa), fontSize = 13.sp, lineHeight = 20.sp, color = colors.text)
                }

                // چطور کار می‌کند؟
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(colors.bgElev2)
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text("⚙️ چطور کار می‌کند؟", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = colors.accent2)
                    Text(f(step.howItWorksFa), fontSize = 13.sp, lineHeight = 20.sp, color = colors.text)
                }

                // چه اثری در حساب دارد؟
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(colors.bgElev2)
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text("📊 چه اثری در حساب دارد؟", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = colors.success)
                    Text(f(step.accountingImpactFa), fontSize = 13.sp, lineHeight = 20.sp, color = colors.text)
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (currentModalStepIndex > 0) {
                        OutlinedButton(
                            onClick = { currentModalStepIndex-- },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("گام قبلی", fontWeight = FontWeight.Bold)
                        }
                    }
                    if (currentModalStepIndex < steps.lastIndex) {
                        Button(
                            onClick = { currentModalStepIndex++ },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = colors.accent,
                                contentColor = colors.onAccent
                            ),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("گام بعدی", fontWeight = FontWeight.ExtraBold)
                        }
                    } else {
                        Button(
                            onClick = { showStepModal = false },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = colors.accent,
                                contentColor = colors.onAccent
                            ),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("پایان آموزش", fontWeight = FontWeight.ExtraBold)
                        }
                    }
                }

                OutlinedButton(
                    onClick = {
                        showStepModal = false
                        onJumpToScreen(step.tryPage)
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("رفتن به بخش و امتحان کردن (${step.tryButtonLabelFa})", fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}
