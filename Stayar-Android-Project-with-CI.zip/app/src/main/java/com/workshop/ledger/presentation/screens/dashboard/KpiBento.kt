package com.workshop.ledger.presentation.screens.dashboard

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.workshop.ledger.domain.engine.TextNormalizer
import com.workshop.ledger.domain.model.AccountingResult
import com.workshop.ledger.presentation.components.TactileSheet
import com.workshop.ledger.presentation.components.tiltCard
import com.workshop.ledger.presentation.theme.MoneyText
import com.workshop.ledger.presentation.theme.NumberText
import com.workshop.ledger.presentation.theme.StayarIcon
import com.workshop.ledger.presentation.theme.StayarTheme
import com.workshop.ledger.presentation.tutorial.QuestCoordinator
import com.workshop.ledger.presentation.tutorial.questTarget

@Composable
fun KpiBentoSection(
    r: AccountingResult,
    isTutorialProfitRulerStep: Boolean,
    onOpenProfitRuler: () -> Unit,
    questCoordinator: QuestCoordinator? = null
) {
    val colors = StayarTheme.colors
    val digitsMode = StayarTheme.digitsMode
    val f = { s: String -> TextNormalizer.formatDisplayDigits(s, digitsMode) }
    var activeDetailKpi by remember { mutableStateOf<String?>(null) }

    val heroSubFa = if (r.basis == "commitment") {
        "واریزی − هزینه مشترک − کل دستمزد استحقاقی"
    } else {
        "واریزی − هزینه مشترک − پرداختی‌های نقدی"
    }

    val mastersDaysSum = r.masters.sumOf { it.days }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        // Hero KPI: profit
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = colors.bgElev,
            border = BorderStroke(2.dp, colors.accent),
            shadowElevation = 4.dp,
            modifier = Modifier
                .fillMaxWidth()
                .tiltCard()
                .questTarget("kpi_profit", questCoordinator)
                .clickable {
                    if (isTutorialProfitRulerStep) {
                        onOpenProfitRuler()
                    } else {
                        activeDetailKpi = "profit"
                    }
                }
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        StayarIcon("chartpie", tint = colors.accent, size = 22.dp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "مانده قابل تقسیم بین اوستاها",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = colors.text
                        )
                    }
                    Text("فرمول ◂", fontSize = 12.sp, color = colors.accent, fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.height(8.dp))
                MoneyText(
                    amount = r.profit,
                    showUnit = true,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = if (r.profit >= 0L) colors.success else colors.danger
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(text = heroSubFa, fontSize = 12.sp, color = colors.textDim)
            }
        }

        // Row 1: receipts & shared
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            SmallKpiCard(
                icon = "wallet",
                labelFa = "مجموع واریزی کارفرما",
                subFa = "دریافتی در بازه",
                amount = r.totalReceipts,
                valueColor = colors.success,
                onClick = { activeDetailKpi = "receipts" },
                modifier = Modifier.weight(1f)
            )
            SmallKpiCard(
                icon = "cart",
                labelFa = "هزینه‌های مشترک",
                subFa = "پرداخت از صندوق",
                amount = r.sharedExpenses,
                valueColor = colors.danger,
                onClick = { activeDetailKpi = "shared" },
                modifier = Modifier.weight(1f)
            )
        }

        // Row 2: wages & payouts
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            SmallKpiCard(
                icon = "layers",
                labelFa = "کل دستمزد استحقاقی",
                subFa = f("${r.staff.size} نفر شاگرد/سایر"),
                amount = r.totalWages,
                valueColor = colors.text,
                onClick = { activeDetailKpi = "wages" },
                modifier = Modifier.weight(1f)
            )
            SmallKpiCard(
                icon = "receipt",
                labelFa = "پرداختی‌های نقدی",
                subFa = "پرداختی + مساعده پرسنل",
                amount = r.totalCashPayouts + r.staffAssistance,
                valueColor = colors.warn,
                onClick = { activeDetailKpi = "payouts" },
                modifier = Modifier.weight(1f)
            )
        }

        // Row 3: personal & days
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            SmallKpiCard(
                icon = "users",
                labelFa = "هزینه‌های شخصی اوستاها",
                subFa = "از جیب اوستا؛ سهم‌بندی می‌شود",
                amount = r.personalExpTotal,
                valueColor = colors.info,
                onClick = { activeDetailKpi = "personal" },
                modifier = Modifier.weight(1f)
            )
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = colors.bgElev,
                border = BorderStroke(colors.defaultBorderWidth, colors.borderStrong),
                modifier = Modifier
                    .weight(1f)
                    .tiltCard()
                    .clickable { activeDetailKpi = "days" }
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        StayarIcon("calendar", tint = colors.accent, size = 18.dp)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "کارکرد اوستاها (روز)",
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = colors.text
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    NumberText(
                        text = TextNormalizer.fmtDays(mastersDaysSum),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = colors.accent
                    )
                    Text(
                        text = "پیش از اعمال ضریب",
                        fontSize = 11.sp,
                        color = colors.textDim
                    )
                }
            }
        }
    }

    if (activeDetailKpi != null) {
        KpiDetailSheet(
            kpiId = activeDetailKpi!!,
            r = r,
            onOpenProfitRuler = {
                activeDetailKpi = null
                onOpenProfitRuler()
            },
            onDismiss = { activeDetailKpi = null }
        )
    }
}

@Composable
private fun SmallKpiCard(
    icon: String,
    labelFa: String,
    subFa: String,
    amount: Long,
    valueColor: androidx.compose.ui.graphics.Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = StayarTheme.colors
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = colors.bgElev,
        border = BorderStroke(colors.defaultBorderWidth, colors.borderStrong),
        modifier = modifier
            .tiltCard()
            .clickable(onClick = onClick)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                StayarIcon(icon, tint = colors.accent, size = 18.dp)
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = labelFa,
                    fontSize = 12.5.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.text
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            MoneyText(
                amount = amount,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = valueColor
            )
            Text(
                text = subFa,
                fontSize = 11.sp,
                color = colors.textDim
            )
        }
    }
}

@Composable
private fun KpiDetailSheet(
    kpiId: String,
    r: AccountingResult,
    onOpenProfitRuler: () -> Unit,
    onDismiss: () -> Unit
) {
    val colors = StayarTheme.colors
    val titleFa = when (kpiId) {
        "profit" -> "مانده قابل تقسیم"
        "receipts" -> "واریزی کارفرما"
        "shared" -> "هزینه‌های مشترک"
        "wages" -> "دستمزد استحقاقی"
        "payouts" -> "پرداختی‌های نقدی"
        "personal" -> "هزینه‌های شخصی اوستاها"
        "days" -> "کارکرد اوستاها"
        else -> "جزئیات شاخص"
    }

    TactileSheet(titleFa = titleFa, onDismissRequest = onDismiss) {
        when (kpiId) {
            "profit" -> {
                FormulaLine("+ واریزی‌ها", r.totalReceipts)
                FormulaLine("− هزینه‌های مشترک", r.sharedExpenses)
                if (r.basis == "commitment") {
                    FormulaLine("− کل دستمزد استحقاقی (حتی پرداخت‌نشده)", r.totalWages)
                } else {
                    FormulaLine("− پرداختی‌های نقدی به شاگردان", r.totalCashPayouts)
                    FormulaLine("− مساعده پرسنل", r.staffAssistance)
                }
                if (r.masterBonus > 0L) FormulaLine("− پاداش اوستاها", r.masterBonus)
                if (r.masterPenalty > 0L) FormulaLine("+ جریمه اوستاها", r.masterPenalty)
                HorizontalDivider(color = colors.borderStrong, modifier = Modifier.padding(vertical = 8.dp))
                FormulaLine("= مانده قابل تقسیم", r.profit, isBold = true)

                if (r.basis == "cash" && r.unpaidWages > 0L) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Surface(
                        color = colors.warn.copy(alpha = 0.14f),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, colors.warn)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "⚠ دستمزد کارکرده و هنوز پرداخت‌نشده (از مانده کم نشده)",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = colors.text,
                                modifier = Modifier.weight(1f)
                            )
                            MoneyText(amount = r.unpaidWages, color = colors.warn, fontSize = 13.sp)
                        }
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "این مبلغ به نسبت «کارکرد × ضریب» بین اوستاهای فعال تقسیم می‌شود." +
                        if (r.basis == "cash") " در مبنای نقدی، پیش از برداشت کامل سود، مبلغ دستمزدهای پرداخت‌نشدهٔ شاگردان را در صندوق کنار بگذارید." else "",
                    fontSize = 12.5.sp,
                    color = colors.textDim
                )
            }
            "receipts" -> {
                FormulaLine("سهم واریزی‌های فعال در بازه", r.totalReceipts, isBold = true)
            }
            "shared" -> {
                FormulaLine("پرداخت‌شده از صندوق کارگاه", r.sharedExpenses, isBold = true)
            }
            "wages" -> {
                for (s in r.staff) {
                    FormulaLine(s.name, s.entitled)
                }
                HorizontalDivider(color = colors.borderStrong, modifier = Modifier.padding(vertical = 6.dp))
                FormulaLine("جمع", r.totalWages, isBold = true)
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "دستمزد پایه (حضور × نرخ) + پاداش − جریمه هر نفر.",
                    fontSize = 12.5.sp,
                    color = colors.textDim
                )
            }
            "payouts" -> {
                FormulaLine("پرداختی‌های ثبت‌شده", r.totalCashPayouts)
                FormulaLine("مساعده پرسنل", r.staffAssistance)
                HorizontalDivider(color = colors.borderStrong, modifier = Modifier.padding(vertical = 6.dp))
                FormulaLine("جمع", r.totalCashPayouts + r.staffAssistance, isBold = true)
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "از طلب هر شاگرد کم می‌شود.",
                    fontSize = 12.5.sp,
                    color = colors.textDim
                )
            }
            "personal" -> {
                for (m in r.masters) {
                    FormulaLine("${m.name} (بازپرداخت)", m.reimburse)
                }
                HorizontalDivider(color = colors.borderStrong, modifier = Modifier.padding(vertical = 6.dp))
                FormulaLine("جمع", r.personalExpTotal, isBold = true)
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "به پرداخت‌کننده برگردانده و بین اوستاها به نسبت سهم تقسیم می‌شود.",
                    fontSize = 12.5.sp,
                    color = colors.textDim
                )
            }
            "days" -> {
                for (m in r.masters) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(m.name, color = colors.text, fontWeight = FontWeight.Medium)
                        NumberText(
                            text = "${TextNormalizer.fmtDays(m.days)} روز (× ${TextNormalizer.fmtDays(m.workFactor)})",
                            color = colors.text
                        )
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "ضریب کارکرد هر اوستا در تقسیم سود اعمال می‌شود.",
                    fontSize = 12.5.sp,
                    color = colors.textDim
                )
            }
        }
    }
}

@Composable
private fun FormulaLine(
    labelFa: String,
    amount: Long,
    isBold: Boolean = false
) {
    val colors = StayarTheme.colors
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = labelFa,
            fontSize = if (isBold) 14.5.sp else 13.5.sp,
            fontWeight = if (isBold) FontWeight.Bold else FontWeight.Medium,
            color = colors.text
        )
        MoneyText(
            amount = amount,
            showUnit = true,
            fontSize = if (isBold) 15.sp else 13.5.sp,
            fontWeight = if (isBold) FontWeight.ExtraBold else FontWeight.SemiBold,
            color = colors.text
        )
    }
}
