package com.workshop.ledger.domain.engine

import com.workshop.ledger.domain.model.DomainConstants

data class ParseMoneyResult(
    val v: Long,
    val has: Boolean,
    val dec: Boolean,
    val clamped: Boolean
)

object PersianMoneyWords {
    private val ONES = arrayOf(
        "", "یک", "دو", "سه", "چهار", "پنج", "شش", "هفت", "هشت", "نه"
    )
    private val TEENS = arrayOf(
        "ده", "یازده", "دوازده", "سیزده", "چهارده", "پانزده", "شانزده", "هفده", "هجده", "نوزده"
    )
    private val TENS = arrayOf(
        "", "", "بیست", "سی", "چهل", "پنجاه", "شصت", "هفتاد", "هشتاد", "نود"
    )
    private val HUNDREDS = arrayOf(
        "", "صد", "دویست", "سیصد", "چهارصد", "پانصد", "ششصد", "هفتصد", "هشتصد", "نهصد"
    )
    private val SCALES = arrayOf(
        "", "هزار", "میلیون", "میلیارد", "هزار میلیارد"
    )

    private fun tri(n: Int): String {
        val h = n / 100
        val rem = n % 100
        val parts = mutableListOf<String>()
        if (h > 0) parts.add(HUNDREDS[h])
        if (rem in 10..19) {
            parts.add(TEENS[rem - 10])
        } else {
            val t = rem / 10
            val o = rem % 10
            if (t > 0) parts.add(TENS[t])
            if (o > 0) parts.add(ONES[o])
        }
        return parts.joinToString(" و ")
    }

    fun numToFaWord(n: Long, unit: String = "تومان"): String {
        val suffix = if (unit.isNotEmpty()) " $unit" else ""
        if (n == 0L) return "صفر$suffix"
        if (n < 0L) {
            if (n == Long.MIN_VALUE) return "مبلغ بسیار بزرگ"
            return "منفی " + numToFaWord(-n, unit)
        }
        if (n >= 1_000_000_000_000_000L) return "مبلغ بسیار بزرگ"

        val groups = mutableListOf<Int>()
        var temp = n
        while (temp > 0L) {
            groups.add((temp % 1000L).toInt())
            temp /= 1000L
        }

        val words = mutableListOf<String>()
        for (scaleIndex in groups.indices.reversed()) {
            val g = groups[scaleIndex]
            if (g == 0) continue
            val scale = SCALES.getOrElse(scaleIndex) { "" }
            val chunk = if (scaleIndex == 1 && g == 1) {
                "هزار"
            } else {
                val t = tri(g)
                if (scale.isNotEmpty()) "$t $scale" else t
            }
            words.add(chunk)
        }

        return words.joinToString(" و ") + suffix
    }

    fun parseMoney(raw: String?): ParseMoneyResult {
        if (raw.isNullOrEmpty()) {
            return ParseMoneyResult(v = 0L, has = false, dec = false, clamped = false)
        }
        val ascii = TextNormalizer.fa2en(raw).replace(" ", "").replace("\t", "").replace("\n", "")
        var working = ascii
        var dec = false
        val dotIndex = working.indexOf('.')
        if (dotIndex >= 0) {
            val afterDot = working.substring(dotIndex + 1)
            dec = afterDot.any { it.isDigit() }
            working = working.substring(0, dotIndex)
        }

        val digitsOnly = buildString(working.length) {
            for (ch in working) {
                if (ch in '0'..'9') append(ch)
            }
        }.trimStart('0')

        if (digitsOnly.isEmpty()) {
            val hadZero = working.any { it == '0' }
            return ParseMoneyResult(v = 0L, has = hadZero, dec = dec, clamped = false)
        }

        if (digitsOnly.length > 12) {
            return ParseMoneyResult(
                v = DomainConstants.MAX_MONEY,
                has = true,
                dec = dec,
                clamped = true
            )
        }

        val parsed = digitsOnly.toLongOrNull() ?: DomainConstants.MAX_MONEY
        return if (parsed > DomainConstants.MAX_MONEY) {
            ParseMoneyResult(
                v = DomainConstants.MAX_MONEY,
                has = true,
                dec = dec,
                clamped = true
            )
        } else {
            ParseMoneyResult(
                v = parsed,
                has = true,
                dec = dec,
                clamped = false
            )
        }
    }

    /**
     * Evaluates an inline addition/subtraction expression from WorkshopMoneyKeypad
     * such as "450000+320000-50000" and clamps to [0, MAX_MONEY].
     */
    fun evaluateInlineCalculator(expression: String): ParseMoneyResult {
        val ascii = TextNormalizer.fa2en(expression).replace(",", "").replace(" ", "")
        if (ascii.isEmpty()) return ParseMoneyResult(0L, has = false, dec = false, clamped = false)
        if (!ascii.contains('+') && !ascii.contains('-')) {
            return parseMoney(expression)
        }

        var sum = 0L
        var currentSign = 1L
        var tokenStart = 0
        var hasAny = false
        var anyClamped = false
        var anyDec = false

        fun processToken(token: String, sign: Long) {
            if (token.isNotEmpty()) {
                val r = parseMoney(token)
                if (r.has) {
                    hasAny = true
                    sum += sign * r.v
                }
                if (r.clamped) anyClamped = true
                if (r.dec) anyDec = true
            }
        }

        for (i in ascii.indices) {
            val c = ascii[i]
            if (c == '+' || c == '-' || c == '−') {
                val token = ascii.substring(tokenStart, i)
                processToken(token, currentSign)
                currentSign = if (c == '+') 1L else -1L
                tokenStart = i + 1
            }
        }
        if (tokenStart <= ascii.length) {
            processToken(ascii.substring(tokenStart), currentSign)
        }

        val clampedSum = when {
            sum < 0L -> 0L
            sum > DomainConstants.MAX_MONEY -> {
                anyClamped = true
                DomainConstants.MAX_MONEY
            }
            else -> sum
        }
        return ParseMoneyResult(
            v = clampedSum,
            has = hasAny,
            dec = anyDec,
            clamped = anyClamped
        )
    }
}
