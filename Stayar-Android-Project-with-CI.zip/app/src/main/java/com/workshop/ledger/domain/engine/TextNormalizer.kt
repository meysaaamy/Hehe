package com.workshop.ledger.domain.engine

import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale
import kotlin.math.abs

enum class DigitsMode {
    FA,
    EN
}

object TextNormalizer {
    private val PERSIAN_DIGITS = charArrayOf('۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹')

    fun fa2en(str: String): String {
        if (str.isEmpty()) return ""
        val sb = StringBuilder(str.length)
        for (ch in str) {
            when (ch) {
                in '۰'..'۹' -> sb.append(('0'.code + (ch.code - '۰'.code)).toChar())
                in '٠'..'٩' -> sb.append(('0'.code + (ch.code - '٠'.code)).toChar())
                '٫' -> sb.append('.')
                '٬', '،' -> sb.append(',')
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    fun normFa(str: String): String {
        if (str.isEmpty()) return ""
        val ascii = fa2en(str)
        val sb = StringBuilder(ascii.length)
        var lastWasSpace = true
        for (ch in ascii) {
            val mapped = when (ch) {
                'ي', 'ى', 'ئ' -> 'ی'
                'ك' -> 'ک'
                '\u200C', '\u200E', '\u200F', '\u202A', '\u202B', '\u202C', '\u202D', '\u202E' -> ' '
                else -> if (ch.isWhitespace()) ' ' else ch.lowercaseChar()
            }
            if (mapped == ' ') {
                if (!lastWasSpace) {
                    sb.append(' ')
                    lastWasSpace = true
                }
            } else {
                sb.append(mapped)
                lastWasSpace = false
            }
        }
        return sb.toString().trim()
    }

    fun srchNorm(str: String): String {
        return normFa(str).replace(",", "").replace("٬", "").replace("،", "")
    }

    fun hourDigitsFa(v: String): String {
        val sb = StringBuilder(v.length)
        for (ch in v) {
            if (ch in '0'..'9') {
                sb.append(PERSIAN_DIGITS[ch.code - '0'.code])
            } else {
                sb.append(ch)
            }
        }
        return sb.toString()
    }

    fun hrFa(v: Number): String {
        val d = v.toDouble()
        val raw = if (d % 1.0 == 0.0) d.toLong().toString() else fmtDays(d)
        return hourDigitsFa(raw).replace('.', '٫')
    }

    fun formatDisplayDigits(str: String, digitsMode: DigitsMode = DigitsMode.FA): String {
        if (digitsMode == DigitsMode.EN || str.isEmpty()) return str
        val sb = StringBuilder(str.length)
        for (i in str.indices) {
            val ch = str[i]
            when {
                ch in '0'..'9' -> sb.append(PERSIAN_DIGITS[ch.code - '0'.code])
                ch == ',' && i > 0 && i < str.lastIndex && str[i - 1].isDigit() && str[i + 1].isDigit() ->
                    sb.append('٬')
                ch == '.' && i > 0 && i < str.lastIndex && str[i - 1].isDigit() && str[i + 1].isDigit() ->
                    sb.append('٫')
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    fun fmt(n: Number): String {
        val d = n.toDouble()
        if (!d.isFinite()) return "0"
        val rounded: Long = Math.round(d)
        val sign = if (rounded < 0L) "-" else ""
        val absVal = abs(rounded)
        val symbols = DecimalFormatSymbols(Locale.US)
        val df = DecimalFormat("#,###", symbols)
        return sign + df.format(absVal)
    }

    fun fmtDisplay(n: Number, digitsMode: DigitsMode = DigitsMode.FA): String {
        return formatDisplayDigits(fmt(n), digitsMode)
    }

    fun fmtDays(d: Number): String {
        val v = d.toDouble()
        if (!v.isFinite()) return "0"
        val scaled = Math.round(v * 100.0)
        if (scaled == 0L) return "0"
        val result = scaled / 100.0
        return if (scaled % 100L == 0L) {
            (scaled / 100L).toString()
        } else if (scaled % 10L == 0L) {
            String.format(Locale.US, "%.1f", result)
        } else {
            String.format(Locale.US, "%.2f", result)
        }
    }

    fun pctText(p: Number): String {
        val v = p.toDouble()
        if (!v.isFinite()) return "0"
        val tenths = Math.round(v * 1000.0)
        return if (tenths % 10L == 0L) {
            (tenths / 10L).toString()
        } else {
            String.format(Locale.US, "%.1f", tenths / 10.0)
        }
    }

    fun pctTextWithSign(p: Number, digitsMode: DigitsMode = DigitsMode.FA): String {
        return formatDisplayDigits("${pctText(p)}٪", digitsMode)
    }

    fun vizShort(n: Number): String {
        val v = n.toDouble()
        if (!v.isFinite()) return "0"
        val sign = if (v < 0) "-" else ""
        val a = abs(v)
        val body = when {
            a >= 1_000_000_000.0 -> {
                val b = Math.round(a / 100_000_000.0) / 10.0
                val s = if (b % 1.0 == 0.0) b.toLong().toString() else String.format(Locale.US, "%.1f", b)
                "${s}B"
            }
            a >= 10_000_000.0 -> "${Math.round(a / 1_000_000.0)}M"
            a >= 1_000_000.0 -> {
                val m = Math.round(a / 100_000.0) / 10.0
                val s = if (m % 1.0 == 0.0) m.toLong().toString() else String.format(Locale.US, "%.1f", m)
                "${s}M"
            }
            a >= 1_000.0 -> "${Math.round(a / 1_000.0)}K"
            else -> Math.round(a).toString()
        }
        return sign + body
    }
}
