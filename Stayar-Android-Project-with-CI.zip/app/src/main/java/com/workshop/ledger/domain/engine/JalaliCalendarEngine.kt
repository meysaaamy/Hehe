package com.workshop.ledger.domain.engine

import com.workshop.ledger.domain.model.JalaliDate
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import java.util.Locale

object JalaliCalendarEngine {
    private val BREAKS = intArrayOf(
        -61, 9, 38, 199, 426, 686, 756, 818, 1111, 1181,
        1210, 1635, 2060, 2097, 2192, 2262, 2324, 2394, 2456, 3178
    )

    // Indexed Sunday=0..Saturday=6
    val WEEKDAYS_FA: List<String> = listOf(
        "یکشنبه",
        "دوشنبه",
        "سه‌شنبه",
        "چهارشنبه",
        "پنجشنبه",
        "جمعه",
        "شنبه"
    )

    val MONTHS_FA: List<String> = listOf(
        "فروردین",
        "اردیبهشت",
        "خرداد",
        "تیر",
        "مرداد",
        "شهریور",
        "مهر",
        "آبان",
        "آذر",
        "دی",
        "بهمن",
        "اسفند"
    )

    data class JalCalResult(val leap: Int, val gy: Int, val march: Int)
    data class GregorianDate(val gy: Int, val gm: Int, val gd: Int)

    fun jalCal(jy: Int): JalCalResult {
        val bl = BREAKS.size
        val gy = jy + 621
        var leapJ = -14
        var jp = BREAKS[0]
        require(jy >= jp && jy < BREAKS[bl - 1]) { "Invalid Jalali year: $jy" }

        var jump = 0
        for (i in 1 until bl) {
            val jm = BREAKS[i]
            jump = jm - jp
            if (jy < jm) break
            leapJ += (jump / 33) * 8 + ((jump % 33) / 4)
            jp = jm
        }
        var n = jy - jp
        leapJ += (n / 33) * 8 + (((n % 33) + 3) / 4)
        if ((jump % 33) == 4 && (jump - n) == 4) {
            leapJ += 1
        }
        val leapG = (gy / 4) - ((((gy / 100) + 1) * 3) / 4) - 150
        val march = 20 + leapJ - leapG
        if ((jump - n) < 6) {
            n = n - jump + ((jump + 4) / 33) * 33
        }
        var leap = (((n + 1) % 33) - 1) % 4
        if (leap == -1) {
            leap = 4
        }
        return JalCalResult(leap = leap, gy = gy, march = march)
    }

    fun isLeapJalaaliYear(jy: Int): Boolean {
        if (jy < BREAKS.first() || jy >= BREAKS.last()) return false
        return jalCal(jy).leap == 0
    }

    fun jalaaliMonthLength(jy: Int, jm: Int): Int {
        if (jm in 1..6) return 31
        if (jm in 7..11) return 30
        if (jm == 12) return if (isLeapJalaaliYear(jy)) 30 else 29
        return 0
    }

    fun g2d(gy: Int, gm: Int, gd: Int): Int {
        var d = ((gy + (gm - 8) / 6 + 100100) * 1461) / 4 +
            (153 * ((gm + 9) % 12) + 2) / 5 + gd - 34840408
        d = d - (((gy + 100100 + (gm - 8) / 6) / 100) * 3) / 4 + 752
        return d
    }

    fun d2g(jdn: Int): GregorianDate {
        var j = 4 * jdn + 139361631
        j = j + (((4 * jdn + 183187720) / 146097) * 3) / 4 * 4 - 3908
        val i = ((j % 1461) / 4) * 5 + 308
        val gd = (i % 153) / 5 + 1
        val gm = ((i / 153) % 12) + 1
        val gy = (j / 1461) - 100100 + (8 - gm) / 6
        return GregorianDate(gy, gm, gd)
    }

    fun j2d(jy: Int, jm: Int, jd: Int): Int {
        val r = jalCal(jy)
        return g2d(r.gy, 3, r.march) + (jm - 1) * 31 - (jm / 7) * (jm - 7) + jd - 1
    }

    fun d2j(jdn: Int): JalaliDate {
        val g = d2g(jdn)
        var jy = g.gy - 621
        val r = jalCal(jy)
        val jdn1f = g2d(g.gy, 3, r.march)
        var k = jdn - jdn1f
        if (k >= 0) {
            if (k <= 185) {
                val jm = 1 + (k / 31)
                val jd = (k % 31) + 1
                return JalaliDate.of(jy, jm, jd)
            } else {
                k -= 186
            }
        } else {
            jy -= 1
            k += 179
            if (r.leap == 1) k += 1
        }
        val jm = 7 + (k / 30)
        val jd = (k % 30) + 1
        return JalaliDate.of(jy, jm, jd)
    }

    fun gregorianToJalali(gy: Int, gm: Int, gd: Int): JalaliDate = d2j(g2d(gy, gm, gd))

    fun jalaliToGregorian(jy: Int, jm: Int, jd: Int): GregorianDate = d2g(j2d(jy, jm, jd))

    fun jParse(str: String?): JalaliDate? {
        if (str.isNullOrBlank()) return null
        val cleaned = TextNormalizer.fa2en(str.trim())
        val parts = cleaned.split('/', '-')
        if (parts.size != 3) return null
        val p0 = parts[0].toIntOrNull() ?: return null
        val p1 = parts[1].toIntOrNull() ?: return null
        val p2 = parts[2].toIntOrNull() ?: return null

        val jy: Int
        val jm: Int
        val jd: Int
        if (parts[0].length >= 4 || p0 > 31) {
            jy = p0
            jm = p1
            jd = p2
        } else if (parts[2].length >= 4 || p2 > 31) {
            jd = p0
            jm = p1
            jy = p2
        } else {
            return null
        }

        if (jy !in -61..3177) return null
        if (jm !in 1..12) return null
        val maxDay = jalaaliMonthLength(jy, jm)
        if (jd !in 1..maxDay) return null
        return JalaliDate.of(jy, jm, jd)
    }

    fun isValidStrictProjectJalaliDate(str: String?): Boolean {
        if (str == null) return false
        val m = com.workshop.ledger.domain.model.DomainConstants.JALALI_DATE_REGEX.matchEntire(str)
            ?: return false
        val jy = m.groupValues[1].toIntOrNull() ?: return false
        val jm = m.groupValues[2].toIntOrNull() ?: return false
        val jd = m.groupValues[3].toIntOrNull() ?: return false
        if (jy !in 1200..1700) return false
        if (jm !in 1..12) return false
        return jd in 1..jalaaliMonthLength(jy, jm)
    }

    fun jToJdn(str: String?): Long? {
        val parsed = jParse(str) ?: return null
        return j2d(parsed.year, parsed.month, parsed.day).toLong()
    }

    fun jTodayDate(): JalaliDate {
        val now = LocalDate.now()
        return gregorianToJalali(now.year, now.monthValue, now.dayOfMonth)
    }

    fun jTodayStr(): String = jTodayDate().toFormattedString()

    fun jNowStr(): String {
        val now = LocalDateTime.now()
        val jDate = gregorianToJalali(now.year, now.monthValue, now.dayOfMonth).toFormattedString()
        return "%s %02d:%02d".format(Locale.US, jDate, now.hour, now.minute)
    }

    fun tsText(epochMs: Long): String {
        val ldt = LocalDateTime.ofInstant(Instant.ofEpochMilli(epochMs), ZoneId.systemDefault())
        val jDate = gregorianToJalali(ldt.year, ldt.monthValue, ldt.dayOfMonth).toFormattedString()
        return "%s %02d:%02d".format(Locale.US, jDate, ldt.hour, ldt.minute)
    }

    fun jAddDays(str: String, n: Int): String {
        val parsed = jParse(str) ?: return str
        val newJdn = j2d(parsed.year, parsed.month, parsed.day) + n
        return d2j(newJdn).toFormattedString()
    }

    fun jAddMonths(ymStr: String, delta: Int): String {
        val cleaned = TextNormalizer.fa2en(ymStr.trim())
        val parts = cleaned.split('/')
        if (parts.size < 2) return ymStr
        val y = parts[0].toIntOrNull() ?: return ymStr
        val m = parts[1].toIntOrNull() ?: return ymStr
        val totalMonths = (y * 12 + (m - 1)) + delta
        val newY = Math.floorDiv(totalMonths, 12)
        val newM = Math.floorMod(totalMonths, 12) + 1
        return "%04d/%02d".format(Locale.US, newY, newM)
    }

    fun jDaysBetween(a: String, b: String): Long {
        val jdnA = jToJdn(a) ?: return 0L
        val jdnB = jToJdn(b) ?: return 0L
        return jdnB - jdnA
    }

    /**
     * Returns weekday index 0..6 where 0=Sunday..6=Saturday
     */
    fun jDowIndex(str: String): Int {
        val parsed = jParse(str) ?: return 6
        val g = jalaliToGregorian(parsed.year, parsed.month, parsed.day)
        val ld = LocalDate.of(g.gy, g.gm, g.gd)
        // Java DayOfWeek: MONDAY=1..SUNDAY=7 -> mod 7 gives SUNDAY=0, MONDAY=1, ..., SATURDAY=6
        return ld.dayOfWeek.value % 7
    }

    fun jDowStr(str: String): String {
        if (str.isBlank()) return ""
        val parsed = jParse(str) ?: return ""
        val g = jalaliToGregorian(parsed.year, parsed.month, parsed.day)
        val ld = LocalDate.of(g.gy, g.gm, g.gd)
        return WEEKDAYS_FA[ld.dayOfWeek.value % 7]
    }

    fun jHuman(str: String?, digitsMode: DigitsMode = DigitsMode.EN): String {
        if (str.isNullOrBlank()) return "—"
        val parsed = jParse(str) ?: return "—"
        val monthName = MONTHS_FA.getOrElse(parsed.month - 1) { "" }
        val raw = "${parsed.day} $monthName ${parsed.year}"
        return TextNormalizer.formatDisplayDigits(raw, digitsMode)
    }
}
