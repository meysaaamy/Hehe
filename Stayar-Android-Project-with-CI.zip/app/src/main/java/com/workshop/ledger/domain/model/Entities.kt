package com.workshop.ledger.domain.model

import com.workshop.ledger.domain.tutorial.OnboardingState
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.Transient
import kotlin.math.roundToLong

@Serializable
enum class UserType(val key: String, val labelFa: String) {
    @SerialName("master")
    MASTER("master", "اوستا"),

    @SerialName("apprentice")
    APPRENTICE("apprentice", "شاگرد"),

    @SerialName("custom")
    CUSTOM("custom", "سایر پرسنل");

    companion object {
        fun fromKey(key: String?): UserType = when (key) {
            "master" -> MASTER
            "apprentice" -> APPRENTICE
            "custom" -> CUSTOM
            else -> APPRENTICE
        }
    }
}

@Serializable
data class AppState(
    val version: Int = 3,
    val activeProjectId: String = "",
    val onboarding: OnboardingState = OnboardingState(),
    val coachDismissed: Boolean = false,
    val projects: List<Project> = emptyList()
)

@Serializable
data class Project(
    val id: String,
    val name: String = "پروژه جدید",
    val createdAt: Long = System.currentTimeMillis(),
    val settings: ProjectSettings = ProjectSettings(),
    val users: List<User> = emptyList(),
    val wages: List<Wage> = emptyList(),
    val attendance: Map<String, Map<String, AttendanceValue>> = emptyMap(),
    val expenses: List<Expense> = emptyList(),
    val receipts: List<Receipt> = emptyList(),
    val payouts: List<Payout> = emptyList(),
    val transfers: List<Transfer> = emptyList(),
    val adjustments: List<Adjustment> = emptyList(),
    val categories: List<Category> = emptyList()
) {
    @Transient
    val isSandbox: Boolean = id.startsWith("demo_quest_")

    fun liveUsers(): List<User> = users.filter { it.deletedAt == null || it.deletedAt == 0L }
}

@Serializable
data class ProjectSettings(
    val rangeFrom: String = "",
    val rangeTo: String = "",
    val theme: String = "system",
    val overtimeFactor: Double = 1.0,
    val absentPenalty: Double = 0.5,
    val profitBasis: String = "cash", // "cash" | "commitment"
    val locked: Boolean = false,
    val calcVersion: Int = 2
) {
    val overtimeFactorScaled: Long
        get() = ((if (overtimeFactor.isFinite() && overtimeFactor >= 1.0) overtimeFactor else 1.0) * 100.0).roundToLong()

    val absentPenaltyScaled: Long
        get() = ((if (absentPenalty.isFinite() && absentPenalty in 0.0..3.0) absentPenalty else 0.5) * 100.0).roundToLong()
}

@Serializable
data class User(
    val id: String,
    val name: String,
    val role: String = "",
    val type: UserType = UserType.APPRENTICE,
    val workFactor: Double = 1.0,
    val active: Boolean = true,
    val main: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val deletedAt: Long? = null
) {
    val effectiveRole: String
        get() = role.ifBlank { type.labelFa }
}

@Serializable
data class Wage(
    val id: String,
    val userId: String,
    val rate: Long,
    val effectiveDate: String
)

@Serializable
data class Expense(
    val id: String,
    val date: String,
    val amount: Long,
    val description: String,
    val categoryId: String? = null,
    val payerId: String = "shared", // "shared" or master userId
    val active: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Serializable
data class Receipt(
    val id: String,
    val dateFrom: String,
    val dateTo: String,
    val amount: Long,
    val description: String = "",
    val active: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Serializable
data class Payout(
    val id: String,
    val date: String,
    val userId: String,
    val amount: Long,
    val description: String = "",
    val active: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Serializable
data class Transfer(
    val id: String,
    val date: String,
    val kind: String = "peer", // "peer" | "advance"
    val fromId: String? = null,
    val toId: String,
    val amount: Long,
    val description: String = "",
    val active: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Serializable
data class Adjustment(
    val id: String,
    val date: String,
    val userId: String,
    val kind: String = "bonus", // "bonus" | "penalty" | "assistance" | "settle"
    val amount: Long,
    val description: String = "",
    val active: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Serializable
data class Category(
    val id: String,
    val name: String
)
