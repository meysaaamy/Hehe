package com.workshop.ledger.presentation.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import com.workshop.ledger.presentation.theme.StayarTheme

/**
 * Subtle 3D tilt card modifier with pointer tracking and specular sheen.
 * Respects ReducedMotion automatically.
 */
fun Modifier.tiltCard(maxTiltDeg: Float = 4.5f): Modifier = composed {
    val reducedMotion = StayarTheme.reducedMotion
    if (reducedMotion) return@composed this

    var rotX by remember { mutableFloatStateOf(0f) }
    var rotY by remember { mutableFloatStateOf(0f) }
    var sheenX by remember { mutableFloatStateOf(0.5f) }
    var sheenY by remember { mutableFloatStateOf(0.5f) }
    var active by remember { mutableFloatStateOf(0f) }

    val animRotX by animateFloatAsState(targetValue = rotX, animationSpec = spring(stiffness = 400f), label = "rotX")
    val animRotY by animateFloatAsState(targetValue = rotY, animationSpec = spring(stiffness = 400f), label = "rotY")
    val animActive by animateFloatAsState(targetValue = active, animationSpec = spring(stiffness = 400f), label = "active")

    this
        .pointerInput(Unit) {
            awaitEachGesture {
                val down = awaitFirstDown(requireUnconsumed = false)
                val w = size.width.toFloat().coerceAtLeast(1f)
                val h = size.height.toFloat().coerceAtLeast(1f)
                val nx = (down.position.x / w).coerceIn(0f, 1f)
                val ny = (down.position.y / h).coerceIn(0f, 1f)
                rotY = (nx - 0.5f) * 2f * maxTiltDeg
                rotX = (0.5f - ny) * 2f * maxTiltDeg
                sheenX = nx
                sheenY = ny
                active = 1f

                do {
                    val event = awaitPointerEvent()
                    val pos = event.changes.firstOrNull()?.position
                    if (pos != null) {
                        val px = (pos.x / w).coerceIn(0f, 1f)
                        val py = (pos.y / h).coerceIn(0f, 1f)
                        rotY = (px - 0.5f) * 2f * maxTiltDeg
                        rotX = (0.5f - py) * 2f * maxTiltDeg
                        sheenX = px
                        sheenY = py
                    }
                } while (event.changes.any { it.pressed })

                rotX = 0f
                rotY = 0f
                active = 0f
            }
        }
        .graphicsLayer {
            rotationX = animRotX
            rotationY = animRotY
            cameraDistance = 14f * density
        }
        .drawWithContent {
            drawContent()
            if (animActive > 0.02f) {
                drawRect(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            Color.White.copy(alpha = 0.10f * animActive),
                            Color.Transparent
                        ),
                        center = Offset(size.width * sheenX, size.height * sheenY),
                        radius = size.maxDimension * 0.7f
                    )
                )
            }
        }
}
