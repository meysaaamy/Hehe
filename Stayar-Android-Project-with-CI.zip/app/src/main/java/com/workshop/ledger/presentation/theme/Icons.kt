package com.workshop.ledger.presentation.theme

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Pure Compose Vector Icon renderer for Stayar's 14 destinations and actions.
 * Zero external asset dependencies, 100% offline vector rendering.
 */
@Composable
fun StayarIcon(
    name: String,
    modifier: Modifier = Modifier,
    tint: Color = StayarTheme.colors.text,
    size: Dp = 22.dp
) {
    Canvas(modifier = modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val stroke = Stroke(width = w * 0.09f, cap = StrokeCap.Round, join = StrokeJoin.Round)

        when (name) {
            "home" -> {
                val path = Path().apply {
                    moveTo(w * 0.15f, h * 0.48f)
                    lineTo(w * 0.50f, h * 0.16f)
                    lineTo(w * 0.85f, h * 0.48f)
                    lineTo(w * 0.85f, h * 0.86f)
                    lineTo(w * 0.15f, h * 0.86f)
                    close()
                }
                drawPath(path, color = tint, style = stroke)
            }
            "calendar" -> {
                drawRoundRect(
                    color = tint,
                    topLeft = Offset(w * 0.14f, h * 0.22f),
                    size = Size(w * 0.72f, h * 0.64f),
                    cornerRadius = CornerRadius(w * 0.10f),
                    style = stroke
                )
                drawLine(tint, Offset(w * 0.14f, h * 0.40f), Offset(w * 0.86f, h * 0.40f), strokeWidth = stroke.width)
                drawLine(tint, Offset(w * 0.32f, h * 0.12f), Offset(w * 0.32f, h * 0.28f), strokeWidth = stroke.width)
                drawLine(tint, Offset(w * 0.68f, h * 0.12f), Offset(w * 0.68f, h * 0.28f), strokeWidth = stroke.width)
            }
            "cart" -> {
                val path = Path().apply {
                    moveTo(w * 0.12f, h * 0.20f)
                    lineTo(w * 0.26f, h * 0.20f)
                    lineTo(w * 0.36f, h * 0.64f)
                    lineTo(w * 0.78f, h * 0.64f)
                    lineTo(w * 0.86f, h * 0.32f)
                    lineTo(w * 0.30f, h * 0.32f)
                }
                drawPath(path, color = tint, style = stroke)
                drawCircle(tint, radius = w * 0.07f, center = Offset(w * 0.40f, h * 0.80f))
                drawCircle(tint, radius = w * 0.07f, center = Offset(w * 0.74f, h * 0.80f))
            }
            "wallet" -> {
                drawRoundRect(
                    color = tint,
                    topLeft = Offset(w * 0.14f, h * 0.24f),
                    size = Size(w * 0.72f, h * 0.56f),
                    cornerRadius = CornerRadius(w * 0.10f),
                    style = stroke
                )
                drawCircle(tint, radius = w * 0.06f, center = Offset(w * 0.70f, h * 0.52f))
            }
            "receipt" -> {
                val path = Path().apply {
                    moveTo(w * 0.22f, h * 0.14f)
                    lineTo(w * 0.78f, h * 0.14f)
                    lineTo(w * 0.78f, h * 0.86f)
                    lineTo(w * 0.64f, h * 0.76f)
                    lineTo(w * 0.50f, h * 0.86f)
                    lineTo(w * 0.36f, h * 0.76f)
                    lineTo(w * 0.22f, h * 0.86f)
                    close()
                }
                drawPath(path, color = tint, style = stroke)
                drawLine(tint, Offset(w * 0.34f, h * 0.36f), Offset(w * 0.66f, h * 0.36f), strokeWidth = stroke.width)
                drawLine(tint, Offset(w * 0.34f, h * 0.54f), Offset(w * 0.60f, h * 0.54f), strokeWidth = stroke.width)
            }
            "transfer" -> {
                drawLine(tint, Offset(w * 0.18f, h * 0.36f), Offset(w * 0.82f, h * 0.36f), strokeWidth = stroke.width)
                drawLine(tint, Offset(w * 0.64f, h * 0.20f), Offset(w * 0.82f, h * 0.36f), strokeWidth = stroke.width)
                drawLine(tint, Offset(w * 0.82f, h * 0.64f), Offset(w * 0.18f, h * 0.64f), strokeWidth = stroke.width)
                drawLine(tint, Offset(w * 0.36f, h * 0.80f), Offset(w * 0.18f, h * 0.64f), strokeWidth = stroke.width)
            }
            "bolt" -> {
                val path = Path().apply {
                    moveTo(w * 0.56f, h * 0.12f)
                    lineTo(w * 0.24f, h * 0.54f)
                    lineTo(w * 0.50f, h * 0.54f)
                    lineTo(w * 0.44f, h * 0.88f)
                    lineTo(w * 0.76f, h * 0.46f)
                    lineTo(w * 0.50f, h * 0.46f)
                    close()
                }
                drawPath(path, color = tint, style = stroke)
            }
            "layers" -> {
                val p1 = Path().apply {
                    moveTo(w * 0.50f, h * 0.16f)
                    lineTo(w * 0.86f, h * 0.34f)
                    lineTo(w * 0.50f, h * 0.52f)
                    lineTo(w * 0.14f, h * 0.34f)
                    close()
                }
                drawPath(p1, color = tint, style = stroke)
                drawLine(tint, Offset(w * 0.14f, h * 0.54f), Offset(w * 0.50f, h * 0.70f), strokeWidth = stroke.width)
                drawLine(tint, Offset(w * 0.86f, h * 0.54f), Offset(w * 0.50f, h * 0.70f), strokeWidth = stroke.width)
                drawLine(tint, Offset(w * 0.14f, h * 0.70f), Offset(w * 0.50f, h * 0.86f), strokeWidth = stroke.width)
                drawLine(tint, Offset(w * 0.86f, h * 0.70f), Offset(w * 0.50f, h * 0.86f), strokeWidth = stroke.width)
            }
            "users" -> {
                drawCircle(tint, radius = w * 0.16f, center = Offset(w * 0.40f, h * 0.34f), style = stroke)
                drawArc(
                    color = tint,
                    startAngle = 180f,
                    sweepAngle = 180f,
                    useCenter = false,
                    topLeft = Offset(w * 0.14f, h * 0.56f),
                    size = Size(w * 0.52f, h * 0.44f),
                    style = stroke
                )
                drawCircle(tint, radius = w * 0.12f, center = Offset(w * 0.72f, h * 0.38f), style = stroke)
            }
            "chart", "chartpie" -> {
                drawLine(tint, Offset(w * 0.16f, h * 0.84f), Offset(w * 0.84f, h * 0.84f), strokeWidth = stroke.width)
                drawLine(tint, Offset(w * 0.30f, h * 0.84f), Offset(w * 0.30f, h * 0.52f), strokeWidth = stroke.width * 1.4f)
                drawLine(tint, Offset(w * 0.50f, h * 0.84f), Offset(w * 0.50f, h * 0.30f), strokeWidth = stroke.width * 1.4f)
                drawLine(tint, Offset(w * 0.70f, h * 0.84f), Offset(w * 0.70f, h * 0.18f), strokeWidth = stroke.width * 1.4f)
            }
            "shield" -> {
                val path = Path().apply {
                    moveTo(w * 0.50f, h * 0.12f)
                    lineTo(w * 0.82f, h * 0.26f)
                    lineTo(w * 0.82f, h * 0.54f)
                    lineTo(w * 0.50f, h * 0.88f)
                    lineTo(w * 0.18f, h * 0.54f)
                    lineTo(w * 0.18f, h * 0.26f)
                    close()
                }
                drawPath(path, color = tint, style = stroke)
            }
            "folder" -> {
                val path = Path().apply {
                    moveTo(w * 0.14f, h * 0.24f)
                    lineTo(w * 0.42f, h * 0.24f)
                    lineTo(w * 0.50f, h * 0.34f)
                    lineTo(w * 0.86f, h * 0.34f)
                    lineTo(w * 0.86f, h * 0.80f)
                    lineTo(w * 0.14f, h * 0.80f)
                    close()
                }
                drawPath(path, color = tint, style = stroke)
            }
            "help" -> {
                drawCircle(tint, radius = w * 0.38f, center = Offset(w * 0.50f, h * 0.50f), style = stroke)
                drawCircle(tint, radius = w * 0.05f, center = Offset(w * 0.50f, h * 0.70f))
                drawLine(tint, Offset(w * 0.50f, h * 0.54f), Offset(w * 0.50f, h * 0.34f), strokeWidth = stroke.width)
            }
            "settings" -> {
                drawCircle(tint, radius = w * 0.22f, center = Offset(w * 0.50f, h * 0.50f), style = stroke)
                drawLine(tint, Offset(w * 0.50f, h * 0.12f), Offset(w * 0.50f, h * 0.24f), strokeWidth = stroke.width)
                drawLine(tint, Offset(w * 0.50f, h * 0.76f), Offset(w * 0.50f, h * 0.88f), strokeWidth = stroke.width)
                drawLine(tint, Offset(w * 0.12f, h * 0.50f), Offset(w * 0.24f, h * 0.50f), strokeWidth = stroke.width)
                drawLine(tint, Offset(w * 0.76f, h * 0.50f), Offset(w * 0.88f, h * 0.50f), strokeWidth = stroke.width)
            }
            "lock" -> {
                drawRoundRect(
                    color = tint,
                    topLeft = Offset(w * 0.22f, h * 0.44f),
                    size = Size(w * 0.56f, h * 0.42f),
                    cornerRadius = CornerRadius(w * 0.08f),
                    style = stroke
                )
                drawArc(
                    color = tint,
                    startAngle = 180f,
                    sweepAngle = 180f,
                    useCenter = false,
                    topLeft = Offset(w * 0.32f, h * 0.18f),
                    size = Size(w * 0.36f, h * 0.44f),
                    style = stroke
                )
            }
            "theme" -> {
                drawCircle(tint, radius = w * 0.24f, center = Offset(w * 0.50f, h * 0.50f), style = stroke)
                drawLine(tint, Offset(w * 0.50f, h * 0.10f), Offset(w * 0.50f, h * 0.20f), strokeWidth = stroke.width)
                drawLine(tint, Offset(w * 0.50f, h * 0.80f), Offset(w * 0.50f, h * 0.90f), strokeWidth = stroke.width)
                drawLine(tint, Offset(w * 0.10f, h * 0.50f), Offset(w * 0.20f, h * 0.50f), strokeWidth = stroke.width)
                drawLine(tint, Offset(w * 0.80f, h * 0.50f), Offset(w * 0.90f, h * 0.50f), strokeWidth = stroke.width)
            }
            "more" -> {
                drawCircle(tint, radius = w * 0.08f, center = Offset(w * 0.24f, h * 0.50f))
                drawCircle(tint, radius = w * 0.08f, center = Offset(w * 0.50f, h * 0.50f))
                drawCircle(tint, radius = w * 0.08f, center = Offset(w * 0.76f, h * 0.50f))
            }
            "plus" -> {
                drawLine(tint, Offset(w * 0.50f, h * 0.20f), Offset(w * 0.50f, h * 0.80f), strokeWidth = stroke.width * 1.2f)
                drawLine(tint, Offset(w * 0.20f, h * 0.50f), Offset(w * 0.80f, h * 0.50f), strokeWidth = stroke.width * 1.2f)
            }
            "check" -> {
                val path = Path().apply {
                    moveTo(w * 0.20f, h * 0.52f)
                    lineTo(w * 0.42f, h * 0.74f)
                    lineTo(w * 0.82f, h * 0.28f)
                }
                drawPath(path, color = tint, style = stroke)
            }
            else -> {
                drawRoundRect(
                    color = tint,
                    topLeft = Offset(w * 0.20f, h * 0.16f),
                    size = Size(w * 0.60f, h * 0.68f),
                    cornerRadius = CornerRadius(w * 0.08f),
                    style = stroke
                )
            }
        }
    }
}
