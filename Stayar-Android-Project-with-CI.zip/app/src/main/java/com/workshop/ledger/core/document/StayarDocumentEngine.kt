package com.workshop.ledger.core.document

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import androidx.core.content.res.ResourcesCompat
import com.workshop.ledger.R
import com.workshop.ledger.domain.engine.AccountingEngine
import com.workshop.ledger.domain.engine.DigitsMode
import com.workshop.ledger.domain.engine.StatementBuilder
import com.workshop.ledger.domain.engine.TextNormalizer
import com.workshop.ledger.domain.model.AccountingResult
import com.workshop.ledger.domain.model.DomainConstants
import com.workshop.ledger.domain.model.Project
import com.workshop.ledger.domain.model.StatementModel
import com.workshop.ledger.domain.model.UserType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

sealed interface DocumentBlock {
    val heightPt: Float
    val keepWithNextPt: Float

    data class BrandHeader(
        val titleFa: String,
        val subtitleFa: String,
        val metaLineFa: String
    ) : DocumentBlock {
        override val heightPt: Float = 66f
        override val keepWithNextPt: Float = 0f
    }

    data class SectionHeading(val titleFa: String) : DocumentBlock {
        override val heightPt: Float = 28f
        // Keep-With-Next Rule: reserves +70pt so it is never orphaned from its table header and first row
        override val keepWithNextPt: Float = 70f
    }

    data class TableRow(
        val cellsFa: List<String>,
        val weights: List<Float>,
        val isHeader: Boolean = false,
        val isFooter: Boolean = false
    ) : DocumentBlock {
        override val heightPt: Float = if (isHeader) 24f else 22f
        override val keepWithNextPt: Float = if (isHeader) 24f else 0f
    }

    data class SummaryLine(
        val labelFa: String,
        val valueFa: String,
        val isHighlighted: Boolean = false,
        val isPositive: Boolean = true
    ) : DocumentBlock {
        override val heightPt: Float = if (isHighlighted) 28f else 21f
        override val keepWithNextPt: Float = 0f
    }

    data class Spacer(override val heightPt: Float = 10f) : DocumentBlock {
        override val keepWithNextPt: Float = 0f
    }
}

data class PaginatedPage(
    val pageIndex: Int,
    val blocks: List<DocumentBlock>,
    val contentHeightPt: Float
)

data class RenderedStatementImages(
    val pages: List<Bitmap>,
    val combinedTallBitmap: Bitmap?
)

class StayarDocumentEngine(private val context: Context) {

    companion object {
        const val A4_WIDTH_PT = 595
        const val A4_HEIGHT_PT = 842
        const val PNG_WIDTH_PX = 1588
        const val PNG_HEIGHT_PX = 2246
        private const val MARGIN_PT = 36f
        private const val FOOTER_RESERVE_PT = 34f
        private const val USABLE_TOP_PT = MARGIN_PT
        private const val USABLE_BOTTOM_PT = A4_HEIGHT_PT - MARGIN_PT - FOOTER_RESERVE_PT
    }

    private val regularTypeface: Typeface by lazy {
        try {
            ResourcesCompat.getFont(context, R.font.vazirmatn_regular) ?: Typeface.DEFAULT
        } catch (_: Throwable) {
            Typeface.DEFAULT
        }
    }

    private val boldTypeface: Typeface by lazy {
        try {
            ResourcesCompat.getFont(context, R.font.vazirmatn_bold) ?: Typeface.DEFAULT_BOLD
        } catch (_: Throwable) {
            Typeface.DEFAULT_BOLD
        }
    }

    private val monoTypeface: Typeface by lazy {
        try {
            ResourcesCompat.getFont(context, R.font.jetbrains_mono_medium) ?: Typeface.MONOSPACE
        } catch (_: Throwable) {
            Typeface.MONOSPACE
        }
    }

    /**
     * Pass 1: Pagination & Keep-With-Next Measurement Pass.
     * Guarantees no section heading is orphaned and no table row or summary line is ever cut in half.
     */
    fun paginate(blocks: List<DocumentBlock>): List<PaginatedPage> {
        val pages = mutableListOf<PaginatedPage>()
        var currentBlocks = mutableListOf<DocumentBlock>()
        var cursorY = USABLE_TOP_PT

        for (block in blocks) {
            val requiredEnd = cursorY + block.heightPt + block.keepWithNextPt
            if (currentBlocks.isNotEmpty() && requiredEnd > USABLE_BOTTOM_PT) {
                pages.add(
                    PaginatedPage(
                        pageIndex = pages.size,
                        blocks = currentBlocks,
                        contentHeightPt = cursorY + FOOTER_RESERVE_PT + MARGIN_PT
                    )
                )
                currentBlocks = mutableListOf()
                cursorY = USABLE_TOP_PT
            }
            currentBlocks.add(block)
            cursorY += block.heightPt
        }

        if (currentBlocks.isNotEmpty() || pages.isEmpty()) {
            pages.add(
                PaginatedPage(
                    pageIndex = pages.size,
                    blocks = currentBlocks,
                    contentHeightPt = cursorY + FOOTER_RESERVE_PT + MARGIN_PT
                )
            )
        }
        return pages
    }

    fun buildStatementBlocks(
        project: Project,
        model: StatementModel,
        digitsMode: DigitsMode = DigitsMode.FA
    ): List<DocumentBlock> {
        val f = { s: String -> TextNormalizer.formatDisplayDigits(s, digitsMode) }
        val fmtMoney = { n: Long -> f("${TextNormalizer.fmt(n)} تومان") }
        val blocks = mutableListOf<DocumentBlock>()

        val roleText = if (model.role.isNotBlank() && model.role != model.type.labelFa) {
            "${model.type.labelFa} · ${model.role}"
        } else {
            model.type.labelFa
        }
        val rangeText = StatementBuilder.rangeTextFa(model.range, digitsMode)

        blocks.add(
            DocumentBlock.BrandHeader(
                titleFa = "صورتحساب کارگاه — استایار",
                subtitleFa = "${model.name} ($roleText)",
                metaLineFa = f("پروژه: ${project.name}   |   بازه: $rangeText")
            )
        )
        blocks.add(DocumentBlock.Spacer(8f))

        // Daily Attendance Section
        val daysTitle = f("کارکرد روزانه (${TextNormalizer.fmtDays(model.person.days)} روز)")
        blocks.add(DocumentBlock.SectionHeading(daysTitle))
        if (model.dailyRows.isEmpty()) {
            blocks.add(
                DocumentBlock.SummaryLine(
                    labelFa = "حضوری در این بازه ثبت نشده است.",
                    valueFa = "—"
                )
            )
        } else if (model.type != UserType.MASTER) {
            val weights = listOf(0.18f, 0.16f, 0.16f, 0.14f, 0.18f, 0.18f)
            blocks.add(
                DocumentBlock.TableRow(
                    cellsFa = listOf("تاریخ", "روز", "وضعیت", "کسر روز", "نرخ", "مبلغ"),
                    weights = weights,
                    isHeader = true
                )
            )
            for (row in model.dailyRows) {
                blocks.add(
                    DocumentBlock.TableRow(
                        cellsFa = listOf(
                            f(row.date),
                            row.weekdayFa,
                            f(row.statusLabelFa),
                            f(TextNormalizer.fmtDays(row.fraction)),
                            f(TextNormalizer.fmt(row.rate)),
                            f(TextNormalizer.fmt(row.amount))
                        ),
                        weights = weights
                    )
                )
            }
            blocks.add(
                DocumentBlock.TableRow(
                    cellsFa = listOf(
                        "جمع",
                        "",
                        "",
                        f(TextNormalizer.fmtDays(model.person.days)),
                        "",
                        f(TextNormalizer.fmt(model.person.baseWage))
                    ),
                    weights = weights,
                    isFooter = true
                )
            )
        } else {
            val weights = listOf(0.26f, 0.24f, 0.26f, 0.24f)
            blocks.add(
                DocumentBlock.TableRow(
                    cellsFa = listOf("تاریخ", "روز", "وضعیت", "کسر روز"),
                    weights = weights,
                    isHeader = true
                )
            )
            for (row in model.dailyRows) {
                blocks.add(
                    DocumentBlock.TableRow(
                        cellsFa = listOf(
                            f(row.date),
                            row.weekdayFa,
                            f(row.statusLabelFa),
                            f(TextNormalizer.fmtDays(row.fraction))
                        ),
                        weights = weights
                    )
                )
            }
            blocks.add(
                DocumentBlock.TableRow(
                    cellsFa = listOf(
                        "جمع",
                        "",
                        "",
                        f(TextNormalizer.fmtDays(model.person.days))
                    ),
                    weights = weights,
                    isFooter = true
                )
            )
        }

        // Optional sections for Staff
        if (model.type != UserType.MASTER) {
            if (model.payouts.isNotEmpty()) {
                blocks.add(DocumentBlock.Spacer(10f))
                blocks.add(DocumentBlock.SectionHeading("پرداخت‌ها"))
                val w = listOf(0.25f, 0.30f, 0.45f)
                blocks.add(DocumentBlock.TableRow(listOf("تاریخ", "مبلغ", "توضیحات"), w, isHeader = true))
                for (p in model.payouts) {
                    blocks.add(
                        DocumentBlock.TableRow(
                            listOf(f(p.date), f(TextNormalizer.fmt(p.amount)), p.description.ifBlank { "—" }),
                            w
                        )
                    )
                }
            }
            if (model.adjustments.isNotEmpty()) {
                blocks.add(DocumentBlock.Spacer(10f))
                blocks.add(DocumentBlock.SectionHeading("پاداش، جریمه و مساعده"))
                val w = listOf(0.22f, 0.20f, 0.25f, 0.33f)
                blocks.add(DocumentBlock.TableRow(listOf("تاریخ", "نوع", "مبلغ", "توضیحات"), w, isHeader = true))
                for (a in model.adjustments) {
                    val kindFa = DomainConstants.KIND_FA[a.kind] ?: a.kind
                    blocks.add(
                        DocumentBlock.TableRow(
                            listOf(f(a.date), kindFa, f(TextNormalizer.fmt(a.amount)), a.description.ifBlank { "—" }),
                            w
                        )
                    )
                }
            }

            val sr = model.staffResult!!
            blocks.add(DocumentBlock.Spacer(10f))
            blocks.add(DocumentBlock.SectionHeading("محاسبه نهایی"))
            blocks.add(DocumentBlock.SummaryLine("دستمزد پایه", fmtMoney(sr.baseWage)))
            blocks.add(DocumentBlock.SummaryLine("+ پاداش", fmtMoney(sr.bonus)))
            blocks.add(DocumentBlock.SummaryLine("− جریمه", fmtMoney(sr.penalty)))
            blocks.add(DocumentBlock.SummaryLine("= دستمزد استحقاقی", fmtMoney(sr.entitled)))
            blocks.add(DocumentBlock.SummaryLine("− پرداختی‌ها", fmtMoney(sr.paid)))
            blocks.add(DocumentBlock.SummaryLine("− مساعده", fmtMoney(sr.assistance)))
            if (sr.debt >= 0L) {
                blocks.add(
                    DocumentBlock.SummaryLine(
                        labelFa = "مانده طلب",
                        valueFa = fmtMoney(sr.debt),
                        isHighlighted = true,
                        isPositive = true
                    )
                )
            } else {
                blocks.add(
                    DocumentBlock.SummaryLine(
                        labelFa = "اضافه‌پرداخت",
                        valueFa = fmtMoney(-sr.debt),
                        isHighlighted = true,
                        isPositive = false
                    )
                )
            }
        } else {
            // Optional sections for Master
            if (model.personalExpenses.isNotEmpty()) {
                blocks.add(DocumentBlock.Spacer(10f))
                blocks.add(DocumentBlock.SectionHeading("هزینه‌های شخصی پرداخت‌شده"))
                val w = listOf(0.25f, 0.30f, 0.45f)
                blocks.add(DocumentBlock.TableRow(listOf("تاریخ", "مبلغ", "توضیحات"), w, isHeader = true))
                for (e in model.personalExpenses) {
                    blocks.add(
                        DocumentBlock.TableRow(
                            listOf(f(e.date), f(TextNormalizer.fmt(e.amount)), e.description),
                            w
                        )
                    )
                }
            }
            if (model.transfers.isNotEmpty()) {
                blocks.add(DocumentBlock.Spacer(10f))
                blocks.add(DocumentBlock.SectionHeading("انتقال‌ها و پیش‌برداشت"))
                val w = listOf(0.22f, 0.30f, 0.23f, 0.25f)
                blocks.add(DocumentBlock.TableRow(listOf("تاریخ", "نوع", "مبلغ", "توضیحات"), w, isHeader = true))
                for (tr in model.transfers) {
                    blocks.add(
                        DocumentBlock.TableRow(
                            listOf(f(tr.date), tr.labelFa, f(TextNormalizer.fmt(tr.amount)), tr.description.ifBlank { "—" }),
                            w
                        )
                    )
                }
            }

            val mr = model.masterResult!!
            val factorStr = f(TextNormalizer.fmtDays(mr.workFactor))
            val pctStr = f(TextNormalizer.pctText(mr.percent))
            blocks.add(DocumentBlock.Spacer(10f))
            blocks.add(DocumentBlock.SectionHeading("محاسبه سهم و تراز (× ضریب $factorStr)"))
            blocks.add(DocumentBlock.SummaryLine("درصد سهم از کارکرد", "٪$pctStr"))
            blocks.add(DocumentBlock.SummaryLine("سهم پایه (٪$pctStr سود قابل تقسیم)", fmtMoney(mr.share)))
            blocks.add(DocumentBlock.SummaryLine("+ بازپرداخت هزینه شخصی", fmtMoney(mr.reimburse)))
            blocks.add(DocumentBlock.SummaryLine("− سهم از هزینه‌های شخصی مشترک", fmtMoney(mr.sharedPersonalExp)))
            blocks.add(DocumentBlock.SummaryLine("+ انتقال به دیگران", fmtMoney(mr.given)))
            blocks.add(DocumentBlock.SummaryLine("− انتقال از دیگران", fmtMoney(mr.taken)))
            blocks.add(DocumentBlock.SummaryLine("− پیش‌برداشت", fmtMoney(mr.advance)))
            blocks.add(DocumentBlock.SummaryLine("− مساعده", fmtMoney(mr.assistance)))
            blocks.add(DocumentBlock.SummaryLine("+ پاداش", fmtMoney(mr.bonus)))
            blocks.add(DocumentBlock.SummaryLine("− جریمه", fmtMoney(mr.penalty)))
            blocks.add(DocumentBlock.SummaryLine("+ تسویه نقدی", fmtMoney(mr.settle)))
            blocks.add(
                DocumentBlock.SummaryLine(
                    labelFa = "مانده تسویه نهایی",
                    valueFa = fmtMoney(mr.finalBalance),
                    isHighlighted = true,
                    isPositive = mr.finalBalance >= 0L
                )
            )
        }

        return blocks
    }

    fun buildProjectFullReportBlocks(
        project: Project,
        r: AccountingResult = AccountingEngine.compute(project),
        digitsMode: DigitsMode = DigitsMode.FA
    ): List<DocumentBlock> {
        val f = { s: String -> TextNormalizer.formatDisplayDigits(s, digitsMode) }
        val fmtMoney = { n: Long -> f("${TextNormalizer.fmt(n)} تومان") }
        val blocks = mutableListOf<DocumentBlock>()
        val basisFa = if (r.basis == "commitment") "تعهدی (تسویه نهایی)" else "نقدی"
        val rangeText = StatementBuilder.rangeTextFa(r.range, digitsMode)

        blocks.add(
            DocumentBlock.BrandHeader(
                titleFa = "گزارش مالی کارگاه — استایار",
                subtitleFa = project.name,
                metaLineFa = f("بازه: $rangeText   |   مبنای سود: $basisFa")
            )
        )
        blocks.add(DocumentBlock.Spacer(8f))
        blocks.add(DocumentBlock.SectionHeading("شاخص‌های کلیدی مالی"))
        blocks.add(DocumentBlock.SummaryLine("مجموع واریزی کارفرما", fmtMoney(r.totalReceipts)))
        blocks.add(DocumentBlock.SummaryLine("هزینه‌های مشترک (از صندوق)", fmtMoney(r.sharedExpenses)))
        blocks.add(DocumentBlock.SummaryLine("هزینه‌های شخصی اوستاها (از جیب)", fmtMoney(r.personalExpTotal)))
        blocks.add(DocumentBlock.SummaryLine("کل دستمزد استحقاقی شاگردان", fmtMoney(r.totalWages)))
        blocks.add(DocumentBlock.SummaryLine("پرداختی‌های نقدی + مساعده پرسنل", fmtMoney(r.totalCashPayouts + r.staffAssistance)))
        blocks.add(
            DocumentBlock.SummaryLine(
                labelFa = "مانده قابل تقسیم بین اوستاها",
                valueFa = fmtMoney(r.profit),
                isHighlighted = true,
                isPositive = r.profit >= 0L
            )
        )

        blocks.add(DocumentBlock.Spacer(12f))
        blocks.add(DocumentBlock.SectionHeading("سهم و مانده تسویه اوستاها"))
        val mw = listOf(0.22f, 0.14f, 0.12f, 0.14f, 0.19f, 0.19f)
        blocks.add(
            DocumentBlock.TableRow(
                listOf("نام اوستا", "کارکرد", "ضریب", "درصد سهم", "سهم پایه", "مانده نهایی"),
                mw,
                isHeader = true
            )
        )
        for (m in r.masters) {
            blocks.add(
                DocumentBlock.TableRow(
                    listOf(
                        m.name,
                        f("${TextNormalizer.fmtDays(m.days)} روز"),
                        f(TextNormalizer.fmtDays(m.workFactor)),
                        f("٪${TextNormalizer.pctText(m.percent)}"),
                        f(TextNormalizer.fmt(m.share)),
                        f(TextNormalizer.fmt(m.finalBalance))
                    ),
                    mw
                )
            )
        }

        if (r.staff.isNotEmpty()) {
            blocks.add(DocumentBlock.Spacer(12f))
            blocks.add(DocumentBlock.SectionHeading("تراز حساب شاگردان و پرسنل"))
            val sw = listOf(0.24f, 0.16f, 0.14f, 0.16f, 0.15f, 0.15f)
            blocks.add(
                DocumentBlock.TableRow(
                    listOf("نام", "نوع", "کارکرد", "استحقاقی", "دریافتی", "مانده"),
                    sw,
                    isHeader = true
                )
            )
            for (s in r.staff) {
                blocks.add(
                    DocumentBlock.TableRow(
                        listOf(
                            s.name,
                            s.type.labelFa,
                            f("${TextNormalizer.fmtDays(s.days)} روز"),
                            f(TextNormalizer.fmt(s.entitled)),
                            f(TextNormalizer.fmt(s.totalPaid)),
                            f(TextNormalizer.fmt(s.debt))
                        ),
                        sw
                    )
                )
            }
        }

        return blocks
    }

    /**
     * Pass 2 (Target A): Renders paginated blocks directly onto PdfDocument vector canvas (< 40 ms).
     */
    suspend fun renderVectorPdfToFile(
        blocks: List<DocumentBlock>,
        outputFile: File,
        digitsMode: DigitsMode = DigitsMode.FA
    ): Boolean = withContext(Dispatchers.Default) {
        val pages = paginate(blocks)
        val pdfDocument = PdfDocument()
        try {
            val totalPages = pages.size
            for (page in pages) {
                val pageInfo = PdfDocument.PageInfo.Builder(
                    A4_WIDTH_PT,
                    A4_HEIGHT_PT,
                    page.pageIndex + 1
                ).create()
                val pdfPage = pdfDocument.startPage(pageInfo)
                drawPageToCanvas(
                    canvas = pdfPage.canvas,
                    page = page,
                    totalPages = totalPages,
                    scale = 1f,
                    digitsMode = digitsMode
                )
                pdfDocument.finishPage(pdfPage)
            }
            withContext(Dispatchers.IO) {
                FileOutputStream(outputFile).use { fos ->
                    pdfDocument.writeTo(fos)
                    fos.flush()
                }
            }
            true
        } catch (_: Throwable) {
            false
        } finally {
            pdfDocument.close()
        }
    }

    /**
     * Pass 2 (Target B): Renders A4 PNG Bitmaps (1588 x 2246 px at 2x scale),
     * cropping the last page of a statement to its content height (minimum 28% of page height)
     * and optionally building a tall stacked image (<= 15000px height with 24px grey gaps).
     */
    suspend fun renderA4Bitmaps(
        blocks: List<DocumentBlock>,
        cropLastPage: Boolean = true,
        digitsMode: DigitsMode = DigitsMode.FA
    ): RenderedStatementImages = withContext(Dispatchers.Default) {
        val pages = paginate(blocks)
        val totalPages = pages.size
        val scale = PNG_WIDTH_PX.toFloat() / A4_WIDTH_PT.toFloat()
        val renderedPages = mutableListOf<Bitmap>()

        for ((idx, page) in pages.withIndex()) {
            val isLast = idx == pages.lastIndex
            val targetHeightPx = if (isLast && cropLastPage) {
                val minHeightPx = (PNG_HEIGHT_PX * 0.28f).roundToInt()
                val neededPx = (page.contentHeightPt * scale).roundToInt()
                neededPx.coerceIn(minHeightPx, PNG_HEIGHT_PX)
            } else {
                PNG_HEIGHT_PX
            }

            val bmp = Bitmap.createBitmap(PNG_WIDTH_PX, targetHeightPx, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bmp)
            drawPageToCanvas(
                canvas = canvas,
                page = page,
                totalPages = totalPages,
                scale = scale,
                digitsMode = digitsMode,
                customHeightPx = targetHeightPx
            )
            renderedPages.add(bmp)
        }

        val combined = if (renderedPages.size > 1) {
            buildStackedBitmap(renderedPages)
        } else {
            renderedPages.firstOrNull()
        }

        RenderedStatementImages(
            pages = renderedPages,
            combinedTallBitmap = combined
        )
    }

    suspend fun saveBitmapToPngFile(bitmap: Bitmap, fileName: String): File = withContext(Dispatchers.IO) {
        val dir = File(context.cacheDir, "exports").apply { mkdirs() }
        val outFile = File(dir, fileName)
        FileOutputStream(outFile).use { out ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
        }
        outFile
    }

    fun stitchBitmapsVertically(pages: List<Bitmap>): Bitmap = buildStackedBitmap(pages)

    fun buildStackedBitmap(pages: List<Bitmap>): Bitmap {
        val gapPx = 24
        val rawTotalHeight = pages.sumOf { it.height } + gapPx * (pages.size - 1)
        val maxHeight = 15_000
        val downscale = if (rawTotalHeight > maxHeight) {
            maxHeight.toFloat() / rawTotalHeight.toFloat()
        } else {
            1f
        }
        val outW = (PNG_WIDTH_PX * downscale).roundToInt().coerceAtLeast(1)
        val outH = min(maxHeight, (rawTotalHeight * downscale).roundToInt()).coerceAtLeast(1)

        val stacked = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(stacked)
        canvas.drawColor(Color.parseColor("#D6CFC2"))
        canvas.scale(downscale, downscale)

        var y = 0f
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        for (bmp in pages) {
            canvas.drawBitmap(bmp, 0f, y, paint)
            y += bmp.height + gapPx
        }
        return stacked
    }

    private fun drawPageToCanvas(
        canvas: Canvas,
        page: PaginatedPage,
        totalPages: Int,
        scale: Float,
        digitsMode: DigitsMode,
        customHeightPx: Int = (A4_HEIGHT_PT * scale).roundToInt()
    ) {
        canvas.save()
        canvas.scale(scale, scale)

        val pageWidth = A4_WIDTH_PT.toFloat()
        val pageHeight = customHeightPx / scale
        val contentLeft = MARGIN_PT
        val contentRight = pageWidth - MARGIN_PT
        val contentWidth = contentRight - contentLeft

        val bgPaint = Paint().apply { color = Color.parseColor("#FFFDF8") }
        canvas.drawRect(0f, 0f, pageWidth, pageHeight, bgPaint)

        val accentPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#1F5140") }
        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#D3C4A4")
            style = Paint.Style.STROKE
            strokeWidth = 1f
        }
        val rowFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#F5EDDA") }
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#201D15")
            typeface = regularTypeface
            textSize = 10f
            textAlign = Paint.Align.RIGHT
        }
        val boldPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#201D15")
            typeface = boldTypeface
            textSize = 11f
            textAlign = Paint.Align.RIGHT
        }
        val monoPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#201D15")
            typeface = monoTypeface
            fontFeatureSettings = "tnum"
            textSize = 10f
            textAlign = Paint.Align.LEFT
        }

        var y = USABLE_TOP_PT
        for (block in page.blocks) {
            when (block) {
                is DocumentBlock.BrandHeader -> {
                    val rect = RectF(contentLeft, y, contentRight, y + block.heightPt - 6f)
                    canvas.drawRoundRect(rect, 8f, 8f, accentPaint)

                    val headerPaint = Paint(boldPaint).apply {
                        color = Color.WHITE
                        textSize = 14f
                        textAlign = Paint.Align.RIGHT
                    }
                    canvas.drawText(block.titleFa, contentRight - 14f, y + 22f, headerPaint)

                    val subPaint = Paint(regularTypeface.let { Paint(textPaint) }).apply {
                        color = Color.parseColor("#EFE6D3")
                        textSize = 11f
                        textAlign = Paint.Align.RIGHT
                    }
                    canvas.drawText(block.subtitleFa, contentRight - 14f, y + 39f, subPaint)
                    canvas.drawText(block.metaLineFa, contentRight - 14f, y + 54f, subPaint)
                    y += block.heightPt
                }

                is DocumentBlock.SectionHeading -> {
                    val headingPaint = Paint(boldPaint).apply {
                        color = Color.parseColor("#1F5140")
                        textSize = 12f
                    }
                    canvas.drawText(block.titleFa, contentRight, y + 18f, headingPaint)
                    canvas.drawLine(contentLeft, y + 24f, contentRight, y + 24f, borderPaint)
                    y += block.heightPt
                }

                is DocumentBlock.TableRow -> {
                    val rowRect = RectF(contentLeft, y, contentRight, y + block.heightPt)
                    if (block.isHeader || block.isFooter) {
                        canvas.drawRect(rowRect, rowFillPaint)
                    }
                    canvas.drawRect(rowRect, borderPaint)

                    // RTL columns: first column on the right
                    var colRight = contentRight
                    val cellPaint = if (block.isHeader || block.isFooter) boldPaint else textPaint
                    cellPaint.textSize = 9.5f
                    for (i in block.cellsFa.indices) {
                        val w = block.weights.getOrElse(i) { 1f / block.cellsFa.size } * contentWidth
                        val colLeft = colRight - w
                        val text = block.cellsFa[i]
                        canvas.drawText(text, colRight - 6f, y + 15f, cellPaint)
                        if (i < block.cellsFa.lastIndex) {
                            canvas.drawLine(colLeft, y, colLeft, y + block.heightPt, borderPaint)
                        }
                        colRight = colLeft
                    }
                    y += block.heightPt
                }

                is DocumentBlock.SummaryLine -> {
                    if (block.isHighlighted) {
                        val hlPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                            color = if (block.isPositive) Color.parseColor("#E6F4EC") else Color.parseColor("#FCEBEC")
                        }
                        val rect = RectF(contentLeft, y, contentRight, y + block.heightPt - 2f)
                        canvas.drawRoundRect(rect, 6f, 6f, hlPaint)
                        canvas.drawRoundRect(rect, 6f, 6f, borderPaint)
                    } else {
                        canvas.drawLine(contentLeft, y + block.heightPt - 1f, contentRight, y + block.heightPt - 1f, borderPaint)
                    }
                    val lPaint = if (block.isHighlighted) boldPaint else textPaint
                    lPaint.textSize = if (block.isHighlighted) 11f else 10f
                    canvas.drawText(block.labelFa, contentRight - 8f, y + 16f, lPaint)

                    val vPaint = Paint(monoPaint).apply {
                        textSize = if (block.isHighlighted) 11f else 10f
                        color = when {
                            !block.isHighlighted -> Color.parseColor("#201D15")
                            block.isPositive -> Color.parseColor("#1F5140")
                            else -> Color.parseColor("#CF4A3F")
                        }
                    }
                    canvas.drawText(block.valueFa, contentLeft + 8f, y + 16f, vPaint)
                    y += block.heightPt
                }

                is DocumentBlock.Spacer -> {
                    y += block.heightPt
                }
            }
        }

        // Footer
        val footerY = pageHeight - 16f
        val footerPaint = Paint(textPaint).apply {
            color = Color.parseColor("#6D6454")
            textSize = 8.5f
            textAlign = Paint.Align.RIGHT
        }
        val pageNumStr = TextNormalizer.formatDisplayDigits("${page.pageIndex + 1} / $totalPages", digitsMode)
        canvas.drawText("تهیه‌شده با استایار — دفتر حساب کارگاه", contentRight, footerY, footerPaint)
        val pagePaint = Paint(monoPaint).apply {
            color = Color.parseColor("#6D6454")
            textSize = 8.5f
            textAlign = Paint.Align.LEFT
        }
        canvas.drawText(pageNumStr, contentLeft, footerY, pagePaint)

        canvas.restore()
    }
}
