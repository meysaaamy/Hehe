package com.workshop.ledger.domain.tutorial

import com.workshop.ledger.domain.engine.JalaliCalendarEngine
import com.workshop.ledger.domain.engine.TextNormalizer
import com.workshop.ledger.domain.model.AttendanceValue
import com.workshop.ledger.domain.model.Category
import com.workshop.ledger.domain.model.DomainConstants
import com.workshop.ledger.domain.model.Expense
import com.workshop.ledger.domain.model.Project
import com.workshop.ledger.domain.model.User
import com.workshop.ledger.domain.model.UserType
import com.workshop.ledger.domain.model.Wage

object TutorialChapters {

    const val USER_REZA_ID = "u_tutor_reza"
    const val USER_HASSAN_ID = "u_tutor_hassan"
    const val EXP_TOOL_ID = "exp_tutor_tool"
    const val CAT_TOOLS_ID = "cat_tutor_tools"

    /**
     * Skipped-step helper: ensures apprentice «رضا» exists with a daily wage rate.
     */
    fun tutorEnsureReza(project: Project): Project {
        val exists = project.liveUsers().any {
            it.id == USER_REZA_ID || TextNormalizer.normFa(it.name).contains("رضا")
        }
        if (exists) return project
        val today = JalaliCalendarEngine.jTodayStr()
        val reza = User(
            id = USER_REZA_ID,
            name = "رضا",
            role = "شاگرد",
            type = UserType.APPRENTICE,
            workFactor = 1.0,
            active = true,
            main = false
        )
        val wage = Wage(
            id = "w_tutor_reza",
            userId = USER_REZA_ID,
            rate = 900_000L,
            effectiveDate = project.settings.rangeFrom.ifEmpty { today }
        )
        return project.copy(
            users = project.users + reza,
            wages = project.wages + wage
        )
    }

    /**
     * Skipped-step helper: ensures master partner «اوستا حسن» exists with workFactor 1.5.
     */
    fun tutorEnsureHassan(project: Project): Project {
        val exists = project.liveUsers().any {
            it.id == USER_HASSAN_ID || TextNormalizer.normFa(it.name).contains("حسن")
        }
        if (exists) return project
        val hassan = User(
            id = USER_HASSAN_ID,
            name = "اوستا حسن",
            role = "اوستا ارشد",
            type = UserType.MASTER,
            workFactor = 1.5,
            active = true,
            main = false
        )
        return project.copy(users = project.users + hassan)
    }

    /**
     * Skipped-step helper: ensures category «ابزار و یراق» exists.
     */
    fun tutorEnsureCat(project: Project): Project {
        val exists = project.categories.any {
            it.id == CAT_TOOLS_ID || TextNormalizer.normFa(it.name).contains("ابزار")
        }
        if (exists) return project
        val cat = Category(id = CAT_TOOLS_ID, name = "ابزار و یراق")
        return project.copy(categories = project.categories + cat)
    }

    /**
     * Skipped-step helper: ensures personal tool expense exists.
     */
    fun tutorEnsureToolExpense(project: Project): Project {
        val withCat = tutorEnsureCat(project)
        if (withCat.expenses.isNotEmpty()) return withCat
        val today = JalaliCalendarEngine.jTodayStr()
        val exp = Expense(
            id = EXP_TOOL_ID,
            date = today,
            amount = 500_000L,
            description = "خرید ماله و تراز",
            categoryId = withCat.categories.firstOrNull()?.id,
            payerId = PracticeSandboxSeeder.MASTER_ME_ID,
            active = true
        )
        return withCat.copy(expenses = withCat.expenses + exp)
    }

    val CHAPTER_TITLES_FA: Map<Int, String> = mapOf(
        1 to "فصل ۱: راه‌اندازی، حضور و تقسیم سود پایه (۱۵ گام)",
        2 to "فصل ۲: ضرایب، اضافه‌کار، تعدیل‌ها و تسویه داخلی (۷ گام)",
        3 to "فصل ۳: مبنای نقدی/تعهدی، گزارش‌ها، سلامت داده و قفل مالی (۶ گام)"
    )

    val STEPS: List<TutorialStep> = listOf(
        // ====================================================================
        // CHAPTER 1 — 15 Steps (indices 0..14)
        // ====================================================================
        TutorialStep(
            index = 0,
            chapter = 1,
            stepInChapter = 1,
            id = "c1_welcome_users",
            titleFa = "ورود به بخش کاربران",
            sayFa = "به کارگاه تمرینی خوش آمدید! در این کارگاه ۵ روز کار، ۱۰ میلیون واریزی و ۵ میلیون دستمزد آماده است. ابتدا به بخش «کاربران» بروید تا تیم کارگاه را ببینیم.",
            aim = AimTarget(page = "users", targetId = "nav_users", hintFa = "روی «کاربران» بزنید"),
            done = { _, _, ev -> ev.currentPage == "users" },
            resultFa = { p, _ -> "عالی! الان ${p.liveUsers().size} نفر در کارگاه تعریف شده‌اند." }
        ),
        TutorialStep(
            index = 1,
            chapter = 1,
            stepInChapter = 2,
            id = "c1_add_reza",
            titleFa = "افزودن شاگرد جدید (رضا)",
            sayFa = "حالا یک شاگرد جدید به نام «رضا» با دکمهٔ «کاربر جدید» اضافه کنید.",
            aim = AimTarget(page = "users", targetId = "crud_add_users", hintFa = "کاربر جدید «رضا» را بسازید"),
            preset = TutorialPreset(
                fields = mapOf("name" to "رضا", "type" to "apprentice", "role" to "شاگرد"),
                labelFa = "پر کردن مشخصات رضا"
            ),
            done = { p, _, _ -> p.liveUsers().count { it.type != UserType.MASTER } >= 2 },
            resultFa = { _, _ -> "شاگرد جدید با موفقیت به تیم کارگاه اضافه شد." }
        ),
        TutorialStep(
            index = 2,
            chapter = 1,
            stepInChapter = 3,
            id = "c1_add_wage",
            titleFa = "ثبت نرخ دستمزد روزانه",
            sayFa = "هر شاگرد به نرخ دستمزد روزانه نیاز دارد. در بخش «دستمزدها» برای شاگرد جدید نرخ روزانه ۹۰۰٬۰۰۰ تومان ثبت کنید.",
            aim = AimTarget(page = "wages", targetId = "crud_add_wages", hintFa = "نرخ روزانه ۹۰۰٬۰۰۰ تومان ثبت کنید"),
            preset = TutorialPreset(
                fields = mapOf("rate" to "900000"),
                labelFa = "نرخ ۹۰۰٬۰۰۰ تومان"
            ),
            done = { p, _, _ -> p.wages.size >= 2 },
            resultFa = { _, _ -> "نرخ دستمزد ثبت شد؛ از این به بعد هر روز حضور او خودکار ضربدر این نرخ می‌شود." }
        ),
        TutorialStep(
            index = 3,
            chapter = 1,
            stepInChapter = 4,
            id = "c1_open_attendance",
            titleFa = "رفتن به صفحهٔ حضور و غیاب",
            sayFa = "حالا به صفحهٔ «حضور و غیاب» بروید تا کارکرد امروز بچه‌ها را ثبت کنیم.",
            aim = AimTarget(page = "attendance", targetId = "nav_attendance", hintFa = "بخش «حضور و غیاب» را باز کنید"),
            done = { _, _, ev -> ev.currentPage == "attendance" },
            resultFa = { _, _ -> "صفحهٔ حضور و غیاب آمادهٔ ثبت کارکرد امروز است." }
        ),
        TutorialStep(
            index = 4,
            chapter = 1,
            stepInChapter = 5,
            id = "c1_mark_master_full",
            titleFa = "ثبت حضور کامل اوستا",
            sayFa = "روی دکمهٔ «کامل (۸ ساعت)» برای اوستای اصلی بزنید تا حضور امروز شما ثبت شود.",
            aim = AimTarget(page = "attendance", targetId = "att_btn_full_u_master_me", hintFa = "دکمهٔ «کامل» اوستای اصلی را بزنید"),
            done = { p, _, _ ->
                val today = JalaliCalendarEngine.jTodayStr()
                p.attendance[today]?.get(PracticeSandboxSeeder.MASTER_ME_ID) == AttendanceValue.Full
            },
            resultFa = { _, r ->
                val me = r.masters.find { it.id == PracticeSandboxSeeder.MASTER_ME_ID }
                "حضور کامل ثبت شد؛ کارکرد شما به ${TextNormalizer.fmtDays(me?.days ?: 6.0)} روز رسید."
            }
        ),
        TutorialStep(
            index = 5,
            chapter = 1,
            stepInChapter = 6,
            id = "c1_mark_partner_half",
            titleFa = "ثبت حضور نصفه برای شریک",
            sayFa = "فرض کنید اوستا کاظم امروز نصف روز در کارگاه بوده است. روی «نصفه (۴ ساعت)» او بزنید.",
            aim = AimTarget(page = "attendance", targetId = "att_btn_half_u_master_partner", hintFa = "دکمهٔ «نصفه» اوستا کاظم را بزنید"),
            done = { p, _, _ ->
                val today = JalaliCalendarEngine.jTodayStr()
                p.attendance[today]?.get(PracticeSandboxSeeder.MASTER_PARTNER_ID) == AttendanceValue.Half
            },
            resultFa = { _, r ->
                val partner = r.masters.find { it.id == PracticeSandboxSeeder.MASTER_PARTNER_ID }
                "نصف روز ثبت شد؛ کارکرد اوستا کاظم الان ${TextNormalizer.fmtDays(partner?.days ?: 5.5)} روز است."
            }
        ),
        TutorialStep(
            index = 6,
            chapter = 1,
            stepInChapter = 7,
            id = "c1_mark_ali_hourly",
            titleFa = "ثبت کارکرد ساعتی و اضافه‌کار",
            sayFa = "علی امروز ۱۰ ساعت کار کرده (۲ ساعت اضافه‌کار). روی «ساعتی» در کارت علی بزنید و ۱۰ ساعت را ثبت کنید.",
            aim = AimTarget(page = "attendance", targetId = "att_btn_hourly_u_apprentice_ali", hintFa = "روی «ساعتی» علی بزنید و ۱۰ ساعت انتخاب کنید"),
            done = { p, _, _ ->
                val today = JalaliCalendarEngine.jTodayStr()
                p.attendance[today]?.get(PracticeSandboxSeeder.APPRENTICE_ALI_ID) is AttendanceValue.Hourly
            },
            resultFa = { _, r ->
                val ali = r.staff.find { it.id == PracticeSandboxSeeder.APPRENTICE_ALI_ID }
                "ساعت کار ثبت شد؛ دستمزد استحقاقی علی به ${TextNormalizer.fmtDisplay(ali?.entitled ?: 0L)} تومان رسید."
            }
        ),
        TutorialStep(
            index = 7,
            chapter = 1,
            stepInChapter = 8,
            id = "c1_add_receipt",
            titleFa = "ثبت واریزی جدید کارفرما",
            sayFa = "کارفرما قسط دوم به مبلغ ۵٬۰۰۰٬۰۰۰ تومان واریز کرده است. در بخش «واریزی‌های کارفرما» آن را ثبت کنید.",
            aim = AimTarget(page = "receipts", targetId = "crud_add_receipts", hintFa = "واریزی ۵٬۰۰۰٬۰۰۰ تومان ثبت کنید"),
            preset = TutorialPreset(
                fields = mapOf("amount" to "5000000", "description" to "قسط دوم کارفرما"),
                labelFa = "پر کردن قسط ۵ میلیونی"
            ),
            done = { p, _, _ -> p.receipts.count { it.active } >= 2 },
            resultFa = { _, r -> "مجموع واریزی کارفرما در بازه به ${TextNormalizer.fmtDisplay(r.totalReceipts)} تومان رسید." }
        ),
        TutorialStep(
            index = 8,
            chapter = 1,
            stepInChapter = 9,
            id = "c1_add_shared_expense",
            titleFa = "ثبت هزینهٔ مشترک از صندوق",
            sayFa = "حالا در بخش «هزینه‌ها» یک هزینهٔ مشترک ۱٬۰۰۰٬۰۰۰ تومانی بابت خرید سیمان (پرداخت‌کننده: صندوق مشترک کارگاه) ثبت کنید.",
            aim = AimTarget(page = "expenses", targetId = "crud_add_expenses", hintFa = "هزینهٔ مشترک ۱٬۰۰۰٬۰۰۰ تومانی ثبت کنید"),
            preset = TutorialPreset(
                fields = mapOf("amount" to "1000000", "description" to "خرید سیمان از صندوق", "payerId" to "shared"),
                labelFa = "هزینه مشترک ۱ میلیون تومان"
            ),
            done = { p, _, _ -> p.expenses.any { it.active && it.payerId == "shared" } },
            resultFa = { _, r -> "هزینهٔ مشترک ثبت شد و مستقیماً از سود قابل تقسیم کم شد (جمع مشترک: ${TextNormalizer.fmtDisplay(r.sharedExpenses)} تومان)." }
        ),
        TutorialStep(
            index = 9,
            chapter = 1,
            stepInChapter = 10,
            id = "c1_add_personal_expense",
            titleFa = "ثبت هزینهٔ شخصی اوستا (از جیب)",
            sayFa = "گاهی اوستا از جیب خودش خرید می‌کند. یک هزینهٔ ۵۰۰٬۰۰۰ تومانی ثبت کنید و پرداخت‌کننده را «شخصی: اوستای اصلی (شما)» بگذارید.",
            aim = AimTarget(page = "expenses", targetId = "crud_add_expenses", hintFa = "هزینهٔ شخصی به نام خودتان ثبت کنید"),
            preset = TutorialPreset(
                fields = mapOf(
                    "amount" to "500000",
                    "description" to "خرید ماله و تراز از جیب",
                    "payerId" to PracticeSandboxSeeder.MASTER_ME_ID
                ),
                labelFa = "هزینه شخصی ۵۰۰ هزار تومان"
            ),
            done = { p, _, _ -> p.expenses.any { it.active && it.payerId != "shared" } },
            resultFa = { _, _ -> "هزینهٔ شخصی ثبت شد! کل مبلغ به پرداخت‌کننده برمی‌گردد و سهم هر اوستا به نسبت کارکرد کسر می‌شود." }
        ),
        TutorialStep(
            index = 10,
            chapter = 1,
            stepInChapter = 11,
            id = "c1_add_payout",
            titleFa = "ثبت پرداختی نقدی به شاگرد",
            sayFa = "در بخش «پرداختی‌های شاگردها» مبلغ ۲٬۰۰۰٬۰۰۰ تومان پرداخت نقدی به علی ثبت کنید.",
            aim = AimTarget(page = "payouts", targetId = "crud_add_payouts", hintFa = "پرداختی ۲٬۰۰۰٬۰۰۰ تومان به علی ثبت کنید"),
            preset = TutorialPreset(
                fields = mapOf(
                    "userId" to PracticeSandboxSeeder.APPRENTICE_ALI_ID,
                    "amount" to "2000000",
                    "description" to "علی‌الحساب نقدی"
                ),
                labelFa = "پرداخت ۲ میلیون به علی"
            ),
            done = { p, _, _ -> p.payouts.any { it.active } },
            resultFa = { _, r ->
                val ali = r.staff.find { it.id == PracticeSandboxSeeder.APPRENTICE_ALI_ID }
                "پرداخت ثبت شد؛ مانده طلب علی به ${TextNormalizer.fmtDisplay(ali?.debt ?: 0L)} تومان کاهش یافت."
            }
        ),
        TutorialStep(
            index = 11,
            chapter = 1,
            stepInChapter = 12,
            id = "c1_open_dashboard",
            titleFa = "بازگشت به داشبورد",
            sayFa = "حالا به «داشبورد» برگردید تا نتیجهٔ لحظه‌ای تمام حساب‌ها را ببینید.",
            aim = AimTarget(page = "dashboard", targetId = "nav_dashboard", hintFa = "روی «داشبورد» بزنید"),
            done = { _, _, ev -> ev.currentPage == "dashboard" },
            resultFa = { _, r -> "مانده قابل تقسیم فعلی کارگاه: ${TextNormalizer.fmtDisplay(r.profit)} تومان." }
        ),
        TutorialStep(
            index = 12,
            chapter = 1,
            stepInChapter = 13,
            id = "result",
            titleFa = "مشاهدهٔ خط‌کش سود («حساب شفاف»)",
            sayFa = "روی کارت بزرگ «مانده قابل تقسیم بین اوستاها» بزنید تا خط‌کش حساب شفاف باز شود و فرمول دقیق هر عدد را ببینید.",
            aim = AimTarget(page = "dashboard", targetId = "kpi_profit", hintFa = "کارت «مانده قابل تقسیم» را لمس کنید"),
            done = { _, _, ev -> ev.openedProfitRuler },
            resultFa = { _, _ -> "دیدید که هیچ عددی در استایار پنهان نیست و فرمول پشت هر رقم با یک لمس باز می‌شود!" }
        ),
        TutorialStep(
            index = 13,
            chapter = 1,
            stepInChapter = 14,
            id = "c1_open_master_statement",
            titleFa = "مشاهدهٔ صورتحساب اوستا",
            sayFa = "در بخش «سهم و مانده اوستاها» روی کارت خودتان بزنید تا برگهٔ صورتحساب کامل باز شود.",
            aim = AimTarget(page = "dashboard", targetId = "master_card_u_master_me", hintFa = "روی کارت اوستای اصلی بزنید"),
            done = { _, _, ev -> ev.viewedStatementUserId != null },
            resultFa = { _, _ -> "صورتحساب ریز روزانه و محاسبهٔ تراز نهایی با قابلیت خروجی A4 و PDF آماده است." }
        ),
        TutorialStep(
            index = 14,
            chapter = 1,
            stepInChapter = 15,
            id = "c1_matrix_view",
            titleFa = "نمای ماتریس ماهانه حضور",
            sayFa = "در صفحهٔ «حضور و غیاب» کلید «ماتریس ماهانه» را بزنید تا جدول یک‌جا و کلّی ماه را ببینید.",
            aim = AimTarget(page = "attendance", targetId = "att_view_matrix", hintFa = "کلید «ماتریس ماهانه» را انتخاب کنید"),
            done = { _, _, ev -> ev.currentPage == "attendance" },
            resultFa = { _, _ -> "فصل اول به پایان رسید! مبانی کارگاه، حضور، هزینه، واریزی و تقسیم سود را کامل یاد گرفتید." }
        ),

        // ====================================================================
        // CHAPTER 2 — 7 Steps (indices 15..21)
        // ====================================================================
        TutorialStep(
            index = 15,
            chapter = 2,
            stepInChapter = 1,
            id = "c2_add_master_factor",
            titleFa = "افزودن اوستا با ضریب کارکرد ۱٫۵",
            sayFa = "در فصل دوم سراغ امکانات حرفه‌ای می‌رویم. در «کاربران» یک اوستای جدید (مثلاً «اوستا حسن») با ضریب کارکرد ۱٫۵ اضافه کنید.",
            aim = AimTarget(page = "users", targetId = "crud_add_users", hintFa = "اوستا با ضریب ۱٫۵ اضافه کنید"),
            preset = TutorialPreset(
                fields = mapOf("name" to "اوستا حسن", "type" to "master", "role" to "اوستا ارشد", "workFactor" to "1.5"),
                labelFa = "اوستا حسن با ضریب ۱٫۵"
            ),
            done = { p, _, _ -> p.liveUsers().any { it.type == UserType.MASTER && it.workFactor != 1.0 } },
            resultFa = { _, _ -> "ضریب ۱٫۵ یعنی هر ۱ روز کار او در تقسیم سود معادل ۱٫۵ روز حساب می‌شود." }
        ),
        TutorialStep(
            index = 16,
            chapter = 2,
            stepInChapter = 2,
            id = "c2_overtime_factor",
            titleFa = "تنظیم ضریب اضافه‌کار پروژه",
            sayFa = "در بخش «تنظیمات و پشتیبان» ضریب اضافه‌کار را روی ۱٫۲۵× یا ۱٫۵× قرار دهید تا ساعت‌های بالای ۸ ساعت با ضریب بیشتر حساب شوند.",
            aim = AimTarget(page = "settings", targetId = "settings_overtime_chips", hintFa = "ضریب اضافه‌کار را بیشتر از ۱× کنید"),
            done = { p, _, _ -> p.settings.overtimeFactor > 1.0 },
            resultFa = { p, _ -> "ضریب اضافه‌کار روی ${TextNormalizer.fmtDays(p.settings.overtimeFactor)}× تنظیم شد." }
        ),
        TutorialStep(
            index = 17,
            chapter = 2,
            stepInChapter = 3,
            id = "c2_add_bonus",
            titleFa = "ثبت پاداش برای شاگرد",
            sayFa = "در بخش «پاداش، جریمه و مساعده» یک پاداش ۲۰۰٬۰۰۰ تومانی برای علی ثبت کنید.",
            aim = AimTarget(page = "adjustments", targetId = "crud_add_adjustments", hintFa = "پاداش ۲۰۰٬۰۰۰ تومانی ثبت کنید"),
            preset = TutorialPreset(
                fields = mapOf(
                    "userId" to PracticeSandboxSeeder.APPRENTICE_ALI_ID,
                    "kind" to "bonus",
                    "amount" to "200000",
                    "description" to "پاداش خوش‌قولی"
                ),
                labelFa = "پاداش ۲۰۰ هزار تومان"
            ),
            done = { p, _, _ -> p.adjustments.any { it.active && it.kind == "bonus" } },
            resultFa = { _, _ -> "پاداش ثبت شد و به دستمزد استحقاقی فرد اضافه گردید." }
        ),
        TutorialStep(
            index = 18,
            chapter = 2,
            stepInChapter = 4,
            id = "c2_add_assistance",
            titleFa = "ثبت مساعده (پول نقد فوری)",
            sayFa = "حالا یک «مساعده» ۳۰۰٬۰۰۰ تومانی برای علی ثبت کنید تا از طلب او کم شود.",
            aim = AimTarget(page = "adjustments", targetId = "crud_add_adjustments", hintFa = "مساعده ۳۰۰٬۰۰۰ تومانی ثبت کنید"),
            preset = TutorialPreset(
                fields = mapOf(
                    "userId" to PracticeSandboxSeeder.APPRENTICE_ALI_ID,
                    "kind" to "assistance",
                    "amount" to "300000",
                    "description" to "مساعده بین‌هفتگی"
                ),
                labelFa = "مساعده ۳۰۰ هزار تومان"
            ),
            done = { p, _, _ -> p.adjustments.any { it.active && it.kind == "assistance" } },
            resultFa = { _, _ -> "مساعده مثل پرداخت نقدی از طلب شاگرد کم می‌شود." }
        ),
        TutorialStep(
            index = 19,
            chapter = 2,
            stepInChapter = 5,
            id = "c2_add_advance_withdrawal",
            titleFa = "ثبت پیش‌برداشت اوستا از صندوق",
            sayFa = "در بخش «انتقال بین اوستاها» یک «پیش‌برداشت از کار (صندوق)» به مبلغ ۴٬۰۰۰٬۰۰۰ تومان برای اوستا کاظم ثبت کنید.",
            aim = AimTarget(page = "transfers", targetId = "crud_add_transfers", hintFa = "پیش‌برداشت ۴٬۰۰۰٬۰۰۰ تومانی ثبت کنید"),
            preset = TutorialPreset(
                fields = mapOf(
                    "kind" to "advance",
                    "toId" to PracticeSandboxSeeder.MASTER_PARTNER_ID,
                    "amount" to "4000000",
                    "description" to "پیش‌برداشت علی‌الحساب"
                ),
                labelFa = "پیش‌برداشت ۴ میلیون تومان"
            ),
            done = { p, _, _ -> p.transfers.any { it.active && it.kind == "advance" } },
            resultFa = { _, _ -> "پیش‌برداشت از تراز نهایی آن اوستا کسر شد؛ اگر بیش از سهمش بردارد تراز او منفی (بدهکار) می‌شود." }
        ),
        TutorialStep(
            index = 20,
            chapter = 2,
            stepInChapter = 6,
            id = "c2_add_peer_transfer",
            titleFa = "انتقال مستقیم بین دو اوستا",
            sayFa = "حالا یک انتقال داخلی («انتقال بین دو اوستا») به مبلغ ۵۰۰٬۰۰۰ تومان از اوستای اصلی به اوستا کاظم ثبت کنید.",
            aim = AimTarget(page = "transfers", targetId = "crud_add_transfers", hintFa = "انتقال ۵۰۰٬۰۰۰ تومان بین دو اوستا ثبت کنید"),
            preset = TutorialPreset(
                fields = mapOf(
                    "kind" to "peer",
                    "fromId" to PracticeSandboxSeeder.MASTER_ME_ID,
                    "toId" to PracticeSandboxSeeder.MASTER_PARTNER_ID,
                    "amount" to "500000",
                    "description" to "کارت‌به‌کارت داخلی"
                ),
                labelFa = "انتقال ۵۰۰ هزار تومان"
            ),
            done = { p, _, _ -> p.transfers.any { it.active && it.kind == "peer" } },
            resultFa = { _, _ -> "در انتقال داخلی به پرداخت‌کننده اضافه و از گیرنده کم می‌شود، بدون تغییر در سود کل کارگاه." }
        ),
        TutorialStep(
            index = 21,
            chapter = 2,
            stepInChapter = 7,
            id = "c2_negative_settle",
            titleFa = "تسویهٔ مانده منفی در داشبورد",
            sayFa = "به «داشبورد» بروید. اگر اوستایی تراز منفی دارد، در «ماتریس تسویه مانده‌های منفی» با یک لمس «پرداخت به صندوق» یا در بخش تعدیل‌ها یک «تسویه نقدی» ثبت کنید.",
            aim = AimTarget(page = "dashboard", targetId = "negative_matrix_settle", hintFa = "در داشبورد تسویه به صندوق را بزنید"),
            done = { p, _, ev ->
                ev.currentPage == "dashboard" && (p.adjustments.any { it.active && it.kind == "settle" } || p.transfers.size >= 2)
            },
            resultFa = { _, _ -> "فصل دوم تمام شد! ضرایب، اضافه‌کار، پاداش، مساعده، پیش‌برداشت و تسویه بین شرکا را مسلط شدید." }
        ),

        // ====================================================================
        // CHAPTER 3 — 6 Steps (indices 22..27)
        // ====================================================================
        TutorialStep(
            index = 22,
            chapter = 3,
            stepInChapter = 1,
            id = "c3_profit_basis",
            titleFa = "تغییر مبنای سود (نقدی و تعهدی)",
            sayFa = "در فصل سوم سراغ تسویه نهایی و امنیت داده می‌رویم. در «تنظیمات و پشتیبان» مبنای سود را بین «نقدی» و «تعهدی» تغییر دهید.",
            aim = AimTarget(page = "settings", targetId = "settings_profit_basis", hintFa = "مبنای سود را تغییر دهید"),
            done = { p, _, _ -> p.settings.profitBasis == "cash" },
            resultFa = { _, _ -> "در مبنای نقدی فقط پرداختی‌های واقعی کم می‌شود؛ در مبنای تعهدی کل دستمزد کارکردهٔ شاگردان کسر می‌گردد." }
        ),
        TutorialStep(
            index = 23,
            chapter = 3,
            stepInChapter = 2,
            id = "c3_health_check",
            titleFa = "سنجش سلامت داده با ۹ قاعده",
            sayFa = "پیش از بستن حساب، به صفحهٔ «سنجش سلامت داده» بروید تا ۹ قاعدهٔ کنترلی حسابداری بررسی شود.",
            aim = AimTarget(page = "health", targetId = "nav_health", hintFa = "صفحهٔ «سنجش سلامت داده» را باز کنید"),
            done = { _, _, ev -> ev.currentPage == "health" || ev.visitedHealthPage },
            resultFa = { _, _ -> "تمام ۹ قاعدهٔ سلامت داده بررسی شد؛ هر خطا یا هشداری با یک لمس شما را به محل اصلاح می‌برد." }
        ),
        TutorialStep(
            index = 24,
            chapter = 3,
            stepInChapter = 3,
            id = "c3_export_report",
            titleFa = "گرفتن خروجی گزارش یا پشتیبان",
            sayFa = "در بخش «گزارش‌ها و خروجی» یکی از خروجی‌ها (PDF، اکسل CSV یا پشتیبان JSON) را امتحان کنید.",
            aim = AimTarget(page = "reports", targetId = "reports_export_pdf", hintFa = "یکی از کارت‌های خروجی در «گزارش‌ها» را بزنید"),
            done = { _, _, ev -> ev.exportedReportOrBackup || ev.currentPage == "reports" },
            resultFa = { _, _ -> "خروجی‌های استایار کاملاً برداری و خوانا هستند و آمادهٔ اشتراک‌گذاری با شرکا و کارفرما." }
        ),
        TutorialStep(
            index = 25,
            chapter = 3,
            stepInChapter = 4,
            id = "c3_enable_lock",
            titleFa = "فعال کردن قفل دوره مالی",
            sayFa = "پس از تسویه حساب، در «تنظیمات و پشتیبان» کلید «قفل دوره مالی» را روشن کنید تا هیچ رکوردی سهواً تغییر نکند.",
            aim = AimTarget(page = "settings", targetId = "settings_period_lock", hintFa = "قفل دوره مالی را فعال کنید"),
            done = { p, _, _ -> p.settings.locked },
            resultFa = { _, _ -> "قفل ۳ لایهٔ دوره مالی فعال شد! تمام صفحات اکنون در برابر تغییر یا حذف محافظت می‌شوند." }
        ),
        TutorialStep(
            index = 26,
            chapter = 3,
            stepInChapter = 5,
            id = "c3_test_locked_guard",
            titleFa = "آزمایش محافظت قفل مالی",
            sayFa = "حالا که قفل فعال است، در یکی از صفحات (مثلاً حضور و غیاب یا هزینه‌ها) سعی کنید چیزی ثبت یا تغییر دهید تا سپر محافظتی را ببینید.",
            aim = AimTarget(page = "attendance", targetId = "att_btn_full_u_master_me", hintFa = "یک تغییر آزمایشی در حالت قفل انجام دهید"),
            done = { p, _, ev -> ev.attemptedLockedEdit || !p.settings.locked },
            resultFa = { _, _ -> "دیدید که قفل دوره مالی مانع از هرگونه تغییر ناخواسته در دورهٔ تسویه‌شده می‌شود." }
        ),
        TutorialStep(
            index = 27,
            chapter = 3,
            stepInChapter = 6,
            id = "c3_unlock_and_graduate",
            titleFa = "باز کردن قفل و پایان دورهٔ آموزشی",
            sayFa = "در نهایت روی آیکون قفل در نوار بالا (یا در تنظیمات) بزنید و قفل مالی را باز کنید تا مدرک پایان دورهٔ استایار صادر شود!",
            aim = AimTarget(page = "settings", targetId = "topbar_lock_btn", hintFa = "قفل دوره مالی را باز کنید"),
            done = { p, _, _ -> !p.settings.locked },
            resultFa = { _, _ -> "تبریک! هر ۲۸ گام کارگاه تمرینی استایار را با موفقیت به پایان رساندید." }
        )
    )
}
