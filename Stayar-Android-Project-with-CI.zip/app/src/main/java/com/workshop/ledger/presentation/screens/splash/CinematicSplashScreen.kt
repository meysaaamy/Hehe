package com.workshop.ledger.presentation.screens.splash

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.workshop.ledger.core.audio.NativePcmSynthesizer
import com.workshop.ledger.presentation.theme.StayarTheme

/**
 * 4.0-second 120 FPS Native Vector Cinematic Splash assembling the Persian arch with
 * turquoise tiles, mason's trowel, wooden abacus, rising green bar chart, and sand-gold
 * «استایار» lettering with a diagonal golden light sweep and «رد کردن ◂» skip button.
 */
@Composable
fun CinematicSplashScreen(
    synthesizer: NativePcmSynthesizer?,
    onFinished: () -> Unit
) {
    val colors = StayarTheme.colors
    val progress = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        synthesizer?.playSplashAudio()
        progress.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 4000, easing = LinearEasing)
        )
        onFinished()
    }

    val p = progress.value

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0A0A0F))
            .statusBarsPadding()
    ) {
        // Skip button «رد کردن ◂»
        OutlinedButton(
            onClick = onFinished,
            border = BorderStroke(1.dp, Color(0xFFD4A574)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(16.dp)
        ) {
            Text(
                text = "رد کردن ◂",
                color = Color(0xFFD4A574),
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
            )
        }

        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Canvas(modifier = Modifier.size(260.dp)) {
                val w = size.width
                val h = size.height
                val gold = Color(0xFFD4A574)
                val turquoise = Color(0xFF2A9D9D)
                val green = Color(0xFF2F8F5B)
                val terracotta = Color(0xFFB45A3C)

                // Stage 1 (0.0..0.35): Persian Arch + Turquoise Tiles
                val archProg = (p / 0.35f).coerceIn(0f, 1f)
                if (archProg > 0f) {
                    val archPath = Path().apply {
                        moveTo(w * 0.18f, h * 0.85f)
                        lineTo(w * 0.18f, h * 0.42f)
                        quadraticBezierTo(w * 0.18f, h * 0.14f, w * 0.50f, h * 0.08f)
                        quadraticBezierTo(w * 0.82f, h * 0.14f, w * 0.82f, h * 0.42f)
                        lineTo(w * 0.82f, h * 0.85f)
                    }
                    drawPath(
                        path = archPath,
                        color = turquoise.copy(alpha = archProg),
                        style = Stroke(width = 6.dp.toPx(), cap = StrokeCap.Round)
                    )
                    // Inner Gold Arch
                    drawRoundRect(
                        color = gold.copy(alpha = archProg * 0.8f),
                        topLeft = Offset(w * 0.23f, h * 0.22f),
                        size = Size(w * 0.54f, h * 0.60f),
                        cornerRadius = CornerRadius(w * 0.18f),
                        style = Stroke(width = 2.5.dp.toPx())
                    )
                }

                // Stage 2 (0.25..0.60): Wooden Abacus & Mason's Trowel
                val toolProg = ((p - 0.25f) / 0.35f).coerceIn(0f, 1f)
                if (toolProg > 0f) {
                    // Abacus beads
                    for (row in 0..2) {
                        val y = h * (0.36f + row * 0.08f)
                        drawLine(
                            color = gold.copy(alpha = toolProg * 0.6f),
                            start = Offset(w * 0.28f, y),
                            end = Offset(w * 0.72f, y),
                            strokeWidth = 2.dp.toPx()
                        )
                        for (b in 0..3) {
                            val bx = w * (0.33f + b * 0.09f + toolProg * 0.04f)
                            drawCircle(
                                color = terracotta.copy(alpha = toolProg),
                                radius = 5.dp.toPx(),
                                center = Offset(bx, y)
                            )
                        }
                    }

                    // Mason's Trowel diamond silhouette
                    val trowel = Path().apply {
                        moveTo(w * 0.50f, h * 0.22f)
                        lineTo(w * 0.60f, h * 0.31f)
                        lineTo(w * 0.50f, h * 0.36f)
                        lineTo(w * 0.40f, h * 0.31f)
                        close()
                    }
                    drawPath(trowel, color = gold.copy(alpha = toolProg))
                }

                // Stage 3 (0.50..0.85): Rising Green Bar Chart
                val chartProg = ((p - 0.50f) / 0.35f).coerceIn(0f, 1f)
                if (chartProg > 0f) {
                    val barHeights = listOf(0.14f, 0.22f, 0.30f, 0.38f)
                    barHeights.forEachIndexed { idx, bh ->
                        val curH = h * bh * chartProg
                        val bx = w * (0.30f + idx * 0.11f)
                        drawRoundRect(
                            color = green,
                            topLeft = Offset(bx, h * 0.80f - curH),
                            size = Size(w * 0.07f, curH),
                            cornerRadius = CornerRadius(4.dp.toPx())
                        )
                    }
                }

                // Stage 4 (0.70..1.0): Diagonal Golden Light Sweep
                val sweepProg = ((p - 0.70f) / 0.30f).coerceIn(0f, 1f)
                if (sweepProg > 0f) {
                    val sweepX = w * (-0.3f + sweepProg * 1.6f)
                    drawRect(
                        brush = Brush.linearGradient(
                            colors = listOf(
                                Color.Transparent,
                                gold.copy(alpha = 0.35f),
                                Color.Transparent
                            ),
                            start = Offset(sweepX - 60f, 0f),
                            end = Offset(sweepX + 60f, h)
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "استایار",
                fontSize = 32.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color(0xFFD4A574)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "دفتر حساب کارگاه ساختمانی",
                fontSize = 15.sp,
                color = Color(0xFFE8E8F0).copy(alpha = 0.85f)
            )
        }
    }
}
