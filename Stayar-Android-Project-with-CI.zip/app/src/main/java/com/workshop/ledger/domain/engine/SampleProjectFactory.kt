package com.workshop.ledger.domain.engine

import com.workshop.ledger.domain.model.Adjustment
import com.workshop.ledger.domain.model.AttendanceValue
import com.workshop.ledger.domain.model.Category
import com.workshop.ledger.domain.model.DomainConstants
import com.workshop.ledger.domain.model.Expense
import com.workshop.ledger.domain.model.Payout
import com.workshop.ledger.domain.model.Project
import com.workshop.ledger.domain.model.ProjectSettings
import com.workshop.ledger.domain.model.Receipt
import com.workshop.ledger.domain.model.Transfer
import com.workshop.ledger.domain.model.User
import com.workshop.ledger.domain.model.UserType
import com.workshop.ledger.domain.model.Wage

object SampleProjectFactory {

    fun createEmptyProject(
        name: String = "پروژه اول",
        masterName: String = "اوستای اصلی"
    ): Project {
        val now = System.currentTimeMillis()
        val categories = DomainConstants.DEFAULT_CATEGORIES.mapIndexed { idx, title ->
            Category(id = "cat_${idx + 1}_${DomainConstants.uid()}", name = title)
        }
        val mainMaster = User(
            id = "u_main_${DomainConstants.uid()}",
            name = masterName,
            role = "اوستا",
            type = UserType.MASTER,
            workFactor = 1.0,
            active = true,
            main = true,
            createdAt = now
        )
        return Project(
            id = "proj_${DomainConstants.uid()}",
            name = name.ifBlank { "پروژه جدید" },
            createdAt = now,
            settings = ProjectSettings(calcVersion = 2),
            users = listOf(mainMaster),
            categories = categories
        )
    }

    /**
     * Creates sample project «نمونه: ساختمان سه‌طبقه گلستان» with LCG seed 7 attendance,
     * masters «اوستا رضا» (main, factor 1.0) and «اوستا محمد» (factor 0.8),
     * apprentices «علی رضایی» and «حسین کریمی», custom worker «کارگر ساده» (role «کارگر»),
     * receipts (32,000,000 and 24,000,000), 6 expenses, 3 payouts, 1 peer transfer, and 3 adjustments.
     */
    fun createSampleProject(todayStr: String = JalaliCalendarEngine.jTodayStr()): Project {
        val now = System.currentTimeMillis()
        val pid = "proj_sample_${DomainConstants.uid()}"

        val cat1 = Category("cat_mat", "مصالح ساختمانی")
        val cat2 = Category("cat_trn", "حمل‌ونقل")
        val cat3 = Category("cat_tls", "ابزار و تجهیزات")
        val cat4 = Category("cat_fod", "غذا و پذیرایی")
        val cat5 = Category("cat_msc", "متفرقه")
        val categories = listOf(cat1, cat2, cat3, cat4, cat5)

        val m1 = User(
            id = "u_m1",
            name = "اوستا رضا",
            role = "اوستاکار اصلی",
            type = UserType.MASTER,
            workFactor = 1.0,
            active = true,
            main = true,
            createdAt = now - 50_000L
        )
        val m2 = User(
            id = "u_m2",
            name = "اوستا محمد",
            role = "شریک کارگاه",
            type = UserType.MASTER,
            workFactor = 0.8,
            active = true,
            main = false,
            createdAt = now - 40_000L
        )
        val a1 = User(
            id = "u_a1",
            name = "علی رضایی",
            role = "شاگرد نیمه‌ماهر",
            type = UserType.APPRENTICE,
            workFactor = 1.0,
            active = true,
            main = false,
            createdAt = now - 30_000L
        )
        val a2 = User(
            id = "u_a2",
            name = "حسین کریمی",
            role = "شاگرد",
            type = UserType.APPRENTICE,
            workFactor = 1.0,
            active = true,
            main = false,
            createdAt = now - 20_000L
        )
        val c1 = User(
            id = "u_c1",
            name = "کارگر ساده",
            role = "کارگر",
            type = UserType.CUSTOM,
            workFactor = 1.0,
            active = true,
            main = false,
            createdAt = now - 10_000L
        )
        val users = listOf(m1, m2, a1, a2, c1)

        val startDay = JalaliCalendarEngine.jAddDays(todayStr, -13)
        val midDay = JalaliCalendarEngine.jAddDays(todayStr, -6)

        val wages = listOf(
            Wage(id = "w_a1_1", userId = a1.id, rate = 1_200_000L, effectiveDate = startDay),
            Wage(id = "w_a1_2", userId = a1.id, rate = 1_350_000L, effectiveDate = midDay),
            Wage(id = "w_a2_1", userId = a2.id, rate = 1_000_000L, effectiveDate = startDay),
            Wage(id = "w_c1_1", userId = c1.id, rate = 900_000L, effectiveDate = startDay)
        )

        // Deterministic LCG seed 7 attendance across 14 days
        var seed = 7L
        fun nextRand(): Double {
            seed = (seed * 1664525L + 1013904223L) and 0xFFFFFFFFL
            return seed.toDouble() / 4294967296.0
        }

        val attendance = LinkedHashMap<String, Map<String, AttendanceValue>>()
        for (offset in -13..0) {
            val d = JalaliCalendarEngine.jAddDays(todayStr, offset)
            if (JalaliCalendarEngine.jDowIndex(d) == 5) continue // skip Friday
            val dayMap = LinkedHashMap<String, AttendanceValue>()
            for (u in users) {
                val r = nextRand()
                val v: AttendanceValue = when {
                    r < 0.68 -> AttendanceValue.Full
                    r < 0.82 -> AttendanceValue.Half
                    r < 0.93 -> AttendanceValue.Hourly(if (r < 0.88) 9.0 else 10.0)
                    else -> AttendanceValue.Absent
                }
                dayMap[u.id] = v
            }
            attendance[d] = dayMap
        }

        val receipts = listOf(
            Receipt(
                id = "rec_1",
                dateFrom = startDay,
                dateTo = JalaliCalendarEngine.jAddDays(todayStr, -7),
                amount = 32_000_000L,
                description = "قسط اول کارفرما (شروع کار)",
                active = true,
                createdAt = now
            ),
            Receipt(
                id = "rec_2",
                dateFrom = midDay,
                dateTo = todayStr,
                amount = 24_000_000L,
                description = "قسط دوم کارفرما (پیشرفت طبقه دوم)",
                active = true,
                createdAt = now
            )
        )

        val expenses = listOf(
            Expense(
                id = "exp_1",
                date = JalaliCalendarEngine.jAddDays(todayStr, -12),
                amount = 4_200_000L,
                description = "خرید سیمان و گچ",
                categoryId = cat1.id,
                payerId = "shared",
                active = true,
                createdAt = now
            ),
            Expense(
                id = "exp_2",
                date = JalaliCalendarEngine.jAddDays(todayStr, -10),
                amount = 1_150_000L,
                description = "کرایه نیسان حمل مصالح",
                categoryId = cat2.id,
                payerId = "shared",
                active = true,
                createdAt = now
            ),
            Expense(
                id = "exp_3",
                date = JalaliCalendarEngine.jAddDays(todayStr, -8),
                amount = 1_850_000L,
                description = "خرید صفحه فرز، تراز و ماله",
                categoryId = cat3.id,
                payerId = m1.id,
                active = true,
                createdAt = now
            ),
            Expense(
                id = "exp_4",
                date = JalaliCalendarEngine.jAddDays(todayStr, -6),
                amount = 980_000L,
                description = "صبحانه و ناهار کارگاه",
                categoryId = cat4.id,
                payerId = m2.id,
                active = true,
                createdAt = now
            ),
            Expense(
                id = "exp_5",
                date = JalaliCalendarEngine.jAddDays(todayStr, -3),
                amount = 2_400_000L,
                description = "اجاره داربست و بالابر",
                categoryId = cat3.id,
                payerId = "shared",
                active = true,
                createdAt = now
            ),
            Expense(
                id = "exp_6",
                date = JalaliCalendarEngine.jAddDays(todayStr, -1),
                amount = 620_000L,
                description = "چای، قند و ملزومات متفرقه",
                categoryId = cat5.id,
                payerId = "shared",
                active = true,
                createdAt = now
            )
        )

        val payouts = listOf(
            Payout(
                id = "pay_1",
                date = JalaliCalendarEngine.jAddDays(todayStr, -7),
                userId = a1.id,
                amount = 5_000_000L,
                description = "علی‌الحساب هفته اول",
                active = true,
                createdAt = now
            ),
            Payout(
                id = "pay_2",
                date = JalaliCalendarEngine.jAddDays(todayStr, -5),
                userId = a2.id,
                amount = 4_000_000L,
                description = "پرداخت نقدی هفتگی",
                active = true,
                createdAt = now
            ),
            Payout(
                id = "pay_3",
                date = JalaliCalendarEngine.jAddDays(todayStr, -2),
                userId = c1.id,
                amount = 3_500_000L,
                description = "تسویه کارگر ساده",
                active = true,
                createdAt = now
            )
        )

        val transfers = listOf(
            Transfer(
                id = "tr_1",
                date = JalaliCalendarEngine.jAddDays(todayStr, -4),
                kind = "peer",
                fromId = m1.id,
                toId = m2.id,
                amount = 1_500_000L,
                description = "کارت‌به‌کارت داخلی",
                active = true,
                createdAt = now
            )
        )

        val adjustments = listOf(
            Adjustment(
                id = "adj_1",
                date = JalaliCalendarEngine.jAddDays(todayStr, -9),
                userId = a1.id,
                kind = "bonus",
                amount = 300_000L,
                description = "پاداش خوش‌قولی",
                active = true,
                createdAt = now
            ),
            Adjustment(
                id = "adj_2",
                date = JalaliCalendarEngine.jAddDays(todayStr, -4),
                userId = a2.id,
                kind = "assistance",
                amount = 500_000L,
                description = "مساعده نقدی",
                active = true,
                createdAt = now
            ),
            Adjustment(
                id = "adj_3",
                date = JalaliCalendarEngine.jAddDays(todayStr, -2),
                userId = c1.id,
                kind = "penalty",
                amount = 100_000L,
                description = "خسارت شکستن ابزار",
                active = true,
                createdAt = now
            )
        )

        return Project(
            id = pid,
            name = "نمونه: ساختمان سه‌طبقه گلستان",
            createdAt = now,
            settings = ProjectSettings(
                rangeFrom = startDay,
                rangeTo = todayStr,
                overtimeFactor = 1.25,
                absentPenalty = 0.5,
                profitBasis = "cash",
                locked = false,
                calcVersion = 2
            ),
            users = users,
            wages = wages,
            attendance = attendance,
            expenses = expenses,
            receipts = receipts,
            payouts = payouts,
            transfers = transfers,
            adjustments = adjustments,
            categories = categories
        )
    }
}
