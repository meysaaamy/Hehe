package com.workshop.ledger.presentation.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.workshop.ledger.core.audio.NativePcmSynthesizer
import com.workshop.ledger.core.haptics.RichHapticsManager
import com.workshop.ledger.domain.engine.JalaliCalendarEngine
import com.workshop.ledger.domain.engine.TextNormalizer
import com.workshop.ledger.domain.model.JalaliDate
import com.workshop.ledger.presentation.theme.StayarTheme
import kotlin.math.abs

/**
 * 3D Barrel Wheel Jalali Date Picker with CLOCK_TICK haptics and rising audio pitch.
 */
@Composable
fun JalaliWheelDatePickerSheet(
    initialDateStr: String,
    onDateSelected: (String) -> Unit,
    onDismiss: () -> Unit,
    synthesizer: NativePcmSynthesizer? = null,
    haptics: RichHapticsManager? = null
) {
    val today = remember { JalaliCalendarEngine.jTodayDate() }
    val parsed = remember(initialDateStr) {
        JalaliCalendarEngine.jParse(initialDateStr) ?: today
    }

    var selectedYear by remember { mutableIntStateOf(parsed.year.coerceIn(1380, 1450)) }
    var selectedMonth by remember { mutableIntStateOf(parsed.month.coerceIn(1, 12)) }
    val maxDayInMonth = JalaliCalendarEngine.jalaaliMonthLength(selectedYear, selectedMonth)
    var selectedDay by remember { mutableIntStateOf(parsed.day.coerceIn(1, maxDayInMonth)) }

    if (selectedDay > maxDayInMonth) {
        selectedDay = maxDayInMonth
    }

    val currentFormatted = JalaliDate.of(selectedYear, selectedMonth, selectedDay).toFormattedString()
    val digitsMode = StayarTheme.digitsMode
    val colors = StayarTheme.colors
    val view = LocalView.current

    val onDetent: (Int) -> Unit = { idx ->
        haptics?.clockTick(view)
        synthesizer?.wheelDetent(idx)
    }

    TactileSheet(
        titleFa = "انتخاب تاریخ شمسی",
        onDismissRequest = onDismiss
    ) {
        Surface(
            color = colors.bgElev2,
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(colors.defaultBorderWidth, colors.borderStrong),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "${JalaliCalendarEngine.jDowStr(currentFormatted)} — ${JalaliCalendarEngine.jHuman(currentFormatted, digitsMode)}",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.accent
                )
                Text(
                    text = TextNormalizer.formatDisplayDigits(currentFormatted, digitsMode),
                    fontSize = 13.sp,
                    color = colors.textDim
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        val years = remember { (1380..1450).toList() }
        val months = remember { (1..12).toList() }
        val days = remember(maxDayInMonth) { (1..maxDayInMonth).toList() }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Day Barrel
            BarrelWheelColumn(
                titleFa = "روز",
                items = days,
                selectedItem = selectedDay,
                labelProvider = { TextNormalizer.formatDisplayDigits(it.toString(), digitsMode) },
                onItemSelected = {
                    selectedDay = it
                    onDetent(it)
                },
                modifier = Modifier.weight(1f)
            )

            // Month Barrel
            BarrelWheelColumn(
                titleFa = "ماه",
                items = months,
                selectedItem = selectedMonth,
                labelProvider = { m -> JalaliCalendarEngine.MONTHS_FA[m - 1] },
                onItemSelected = {
                    selectedMonth = it
                    onDetent(it * 2)
                },
                modifier = Modifier.weight(1.3f)
            )

            // Year Barrel
            BarrelWheelColumn(
                titleFa = "سال",
                items = years,
                selectedItem = selectedYear,
                labelProvider = { TextNormalizer.formatDisplayDigits(it.toString(), digitsMode) },
                onItemSelected = {
                    selectedYear = it
                    onDetent(it - 1380)
                },
                modifier = Modifier.weight(1.1f)
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            OutlinedButton(
                onClick = {
                    selectedYear = today.year
                    selectedMonth = today.month
                    selectedDay = today.day
                    onDetent(10)
                },
                border = BorderStroke(colors.defaultBorderWidth, colors.borderStrong),
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
            ) {
                Text("امروز", color = colors.text, fontWeight = FontWeight.SemiBold)
            }
            Button(
                onClick = {
                    onDateSelected(currentFormatted)
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = colors.accent),
                modifier = Modifier
                    .weight(1.5f)
                    .height(48.dp)
            ) {
                Text("انتخاب تاریخ", color = colors.onAccent, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun <T> BarrelWheelColumn(
    titleFa: String,
    items: List<T>,
    selectedItem: T,
    labelProvider: (T) -> String,
    onItemSelected: (T) -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = StayarTheme.colors
    val selectedIndex = items.indexOf(selectedItem).coerceAtLeast(0)
    val listState = rememberLazyListState(initialFirstVisibleItemIndex = (selectedIndex - 1).coerceAtLeast(0))

    LaunchedEffect(selectedIndex) {
        val target = (selectedIndex - 1).coerceAtLeast(0)
        listState.animateScrollToItem(target)
    }

    val centerIndex by remember {
        derivedStateOf { listState.firstVisibleItemIndex + 1 }
    }

    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(titleFa, fontSize = 12.sp, color = colors.textDim, fontWeight = FontWeight.SemiBold)
        Spacer(modifier = Modifier.height(4.dp))
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = colors.bgElev2,
            border = BorderStroke(colors.defaultBorderWidth, colors.borderStrong),
            modifier = Modifier
                .fillMaxWidth()
                .height(156.dp)
        ) {
            LazyColumn(
                state = listState,
                contentPadding = PaddingValues(vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                itemsIndexed(items) { idx, item ->
                    val isSelected = item == selectedItem
                    val dist = abs(idx - centerIndex)
                    val rotX = ((idx - centerIndex) * 18f).coerceIn(-45f, 45f)
                    val alpha = (1f - dist * 0.25f).coerceIn(0.35f, 1f)

                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .graphicsLayer {
                                rotationX = rotX
                                this.alpha = alpha
                            }
                            .clickable { onItemSelected(item) }
                    ) {
                        Surface(
                            color = if (isSelected) colors.accent else androidx.compose.ui.graphics.Color.Transparent,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = labelProvider(item),
                                fontSize = if (isSelected) 15.sp else 13.5.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) colors.onAccent else colors.text,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(vertical = 6.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
