package com.workshop.ledger

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.workshop.ledger.data.local.backup.BackupSlotInfo
import com.workshop.ledger.data.local.backup.ImportValidationPreview
import com.workshop.ledger.data.local.datastore.AppPreferences
import com.workshop.ledger.data.local.datastore.NotifVerbosity
import com.workshop.ledger.data.local.datastore.ThemeMode
import com.workshop.ledger.data.local.db.ProjectEntity
import com.workshop.ledger.domain.engine.AccountingEngine
import com.workshop.ledger.domain.engine.JalaliCalendarEngine
import com.workshop.ledger.domain.engine.TextNormalizer
import com.workshop.ledger.domain.model.AccountingResult
import com.workshop.ledger.domain.model.Adjustment
import com.workshop.ledger.domain.model.AttendanceValue
import com.workshop.ledger.domain.model.Category
import com.workshop.ledger.domain.model.Expense
import com.workshop.ledger.domain.model.Payout
import com.workshop.ledger.domain.model.Project
import com.workshop.ledger.domain.model.ProjectSettings
import com.workshop.ledger.domain.model.Receipt
import com.workshop.ledger.domain.model.Transfer
import com.workshop.ledger.domain.model.User
import com.workshop.ledger.domain.model.Wage
import com.workshop.ledger.domain.tutorial.TutorialChapters
import com.workshop.ledger.presentation.components.AppChrome
import com.workshop.ledger.presentation.components.SpeedDialAction
import com.workshop.ledger.presentation.components.TactileSheet
import com.workshop.ledger.presentation.components.ToastHost
import com.workshop.ledger.presentation.components.ToastMessage
import com.workshop.ledger.presentation.screens.attendance.AttendanceScreen
import com.workshop.ledger.presentation.screens.crud.CrudPageConfig
import com.workshop.ledger.presentation.screens.crud.GenericCrudScreen
import com.workshop.ledger.presentation.screens.dashboard.DashboardScreen
import com.workshop.ledger.presentation.screens.dashboard.ProfitRulerSheet
import com.workshop.ledger.presentation.screens.guide.GuideScreen
import com.workshop.ledger.presentation.screens.health.HealthScreen
import com.workshop.ledger.presentation.screens.projects.ProjectsScreen
import com.workshop.ledger.presentation.screens.reports.ReportsScreen
import com.workshop.ledger.presentation.screens.settings.SettingsScreen
import com.workshop.ledger.presentation.screens.splash.CinematicSplashScreen
import com.workshop.ledger.presentation.theme.StayarTheme
import com.workshop.ledger.presentation.tutorial.GraduationSheet
import com.workshop.ledger.presentation.tutorial.PracticeChooserSheet
import com.workshop.ledger.presentation.tutorial.QuestBeaconOverlay
import com.workshop.ledger.presentation.tutorial.QuestCoordinator
import com.workshop.ledger.presentation.tutorial.QuestDock
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File

/**
 * Single-Activity Host for «استایار» (Stayar).
 * Features:
 * - Pure Native Android (100% Kotlin 2.1+, Zero WebView)
 * - Edge-to-Edge & SplashScreen
 * - Ambient Light Sensor (> 20,000 lux activates Sunlight High-Contrast theme)
 * - 30s Rolling Auto-Backup ticker
 * - 14 Screens via AppChrome navigation
 * - 28-Step Interactive Tutorial Quest Engine
 */
class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val app = application as StayarApp

        setContent {
            StayarMainContent(app = app)
        }
    }
}

@Composable
private fun StayarMainContent(app: StayarApp) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val prefs by app.preferencesRepository.preferencesFlow.collectAsState(initial = AppPreferences())
    val allProjects by app.ledgerRepository.allProjectsSummaryFlow.collectAsState(initial = emptyList())
    val activeProject by app.ledgerRepository.activeProjectFlow.collectAsState(initial = null)
    val accountingResult by app.ledgerRepository.accountingResultFlow.collectAsState(initial = null)
    val isSaveBlocked by app.ledgerRepository.saveBlocked.collectAsState(initial = false)
    val loadError by app.ledgerRepository.loadError.collectAsState(initial = null)

    var currentPageId by remember { mutableStateOf("dashboard") }
    var showCinematicSplash by remember { mutableStateOf(prefs.splashEnabled) }
    var toasts by remember { mutableStateOf<List<ToastMessage>>(emptyList()) }
    var showProfitRuler by remember { mutableStateOf(false) }

    // Ambient light sensor for high-contrast sunlight mode (> 20,000 lux)
    var isAmbientSunlight by remember { mutableStateOf(false) }
    DisposableEffect(context) {
        val sm = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
        val sensor = sm?.getDefaultSensor(Sensor.TYPE_LIGHT)
        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent?) {
                val lux = event?.values?.firstOrNull() ?: 0f
                isAmbientSunlight = lux > 20_000f
            }
            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
        }
        if (sensor != null) {
            sm.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_NORMAL)
        }
        onDispose {
            sm?.unregisterListener(listener)
        }
    }

    val effectiveThemeMode = if (isAmbientSunlight) ThemeMode.SUNLIGHT else prefs.themeMode

    // Sync audio & haptics settings
    LaunchedEffect(prefs.soundEnabled, prefs.volume, prefs.hapticsEnabled) {
        app.pcmSynthesizer.soundEnabled = prefs.soundEnabled
        app.pcmSynthesizer.volumePercent = prefs.volume
        app.hapticsManager.hapticsEnabled = prefs.hapticsEnabled
    }

    // Initialize database on first launch
    LaunchedEffect(Unit) {
        app.ledgerRepository.initializeFirstLaunchIfNeeded()
    }

    // 30-Second Rolling Auto-Backup Ticker
    LaunchedEffect(allProjects, prefs.activeProjectId, prefs.autoBackupIntervalMin) {
        while (true) {
            delay(30_000L)
            val intervalMin = prefs.autoBackupIntervalMin
            if (intervalMin > 0 && allProjects.isNotEmpty()) {
                val now = System.currentTimeMillis()
                if (now - prefs.lastAutoBackupMs >= intervalMin * 60_000L) {
                    val state = app.ledgerRepository.buildCurrentAppStateSnapshot()
                    val written = app.backupManager.writeRollingAutoBackup(state)
                    if (written) {
                        app.preferencesRepository.recordAutoBackupTimestamp(now)
                    }
                }
            }
        }
    }

    // Toast helper with verbosity filter, audio chime & haptic feedback
    fun showToast(
        text: String,
        isDanger: Boolean = false,
        durationMs: Long = 3500L,
        actionLabel: String? = null,
        onAction: (() -> Unit)? = null
    ) {
        val verbosity = prefs.notifVerbosity
        if (verbosity == NotifVerbosity.MIN && !isDanger) return
        if (verbosity == NotifVerbosity.LESS && text == "ذخیره شد") return

        val msg = ToastMessage(
            text = text,
            isDanger = isDanger,
            durationMs = durationMs,
            actionLabel = actionLabel,
            onAction = onAction
        )
        toasts = toasts + msg

        if (isDanger) {
            app.pcmSynthesizer.chime(ok = false)
            app.hapticsManager.errorOrLock()
        } else {
            app.pcmSynthesizer.chime(ok = true)
            app.hapticsManager.tap()
        }
    }

    fun dismissToast(id: Long) {
        toasts = toasts.filter { it.id != id }
    }

    // Quest Coordinator instance for 28-step tutorial
    val questCoordinator = remember { QuestCoordinator() }

    LaunchedEffect(currentPageId) {
        questCoordinator.onPageChanged(currentPageId)
    }

    // Watch period lock attempts for tutorial step 3.6
    LaunchedEffect(Unit) {
        app.ledgerRepository.lockedAttemptEvents.collect {
            questCoordinator.onLockedPeriodAttempt()
        }
    }

    // Evaluate tutorial step completion reactively
    val currentOnboarding = prefs.onboarding
    val isTutorialActive = currentOnboarding.status == "in_quest"
    val currentStep = if (isTutorialActive) TutorialChapters.ALL_28_STEPS.getOrNull(currentOnboarding.questStep) else null

    LaunchedEffect(activeProject, accountingResult, questCoordinator.runtimeEvents, currentStep?.index) {
        if (isTutorialActive && currentStep != null && activeProject != null && accountingResult != null) {
            val isDone = currentStep.done(activeProject!!, questCoordinator.runtimeEvents)
            if (isDone && questCoordinator.stepDoneBanner == null) {
                app.pcmSynthesizer.chime(ok = true)
                app.hapticsManager.confirm(20L)
                questCoordinator.stepDoneBanner = currentStep.result(accountingResult!!)
            }
        }
    }

    // SAF Launchers for Import & Export
    var pendingExportBytes by remember { mutableStateOf<ByteArray?>(null) }
    var pendingExportMime by remember { mutableStateOf("application/json") }
    var pendingExportSuggestedName by remember { mutableStateOf("stayar-backup.json") }

    val createDocLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri: Uri? ->
        val bytes = pendingExportBytes
        if (uri != null && bytes != null) {
            scope.launch {
                val ok = app.fileDeliveryManager.writeBytesToSafUri(uri, bytes)
                if (ok) {
                    app.preferencesRepository.recordExternalExportTimestamp(System.currentTimeMillis())
                    showToast("فایل پشتیبان با موفقیت ذخیره شد")
                } else {
                    showToast("خطا در ذخیره فایل پشتیبان", isDanger = true)
                }
            }
        }
        pendingExportBytes = null
    }

    var importPreviewDialog by remember { mutableStateOf<ImportValidationPreview?>(null) }

    val openDocLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                try {
                    context.contentResolver.openInputStream(uri)?.use { stream ->
                        val preview = app.backupManager.validateImportStream(stream)
                        importPreviewDialog = preview
                    }
                } catch (e: Exception) {
                    showToast("خطا در خواندن فایل: ${e.message}", isDanger = true)
                }
            }
        }
    }

    // Generic CRUD form trigger state (e.g. from speed dial or wage redirect)
    var crudInitialFormOpen by remember { mutableStateOf(false) }
    var crudPreselectedUserId by remember { mutableStateOf<String?>(null) }

    StayarTheme(
        themeMode = effectiveThemeMode,
        digitsMode = prefs.digitsMode
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(StayarTheme.colors.bg)
        ) {
            if (showCinematicSplash) {
                CinematicSplashScreen(
                    synthesizer = app.pcmSynthesizer,
                    onFinished = { showCinematicSplash = false }
                )
            } else {
                val currentProject = activeProject
                val r = accountingResult ?: currentProject?.let { AccountingEngine.compute(it) } ?: AccountingEngine.compute(
                    Project(id = "dummy")
                )

                AppChrome(
                    currentPageId = currentPageId,
                    onNavigate = { page ->
                        currentPageId = page
                        crudInitialFormOpen = false
                        crudPreselectedUserId = null
                    },
                    activeProjectName = currentProject?.name ?: "استایار",
                    isSandboxProject = currentProject?.isSandbox ?: false,
                    isPeriodLocked = currentProject?.settings?.locked ?: false,
                    onTogglePeriodLock = {
                        scope.launch {
                            val cur = currentProject?.settings?.locked ?: false
                            val outcome = app.ledgerRepository.setPeriodLocked(!cur)
                            app.hapticsManager.confirm(20L)
                            if (outcome is com.workshop.ledger.data.repository.MutationOutcome.Success) {
                                showToast(if (!cur) "دوره مالی قفل شد" else "قفل باز شد")
                            }
                        }
                    },
                    themeMode = prefs.themeMode,
                    onCycleThemeMode = {
                        scope.launch {
                            app.preferencesRepository.setThemeMode(prefs.themeMode.next())
                        }
                    },
                    allProjects = allProjects,
                    activeProjectId = currentProject?.id ?: "",
                    onSelectProject = { pid ->
                        scope.launch {
                            app.preferencesRepository.setActiveProjectId(pid)
                            showToast("پروژه باز شد")
                        }
                    },
                    onSpeedDialAction = { action ->
                        when (action) {
                            SpeedDialAction.ATTENDANCE_TODAY -> {
                                currentPageId = "attendance"
                            }
                            SpeedDialAction.NEW_EXPENSE -> {
                                currentPageId = "expenses"
                                crudInitialFormOpen = true
                            }
                            SpeedDialAction.NEW_RECEIPT -> {
                                currentPageId = "receipts"
                                crudInitialFormOpen = true
                            }
                            SpeedDialAction.NEW_PAYOUT -> {
                                currentPageId = "payouts"
                                crudInitialFormOpen = true
                            }
                        }
                    },
                    databaseLoadError = loadError,
                    questCoordinator = if (isTutorialActive) questCoordinator else null
                ) {
                    if (currentProject != null) {
                        when (currentPageId) {
                            "dashboard" -> {
                                DashboardScreen(
                                    project = currentProject,
                                    r = r,
                                    prefs = prefs,
                                    isSavingBlocked = isSaveBlocked,
                                    onExportFullBackup = {
                                        scope.launch {
                                            val state = app.ledgerRepository.buildCurrentAppStateSnapshot()
                                            val out = ByteArrayOutputStream()
                                            app.backupManager.exportFullStateToStream(state, out)
                                            pendingExportBytes = out.toByteArray()
                                            createDocLauncher.launch(app.fileDeliveryManager.buildExportFileName("backup-all", "json"))
                                        }
                                    },
                                    onSnoozeBackupNag = {
                                        scope.launch {
                                            val threeDaysMs = 3L * 24L * 3600L * 1000L
                                            app.preferencesRepository.snoozeBackupNag(System.currentTimeMillis() + threeDaysMs)
                                        }
                                    },
                                    onUpdateReportRange = { from, to ->
                                        scope.launch {
                                            app.ledgerRepository.updateProjectSettings {
                                                it.copy(rangeFrom = from, rangeTo = to)
                                            }
                                        }
                                    },
                                    onNavigate = { page -> currentPageId = page },
                                    onCreateSampleProject = {
                                        scope.launch {
                                            app.ledgerRepository.createSampleProject()
                                            showToast("پروژه نمونه ساخته شد")
                                        }
                                    },
                                    onOpenPracticeChooser = {
                                        questCoordinator.showPracticeChooserSheet = true
                                    },
                                    onOpenStatementForUser = { uid ->
                                        currentPageId = "reports"
                                    },
                                    onOpenProfitRuler = {
                                        showProfitRuler = true
                                    },
                                    onSettleNegativeMasterToFund = { master, amount ->
                                        scope.launch {
                                            val today = JalaliCalendarEngine.todayStr()
                                            val adj = Adjustment(
                                                id = "adj_" + System.currentTimeMillis(),
                                                date = today,
                                                userId = master.id,
                                                kind = "settle",
                                                amount = amount,
                                                description = "تسویه نقدی مانده منفی",
                                                active = true
                                            )
                                            app.ledgerRepository.upsertAdjustment(adj)
                                            app.hapticsManager.confirm(12L)
                                            showToast("تسویه ثبت شد")
                                        }
                                    },
                                    onTransferNegativeMasterToPeer = { debtor, creditor, amount ->
                                        if (creditor == null) {
                                            showToast("اوستای دیگری برای انتقال وجود ندارد", isDanger = true)
                                        } else {
                                            scope.launch {
                                                val today = JalaliCalendarEngine.todayStr()
                                                val tr = Transfer(
                                                    id = "tr_" + System.currentTimeMillis(),
                                                    date = today,
                                                    kind = "peer",
                                                    fromId = debtor.id,
                                                    toId = creditor.id,
                                                    amount = amount,
                                                    description = "تسویه مانده منفی",
                                                    active = true
                                                )
                                                app.ledgerRepository.upsertTransfer(tr)
                                                showToast("انتقال ثبت شد")
                                            }
                                        }
                                    },
                                    questCoordinator = questCoordinator
                                )
                            }

                            "attendance" -> {
                                AttendanceScreen(
                                    project = currentProject,
                                    onToggleAttendance = { date, userId, value ->
                                        scope.launch {
                                            val outcome = app.ledgerRepository.toggleOrSetAttendance(date, userId, value)
                                            if (outcome is com.workshop.ledger.data.repository.MutationOutcome.PeriodLocked) {
                                                showToast("دوره مالی قفل است؛ ثبت غیرفعال است", isDanger = true)
                                            }
                                        }
                                    },
                                    onMarkAllPresent = { date ->
                                        scope.launch {
                                            val outcome = app.ledgerRepository.markAllPresentForDate(date)
                                            if (outcome is com.workshop.ledger.data.repository.MutationOutcome.Success) {
                                                showToast("حضور کامل برای همه ثبت شد")
                                            }
                                        }
                                    },
                                    onDismissCoach = {
                                        scope.launch {
                                            app.preferencesRepository.setCoachDismissed(true)
                                        }
                                    },
                                    onOpenSettings = { currentPageId = "settings" },
                                    isCoachDismissed = prefs.coachDismissed,
                                    synthesizer = app.pcmSynthesizer,
                                    haptics = app.hapticsManager,
                                    questCoordinator = questCoordinator
                                )
                            }

                            // 7 Config-driven CRUD screens
                            "receipts", "expenses", "payouts", "transfers", "adjustments", "wages", "users" -> {
                                val config = when (currentPageId) {
                                    "receipts" -> CrudPageConfig.Receipts
                                    "expenses" -> CrudPageConfig.Expenses
                                    "payouts" -> CrudPageConfig.Payouts
                                    "transfers" -> CrudPageConfig.Transfers
                                    "adjustments" -> CrudPageConfig.Adjustments
                                    "wages" -> CrudPageConfig.Wages
                                    else -> CrudPageConfig.Users
                                }

                                GenericCrudScreen(
                                    config = config,
                                    project = currentProject,
                                    r = r,
                                    initialFormOpen = crudInitialFormOpen,
                                    preselectedUserId = crudPreselectedUserId,
                                    onConsumeInitialForm = {
                                        crudInitialFormOpen = false
                                        crudPreselectedUserId = null
                                    },
                                    onNavigate = { page -> currentPageId = page },
                                    onNavigateToWagesWithUser = { uid, uname ->
                                        showToast("حالا دستمزد روزانهٔ «$uname» را ثبت کنید")
                                        currentPageId = "wages"
                                        crudInitialFormOpen = true
                                        crudPreselectedUserId = uid
                                    },
                                    onUpsertReceipt = { rc ->
                                        scope.launch {
                                            app.ledgerRepository.upsertReceipt(rc)
                                            showToast("ذخیره شد")
                                        }
                                    },
                                    onDeleteReceiptWithUndo = { rc ->
                                        scope.launch {
                                            app.ledgerRepository.deleteReceipt(rc.id)
                                            showToast("حذف شد", actionLabel = "برگردان") {
                                                scope.launch {
                                                    val outcome = app.ledgerRepository.upsertReceipt(rc)
                                                    if (outcome is com.workshop.ledger.data.repository.MutationOutcome.PeriodLocked) {
                                                        showToast("بازگرداندن ممکن نیست؛ دوره مالی قفل است!", isDanger = true)
                                                    } else {
                                                        showToast("برگردانده شد")
                                                    }
                                                }
                                            }
                                        }
                                    },
                                    onUpsertExpense = { ex ->
                                        scope.launch {
                                            app.ledgerRepository.upsertExpense(ex)
                                            showToast("ذخیره شد")
                                        }
                                    },
                                    onDeleteExpenseWithUndo = { ex ->
                                        scope.launch {
                                            app.ledgerRepository.deleteExpense(ex.id)
                                            showToast("حذف شد", actionLabel = "برگردان") {
                                                scope.launch {
                                                    app.ledgerRepository.upsertExpense(ex)
                                                    showToast("برگردانده شد")
                                                }
                                            }
                                        }
                                    },
                                    onUpsertPayout = { po ->
                                        scope.launch {
                                            app.ledgerRepository.upsertPayout(po)
                                            showToast("ذخیره شد")
                                        }
                                    },
                                    onDeletePayoutWithUndo = { po ->
                                        scope.launch {
                                            app.ledgerRepository.deletePayout(po.id)
                                            showToast("حذف شد", actionLabel = "برگردان") {
                                                scope.launch {
                                                    app.ledgerRepository.upsertPayout(po)
                                                    showToast("برگردانده شد")
                                                }
                                            }
                                        }
                                    },
                                    onUpsertTransfer = { tr ->
                                        scope.launch {
                                            app.ledgerRepository.upsertTransfer(tr)
                                            showToast("ذخیره شد")
                                        }
                                    },
                                    onDeleteTransferWithUndo = { tr ->
                                        scope.launch {
                                            app.ledgerRepository.deleteTransfer(tr.id)
                                            showToast("حذف شد", actionLabel = "برگردان") {
                                                scope.launch {
                                                    app.ledgerRepository.upsertTransfer(tr)
                                                    showToast("برگردانده شد")
                                                }
                                            }
                                        }
                                    },
                                    onUpsertAdjustment = { adj ->
                                        scope.launch {
                                            app.ledgerRepository.upsertAdjustment(adj)
                                            showToast("ذخیره شد")
                                        }
                                    },
                                    onDeleteAdjustmentWithUndo = { adj ->
                                        scope.launch {
                                            app.ledgerRepository.deleteAdjustment(adj.id)
                                            showToast("حذف شد", actionLabel = "برگردان") {
                                                scope.launch {
                                                    app.ledgerRepository.upsertAdjustment(adj)
                                                    showToast("برگردانده شد")
                                                }
                                            }
                                        }
                                    },
                                    onUpsertWage = { wg ->
                                        scope.launch {
                                            app.ledgerRepository.upsertWage(wg)
                                            showToast("ذخیره شد")
                                        }
                                    },
                                    onDeleteWageWithUndo = { wg ->
                                        scope.launch {
                                            app.ledgerRepository.deleteWage(wg.id)
                                            showToast("حذف شد", actionLabel = "برگردان") {
                                                scope.launch {
                                                    app.ledgerRepository.upsertWage(wg)
                                                    showToast("برگردانده شد")
                                                }
                                            }
                                        }
                                    },
                                    onUpsertUser = { u ->
                                        scope.launch {
                                            app.ledgerRepository.upsertUser(u)
                                            showToast("ذخیره شد")
                                        }
                                    },
                                    onHardDeleteUser = { u ->
                                        scope.launch {
                                            val outcome = app.ledgerRepository.hardDeleteUser(u.id)
                                            if (outcome is com.workshop.ledger.data.repository.MutationOutcome.Success) {
                                                showToast("یک نسخه امن ذخیره شد؛ کاربر حذف شد")
                                            }
                                        }
                                    },
                                    onUpsertCategory = { cat ->
                                        scope.launch {
                                            app.ledgerRepository.upsertCategory(cat)
                                            showToast("ذخیره شد")
                                        }
                                    },
                                    onDeleteCategory = { cid ->
                                        scope.launch {
                                            app.ledgerRepository.deleteCategory(cid)
                                            showToast("دسته حذف شد")
                                        }
                                    },
                                    onPreconditionError = { msg, redirect ->
                                        showToast(msg, isDanger = true)
                                        if (redirect != null) currentPageId = redirect
                                    },
                                    synthesizer = app.pcmSynthesizer,
                                    haptics = app.hapticsManager,
                                    questCoordinator = questCoordinator
                                )
                            }

                            "reports" -> {
                                ReportsScreen(
                                    project = currentProject,
                                    r = r,
                                    documentEngine = app.documentEngine,
                                    fileDelivery = app.fileDeliveryManager,
                                    onOpenRangeDialog = {
                                        // Open range modal
                                    },
                                    onNavigateToHealth = { currentPageId = "health" },
                                    onExportProjectJson = {
                                        scope.launch {
                                            val out = ByteArrayOutputStream()
                                            app.backupManager.exportProjectToStream(currentProject, out)
                                            pendingExportBytes = out.toByteArray()
                                            val fileName = app.fileDeliveryManager.buildProjectJsonFileName(currentProject.id)
                                            createDocLauncher.launch(fileName)
                                        }
                                    },
                                    onExportFullDatabaseJson = {
                                        scope.launch {
                                            val state = app.ledgerRepository.buildCurrentAppStateSnapshot()
                                            val out = ByteArrayOutputStream()
                                            app.backupManager.exportFullStateToStream(state, out)
                                            pendingExportBytes = out.toByteArray()
                                            val fileName = app.fileDeliveryManager.buildExportFileName("backup-all", "json")
                                            createDocLauncher.launch(fileName)
                                        }
                                    },
                                    onToast = { msg -> showToast(msg) }
                                )
                            }

                            "health" -> {
                                HealthScreen(
                                    project = currentProject,
                                    onNavigateToPage = { page -> currentPageId = page },
                                    onCleanOrphans = {
                                        scope.launch {
                                            app.ledgerRepository.cleanOrphansInActiveProject()
                                            showToast("رکوردهای یتیم پاک شد")
                                        }
                                    }
                                )
                            }

                            "projects" -> {
                                ProjectsScreen(
                                    allProjects = allProjects,
                                    activeProjectId = currentProject.id,
                                    onSelectProject = { pid ->
                                        scope.launch {
                                            app.preferencesRepository.setActiveProjectId(pid)
                                            showToast("پروژه باز شد")
                                        }
                                    },
                                    onCreateProject = { name ->
                                        scope.launch {
                                            val outcome = app.ledgerRepository.createNewProject(name)
                                            if (outcome is com.workshop.ledger.data.repository.MutationOutcome.ValidationError) {
                                                showToast(outcome.messageFa, isDanger = true)
                                            } else {
                                                showToast("پروژه ساخته شد")
                                            }
                                        }
                                    },
                                    onRenameProject = { newName ->
                                        scope.launch {
                                            app.ledgerRepository.renameActiveProject(newName)
                                            showToast("نام تغییر کرد")
                                        }
                                    },
                                    onCloneStructure = { pid ->
                                        scope.launch {
                                            app.ledgerRepository.cloneProjectStructure(pid)
                                            showToast("ساختار پروژه تکثیر شد؛ داده‌های مالی صفر است")
                                        }
                                    },
                                    onDeleteProject = { pid ->
                                        scope.launch {
                                            val outcome = app.ledgerRepository.deleteProject(pid)
                                            if (outcome is com.workshop.ledger.data.repository.MutationOutcome.ValidationError) {
                                                showToast(outcome.messageFa, isDanger = true)
                                            } else {
                                                showToast("پروژه حذف شد")
                                            }
                                        }
                                    },
                                    onCreateSampleProject = {
                                        scope.launch {
                                            app.ledgerRepository.createSampleProject()
                                            showToast("پروژه نمونه ساخته شد")
                                        }
                                    }
                                )
                            }

                            "guide" -> {
                                GuideScreen(
                                    onStartInteractivePractice = {
                                        questCoordinator.showPracticeChooserSheet = true
                                    },
                                    onJumpToScreen = { page -> currentPageId = page }
                                )
                            }

                            "settings" -> {
                                SettingsScreen(
                                    project = currentProject,
                                    prefs = prefs,
                                    emergencySnapshot = app.backupManager.getEmergencySnapshotInfo(),
                                    rollingSnapshots = app.backupManager.getRollingSnapshots(),
                                    onUpdateProfitBasis = { basis ->
                                        scope.launch {
                                            app.ledgerRepository.updateProjectSettings { it.copy(profitBasis = basis) }
                                            showToast("مبنای سود تغییر کرد")
                                        }
                                    },
                                    onUpdateOvertimeFactor = { ot ->
                                        scope.launch {
                                            app.ledgerRepository.updateProjectSettings { it.copy(overtimeFactor = ot) }
                                            showToast("ضریب اضافه‌کار به‌روزرسانی شد")
                                        }
                                    },
                                    onUpdateAbsentPenalty = { pen ->
                                        scope.launch {
                                            app.ledgerRepository.updateProjectSettings { it.copy(absentPenalty = pen) }
                                            showToast("کسر غیبت به‌روزرسانی شد")
                                        }
                                    },
                                    onTogglePeriodLock = {
                                        scope.launch {
                                            val cur = currentProject.settings.locked
                                            app.ledgerRepository.setPeriodLocked(!cur)
                                            showToast(if (!cur) "دوره مالی قفل شد" else "قفل باز شد")
                                        }
                                    },
                                    onOpenReportRangeDialog = {
                                        // Open range dialog
                                    },
                                    onRenameProject = {
                                        currentPageId = "projects"
                                    },
                                    onExportFullBackup = {
                                        scope.launch {
                                            val state = app.ledgerRepository.buildCurrentAppStateSnapshot()
                                            val out = ByteArrayOutputStream()
                                            app.backupManager.exportFullStateToStream(state, out)
                                            pendingExportBytes = out.toByteArray()
                                            createDocLauncher.launch(app.fileDeliveryManager.buildExportFileName("backup-all", "json"))
                                        }
                                    },
                                    onImportFullBackup = {
                                        openDocLauncher.launch(arrayOf("application/json", "application/octet-stream", "*/*"))
                                    },
                                    onExportProjectJson = {
                                        scope.launch {
                                            val out = ByteArrayOutputStream()
                                            app.backupManager.exportProjectToStream(currentProject, out)
                                            pendingExportBytes = out.toByteArray()
                                            createDocLauncher.launch(app.fileDeliveryManager.buildProjectJsonFileName(currentProject.id))
                                        }
                                    },
                                    onImportProjectJson = {
                                        openDocLauncher.launch(arrayOf("application/json", "application/octet-stream", "*/*"))
                                    },
                                    onRestoreEmergencySnapshot = {
                                        scope.launch {
                                            val snap = app.backupManager.readSnapshotFile(app.backupManager.recoverySnapshotFile)
                                            if (snap != null) {
                                                app.ledgerRepository.replaceFullDatabaseState(snap, "بازیابی نسخه اضطراری")
                                                showToast("نسخه اضطراری بازیابی شد")
                                            } else {
                                                showToast("فایل نسخه اضطراری یافت نشد", isDanger = true)
                                            }
                                        }
                                    },
                                    onCreateRollingSnapshotNow = {
                                        scope.launch {
                                            val state = app.ledgerRepository.buildCurrentAppStateSnapshot()
                                            val ok = app.backupManager.writeRollingAutoBackup(state, force = true)
                                            if (ok) showToast("نسخه پشتیبان ساخته شد")
                                        }
                                    },
                                    onRestoreRollingSnapshot = { snapInfo ->
                                        scope.launch {
                                            val state = app.backupManager.readSnapshotFile(snapInfo.file)
                                            if (state != null) {
                                                app.ledgerRepository.replaceFullDatabaseState(state, "بازیابی نسخه چرخشی ${snapInfo.slot}")
                                                showToast("نسخه چرخشی بازیابی شد")
                                            }
                                        }
                                    },
                                    onSelectThemeMode = { mode ->
                                        scope.launch { app.preferencesRepository.setThemeMode(mode) }
                                    },
                                    onSelectDigitsMode = { mode ->
                                        scope.launch { app.preferencesRepository.setDigitsMode(mode) }
                                    },
                                    onToggleSplash = { sp ->
                                        scope.launch { app.preferencesRepository.setSplashEnabled(sp) }
                                    },
                                    onToggleSound = { snd ->
                                        scope.launch { app.preferencesRepository.setSoundEnabled(snd) }
                                    },
                                    onToggleHaptics = { hp ->
                                        scope.launch { app.preferencesRepository.setHapticsEnabled(hp) }
                                    },
                                    onUpdateVolume = { vol ->
                                        scope.launch { app.preferencesRepository.setVolume(vol) }
                                    },
                                    onTestSound = {
                                        app.pcmSynthesizer.chime(ok = true)
                                        app.hapticsManager.confirm(15L)
                                    },
                                    onSelectNotifVerbosity = { verb ->
                                        scope.launch { app.preferencesRepository.setNotifVerbosity(verb) }
                                    },
                                    onStartPracticeTutorial = {
                                        questCoordinator.showPracticeChooserSheet = true
                                    },
                                    onOpen12StepGuide = {
                                        currentPageId = "guide"
                                    },
                                    onCreateSampleProject = {
                                        scope.launch {
                                            app.ledgerRepository.createSampleProject()
                                            showToast("پروژه نمونه ساخته شد")
                                        }
                                    },
                                    onClearFinancialData = {
                                        scope.launch {
                                            app.ledgerRepository.clearActiveProjectFinancialData()
                                            showToast("داده‌های مالی پروژه پاک شد")
                                        }
                                    }
                                )
                            }
                        }
                    }
                }

                // Profit Ruler Sheet
                if (showProfitRuler) {
                    ProfitRulerSheet(
                        r = r,
                        onDismiss = { showProfitRuler = false }
                    )
                }

                // Quest Beacon Overlay & Quest Dock when interactive tutorial is active
                if (isTutorialActive && currentStep != null) {
                    val aimKey = currentStep.aim.key
                    val targetRect = questCoordinator.targetRects[aimKey]

                    QuestBeaconOverlay(targetRect = targetRect)

                    QuestDock(
                        step = currentStep,
                        stepDoneResultText = questCoordinator.stepDoneBanner,
                        onPrevStep = {
                            if (currentStep.index > 0) {
                                scope.launch {
                                    questCoordinator.stepDoneBanner = null
                                    app.preferencesRepository.setOnboarding(
                                        currentOnboarding.copy(questStep = currentStep.index - 1)
                                    )
                                }
                            }
                        },
                        onNavigateToAimPage = { page ->
                            currentPageId = page
                        },
                        onApplySkipHelpersAndNext = {
                            scope.launch {
                                currentStep.skippedHelpers(activeProject ?: return@launch) { transform ->
                                    scope.launch { app.ledgerRepository.applyTutorialHelperTransform(transform) }
                                }
                                questCoordinator.stepDoneBanner = null
                                if (currentStep.index >= TutorialChapters.ALL_28_STEPS.lastIndex) {
                                    app.preferencesRepository.setOnboarding(
                                        currentOnboarding.copy(status = "completed")
                                    )
                                    questCoordinator.showGraduationSheet = true
                                } else {
                                    val nextStep = currentStep.index + 1
                                    val nextChapter = when {
                                        nextStep < 15 -> 1
                                        nextStep < 22 -> 2
                                        else -> 3
                                    }
                                    app.preferencesRepository.setOnboarding(
                                        currentOnboarding.copy(
                                            questStep = nextStep,
                                            chapter = nextChapter
                                        )
                                    )
                                }
                            }
                        }
                    )
                }

                // Graduation Sheet
                if (questCoordinator.showGraduationSheet) {
                    GraduationSheet(
                        onDismiss = { questCoordinator.showGraduationSheet = false },
                        onLeaveSandbox = {
                            scope.launch {
                                questCoordinator.showGraduationSheet = false
                                val normalProj = allProjects.firstOrNull { !it.id.startsWith("demo_quest_") }
                                if (normalProj != null) {
                                    app.preferencesRepository.setActiveProjectId(normalProj.id)
                                }
                                currentPageId = "dashboard"
                            }
                        }
                    )
                }

                // Practice Chooser Sheet
                if (questCoordinator.showPracticeChooserSheet) {
                    PracticeChooserSheet(
                        currentOnboarding = currentOnboarding,
                        onStartChapter = { ch, stepIdx ->
                            scope.launch {
                                questCoordinator.showPracticeChooserSheet = false
                                app.ledgerRepository.startOrResumePracticeTutorial(chapter = ch, stepIndex = stepIdx)
                                currentPageId = "dashboard"
                            }
                        },
                        onResumeCurrent = {
                            scope.launch {
                                questCoordinator.showPracticeChooserSheet = false
                                val sbId = currentOnboarding.sandboxProjectId
                                if (sbId.isNotBlank()) {
                                    app.preferencesRepository.setActiveProjectId(sbId)
                                }
                                currentPageId = "dashboard"
                            }
                        },
                        onDismiss = { questCoordinator.showPracticeChooserSheet = false }
                    )
                }

                // Import Confirmation Preview Dialog
                importPreviewDialog?.let { preview ->
                    when (preview) {
                        is ImportValidationPreview.ValidFullBackup -> {
                            val msg = "همهٔ پروژه‌ها با محتوای فایل جایگزین می‌شوند. پیش از آن، یک نسخه امن از وضعیت فعلی ذخیره خواهد شد." +
                                if (preview.fixesCount > 0) "\n⚠ ${TextNormalizer.formatDisplayDigits(preview.fixesCount.toString(), prefs.digitsMode)} مقدار نامعتبر یا ناامن در فایل اصلاح شد." else ""
                            androidx.compose.material3.AlertDialog(
                                onDismissRequest = { importPreviewDialog = null },
                                title = { androidx.compose.material3.Text("بازیابی پشتیبان کامل") },
                                text = { androidx.compose.material3.Text(msg) },
                                confirmButton = {
                                    androidx.compose.material3.Button(
                                        onClick = {
                                            scope.launch {
                                                app.ledgerRepository.replaceFullDatabaseState(preview.state, "بازیابی فایل کامل")
                                                importPreviewDialog = null
                                                showToast("پشتیبان بازیابی شد")
                                            }
                                        },
                                        colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                                            containerColor = StayarTheme.colors.danger
                                        )
                                    ) {
                                        androidx.compose.material3.Text("جایگزین کن")
                                    }
                                },
                                dismissButton = {
                                    androidx.compose.material3.OutlinedButton(onClick = { importPreviewDialog = null }) {
                                        androidx.compose.material3.Text("انصراف")
                                    }
                                }
                            )
                        }

                        is ImportValidationPreview.ValidSingleProject -> {
                            val msg = "پروژه «${preview.project.name}» به‌عنوان یک پروژه جدید اضافه می‌شود و پروژه‌های فعلی دست‌نخورده می‌مانند." +
                                if (preview.fixesCount > 0) "\n⚠ ${TextNormalizer.formatDisplayDigits(preview.fixesCount.toString(), prefs.digitsMode)} مقدار نامعتبر در فایل اصلاح شد." else ""
                            androidx.compose.material3.AlertDialog(
                                onDismissRequest = { importPreviewDialog = null },
                                title = { androidx.compose.material3.Text("ورود پروژه") },
                                text = { androidx.compose.material3.Text(msg) },
                                confirmButton = {
                                    androidx.compose.material3.Button(
                                        onClick = {
                                            scope.launch {
                                                app.ledgerRepository.appendImportedProject(preview.project)
                                                importPreviewDialog = null
                                                showToast("پروژه اضافه شد")
                                            }
                                        }
                                    ) {
                                        androidx.compose.material3.Text("افزودن")
                                    }
                                },
                                dismissButton = {
                                    androidx.compose.material3.OutlinedButton(onClick = { importPreviewDialog = null }) {
                                        androidx.compose.material3.Text("انصراف")
                                    }
                                }
                            )
                        }

                        is ImportValidationPreview.Invalid -> {
                            androidx.compose.material3.AlertDialog(
                                onDismissRequest = { importPreviewDialog = null },
                                title = { androidx.compose.material3.Text("خطا در فایل پشتیبان") },
                                text = { androidx.compose.material3.Text(preview.errorMessageFa) },
                                confirmButton = {
                                    androidx.compose.material3.Button(onClick = { importPreviewDialog = null }) {
                                        androidx.compose.material3.Text("متوجه شدم")
                                    }
                                }
                            )
                        }
                    }
                }

                // Global Toast Host
                ToastHost(
                    messages = toasts,
                    onDismiss = { id -> dismissToast(id) }
                )
            }
        }
    }
}
