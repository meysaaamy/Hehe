package com.workshop.ledger

import android.app.Application
import com.workshop.ledger.core.audio.NativePcmSynthesizer
import com.workshop.ledger.core.document.StayarDocumentEngine
import com.workshop.ledger.core.export.FileDeliveryManager
import com.workshop.ledger.core.haptics.RichHapticsManager
import com.workshop.ledger.data.local.backup.BackupManager
import com.workshop.ledger.data.local.datastore.PreferencesRepository
import com.workshop.ledger.data.local.db.LedgerDatabase
import com.workshop.ledger.data.repository.LedgerRepositoryImpl
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

/**
 * Application entry point for «استایار» (Stayar).
 * Initializes singleton native engines, offline Room (WAL) database,
 * Proto DataStore preferences, and atomic backup infrastructure.
 */
class StayarApp : Application() {

    val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    lateinit var database: LedgerDatabase
        private set

    lateinit var preferencesRepository: PreferencesRepository
        private set

    lateinit var backupManager: BackupManager
        private set

    lateinit var ledgerRepository: LedgerRepositoryImpl
        private set

    lateinit var documentEngine: StayarDocumentEngine
        private set

    lateinit var pcmSynthesizer: NativePcmSynthesizer
        private set

    lateinit var hapticsManager: RichHapticsManager
        private set

    lateinit var fileDeliveryManager: FileDeliveryManager
        private set

    override fun onCreate() {
        super.onCreate()
        database = LedgerDatabase.getInstance(this)
        preferencesRepository = PreferencesRepository(this)
        backupManager = BackupManager(this)
        ledgerRepository = LedgerRepositoryImpl(
            dao = database.ledgerDao(),
            prefs = preferencesRepository,
            backupManager = backupManager,
            appScope = applicationScope
        )
        documentEngine = StayarDocumentEngine(this)
        pcmSynthesizer = NativePcmSynthesizer()
        hapticsManager = RichHapticsManager(this)
        fileDeliveryManager = FileDeliveryManager(this)
        fileDeliveryManager.cleanupOldExports()
    }
}
