package com.workshop.ledger.presentation.screens.attendance

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.workshop.ledger.core.audio.NativePcmSynthesizer
import com.workshop.ledger.core.haptics.RichHapticsManager
import com.workshop.ledger.domain.engine.AccountingEngine
import com.workshop.ledger.domain.engine.JalaliCalendarEngine
import com.workshop.ledger.domain.engine.TextNormalizer
import com.workshop.ledger.domain.model.AttendanceValue
import com.workshop.ledger.domain.model.Project
import com.workshop.ledger.domain.model.User
import com.workshop.ledger.presentation.components.TactileSheet
import com.workshop.ledger.presentation.theme.StayarTheme
import java.util.Locale
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

private data class CellMenuTarget(
    val user: User,
    val dateStr: String
)

/**
 * 120 FPS bi-directional monthly attendance matrix (`LazyTwoDimensionalGrid` architecture)
 * with sticky right columns («روز», «هفته»), sticky top person header, sticky bottom «جمع / روز»
 * footer, Friday row tinting, SparkParticleCanvas burst on tap, long-press cell menu sheet,
 * and tap-on-day group sheet.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun LazyTwoDimensionalMatrix(
    project: Project,
    activeUsers: List<User>,
    yearMonth: String, // "YYYY/MM"
    onPrevMonth: () -> Unit,
    onNextMonth: () -> Unit,
    onThisMonth: () -> Unit,
    onCycleCell: (dateStr: String, user: User) -> Unit,
    onSetCellExplicit: (dateStr: String, user: User, value: AttendanceValue?) -> Unit,
    onMarkAllPresentForDate: (dateStr: String) -> Unit,
    synthesizer: NativePcmSynthesizer? = null,
    haptics: RichHapticsManager? = null
) {
    val colors = StayarTheme.colors
    val digitsMode = StayarTheme.digitsMode
    val f = { s: String -> TextNormalizer.formatDisplayDigits(s, digitsMode) }

    val parts = yearMonth.split("/")
    val jy = parts.getOrNull(0)?.toIntOrNull() ?: 1405
    val jm = parts.getOrNull(1)?.toIntOrNull()?.coerceIn(1, 12) ?: 1
    val monthLength = JalaliCalendarEngine.jalaaliMonthLength(jy, jm)
    val monthName = JalaliCalendarEngine.MONTHS_FA[jm - 1]
    val todayStr = remember { JalaliCalendarEngine.jTodayStr() }

    val monthDates = remember(jy, jm, monthLength) {
        (1..monthLength).map { d -> "%04d/%02d/%02d".format(Locale.US, jy, jm, d) }
    }

    // Check if inactive users have attendance in this month
    val inactiveUsers = remember(project.users) { project.liveUsers().filter { !it.active } }
    val inactiveAttCount = remember(project.attendance, monthDates, inactiveUsers) {
        var count = 0
        for (d in monthDates) {
            val dm = project.attendance[d] ?: continue
            for (iu in inactiveUsers) {
                if (dm.containsKey(iu.id)) count++
            }
        }
        count
    }

    // Per-person month totals
    val monthTotals = remember(project, monthDates, activeUsers) {
        activeUsers.associate { u ->
            var sum = 0.0
            for (d in monthDates) {
                val v = project.attendance[d]?.get(u.id) ?: continue
                val fr = AccountingEngine.attFr(v, project) ?: 0.0
                sum += fr
            }
            u.id to sum
        }
    }

    var cellMenuTarget by remember { mutableStateOf<CellMenuTarget?>(null) }
    var groupDaySheetDate by remember { mutableStateOf<String?>(null) }
    var sparkKey by remember { mutableStateOf<String?>(null) }

    val horizontalScrollState = rememberScrollState()
    val verticalListState = rememberLazyListState()

    // Auto-scroll to today on initial open if in current month
    LaunchedEffect(yearMonth) {
        val todayIdx = monthDates.indexOf(todayStr)
        if (todayIdx > 3) {
            verticalListState.scrollToItem((todayIdx - 2).coerceAtLeast(0))
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 12.dp)
    ) {
        // Month Toolbar
        Surface(
            shape = RoundedCornerShape(14.dp),
            color = colors.bgElev,
            border = BorderStroke(colors.defaultBorderWidth, colors.borderStrong),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 6.dp)
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(onClick = onPrevMonth) {
                        Text("ماه قبل", fontSize = 12.sp, color = colors.text)
                    }
                    Text(
                        text = f("$monthName $jy"),
                        fontSize = 16.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = colors.text
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(onClick = onNextMonth) {
                            Text("ماه بعد", fontSize = 12.sp, color = colors.text)
                        }
                        Button(
                            onClick = onThisMonth,
                            colors = ButtonDefaults.buttonColors(containerColor = colors.accent)
                        ) {
                            Text("این ماه", fontSize = 12.sp, color = colors.onAccent, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "لمس: چرخش وضعیت · نگهداشتن: ساعت دقیق · لمس شماره روز: ثبت گروهی",
                    fontSize = 11.5.sp,
                    color = colors.textDim
                )

                if (inactiveAttCount > 0) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = colors.warn.copy(alpha = 0.15f),
                        border = BorderStroke(1.dp, colors.warn)
                    ) {
                        Text(
                            text = f("⚠ $inactiveAttCount ثبت حضور برای نیروی غیرفعال در این ماه هست؛ در حساب‌ها حساب می‌شود ولی اینجا دیده نمی‌شود. برای ویرایش، آن نیرو را در «کاربران» دوباره فعال کنید."),
                            fontSize = 11.5.sp,
                            color = colors.text,
                            modifier = Modifier.padding(8.dp)
                        )
                    }
                }
            }
        }

        // Sticky Top Header Row
        Surface(
            color = colors.bgElev2,
            border = BorderStroke(colors.defaultBorderWidth, colors.borderStrong),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                // Sticky Right Columns (RTL start): «روز» and «هفته»
                Text(
                    text = "روز",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.text,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .width(42.dp)
                        .padding(vertical = 10.dp)
                )
                Text(
                    text = "هفته",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.text,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .width(64.dp)
                        .padding(vertical = 10.dp)
                )

                // Scrollable Person Headers
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .horizontalScroll(horizontalScrollState)
                ) {
                    for (u in activeUsers) {
                        Text(
                            text = u.name,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = colors.text,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            textAlign = TextAlign.Center,
                            modifier = Modifier
                                .width(88.dp)
                                .padding(horizontal = 4.dp, vertical = 10.dp)
                        )
                    }
                }
            }
        }

        // 2D Matrix Body Rows
        LazyColumn(
            state = verticalListState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            items(monthDates, key = { it }) { dateStr ->
                val dayNumStr = dateStr.takeLast(2)
                val dowIdx = JalaliCalendarEngine.jDowIndex(dateStr)
                val isFriday = dowIdx == 5
                val isToday = dateStr == todayStr
                val weekdayFa = JalaliCalendarEngine.WEEKDAYS_FA[dowIdx]
                val dayMap = project.attendance[dateStr].orEmpty()

                val rowBg = when {
                    isToday -> colors.accent.copy(alpha = 0.14f)
                    isFriday -> colors.warn.copy(alpha = 0.10f)
                    else -> colors.bgElev
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(rowBg)
                ) {
                    // Sticky Right Column 1: Day Number (tapping opens group day sheet)
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .width(42.dp)
                            .height(48.dp)
                            .clickable { groupDaySheetDate = dateStr }
                    ) {
                        Text(
                            text = f(dayNumStr),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = if (isToday) colors.accent else colors.text
                        )
                    }

                    // Sticky Right Column 2: Weekday Name
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .width(64.dp)
                            .height(48.dp)
                            .clickable { groupDaySheetDate = dateStr }
                    ) {
                        Text(
                            text = weekdayFa,
                            fontSize = 11.5.sp,
                            fontWeight = if (isFriday) FontWeight.Bold else FontWeight.Normal,
                            color = if (isFriday) colors.warn else colors.textDim
                        )
                    }

                    // Scrollable Person Cells for this Day
                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .horizontalScroll(horizontalScrollState)
                    ) {
                        for (u in activeUsers) {
                            val v = dayMap[u.id]
                            val cellKey = "$dateStr-${u.id}"
                            MatrixAttendanceCell(
                                value = v,
                                showSpark = sparkKey == cellKey,
                                onTap = {
                                    sparkKey = cellKey
                                    onCycleCell(dateStr, u)
                                },
                                onLongPress = {
                                    haptics?.oneShot(18L, 180)
                                    cellMenuTarget = CellMenuTarget(u, dateStr)
                                }
                            )
                        }
                    }
                }
                HorizontalDivider(color = colors.border, thickness = colors.defaultBorderWidth)
            }
        }

        // Sticky Bottom Footer Row: «جمع / روز»
        Surface(
            color = colors.bgElev2,
            border = BorderStroke(colors.defaultBorderWidth, colors.borderStrong),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "جمع / روز",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = colors.accent,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .width(106.dp)
                        .padding(vertical = 10.dp)
                )
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .horizontalScroll(horizontalScrollState)
                ) {
                    for (u in activeUsers) {
                        val total = monthTotals[u.id] ?: 0.0
                        Text(
                            text = f(TextNormalizer.fmtDays(total)),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = colors.accent,
                            textAlign = TextAlign.Center,
                            modifier = Modifier
                                .width(88.dp)
                                .padding(vertical = 10.dp)
                        )
                    }
                }
            }
        }
    }

    // Long-press Cell Menu Sheet
    if (cellMenuTarget != null) {
        val target = cellMenuTarget!!
        val currentVal = project.attendance[target.dateStr]?.get(target.user.id)
        val initialH = (currentVal as? AttendanceValue.Hourly)?.hours ?: 8.0
        var sliderH by remember(target) { mutableDoubleStateOf(initialH) }
        val ot = AccountingEngine.sanitizeOvertimeFactor(project.settings.overtimeFactor)
        val equiv = AccountingEngine.attFraction(AttendanceValue.Hourly(sliderH), ot) ?: 1.0

        TactileSheet(
            titleFa = "${target.user.name} — ${JalaliCalendarEngine.jDowStr(target.dateStr)} ${f(target.dateStr)}",
            onDismissRequest = { cellMenuTarget = null }
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf(
                    "کامل" to AttendanceValue.Full,
                    "نصفه" to AttendanceValue.Half,
                    "غایب" to AttendanceValue.Absent,
                    "پاک کردن" to null
                ).forEach { (label, attVal) ->
                    OutlinedButton(
                        onClick = {
                            onSetCellExplicit(target.dateStr, target.user, attVal)
                            cellMenuTarget = null
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(label, fontSize = 12.sp, color = colors.text, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "ساعت دقیق کارکرد (۱ تا ۲۴):",
                fontSize = 13.5.sp,
                fontWeight = FontWeight.Bold,
                color = colors.text
            )
            Spacer(modifier = Modifier.height(8.dp))

            HourPickerControlsContent(
                hours = sliderH,
                hoursFa = TextNormalizer.hrFa(sliderH),
                equivFa = TextNormalizer.hrFa(equiv),
                onUpdateHours = { newH ->
                    sliderH = ((newH * 2.0).roundToInt() / 2.0).coerceIn(0.5, 24.0)
                    synthesizer?.hourSliderTick(sliderH)
                },
                onConfirm = {
                    onSetCellExplicit(target.dateStr, target.user, AttendanceValue.Hourly(sliderH))
                    cellMenuTarget = null
                }
            )
        }
    }

    // Group Day Sheet on tapping day number
    if (groupDaySheetDate != null) {
        val gDate = groupDaySheetDate!!
        val dayMap = project.attendance[gDate].orEmpty()
        val absentPenalty = AccountingEngine.sanitizeAbsentPenalty(project.settings.absentPenalty)
        TactileSheet(
            titleFa = "ثبت گروهی حضور — ${f(gDate)}",
            onDismissRequest = { groupDaySheetDate = null }
        ) {
            Button(
                onClick = { onMarkAllPresentForDate(gDate) },
                colors = ButtonDefaults.buttonColors(containerColor = colors.accent),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
            ) {
                Text("حاضر زدن همه", color = colors.onAccent, fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.height(10.dp))
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                for (u in activeUsers.take(6)) {
                    val cur = dayMap[u.id]
                    val fr = AccountingEngine.attFr(cur, project)
                    PersonAttendanceCard(
                        user = u,
                        currentVal = cur,
                        fraction = fr,
                        absentPenalty = absentPenalty,
                        onTapFull = { onSetCellExplicit(gDate, u, if (cur == AttendanceValue.Full) null else AttendanceValue.Full) },
                        onTapHalf = { onSetCellExplicit(gDate, u, if (cur == AttendanceValue.Half) null else AttendanceValue.Half) },
                        onTapHourly = {
                            groupDaySheetDate = null
                            cellMenuTarget = CellMenuTarget(u, gDate)
                        },
                        onTapAbsent = { onSetCellExplicit(gDate, u, if (cur == AttendanceValue.Absent) null else AttendanceValue.Absent) }
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun MatrixAttendanceCell(
    value: AttendanceValue?,
    showSpark: Boolean,
    onTap: () -> Unit,
    onLongPress: () -> Unit
) {
    val colors = StayarTheme.colors
    val glyphAndColor = when (value) {
        AttendanceValue.Full -> "✓" to colors.success
        AttendanceValue.Half -> "½" to colors.warn
        AttendanceValue.Absent -> "✗" to colors.danger
        is AttendanceValue.Hourly -> "${TextNormalizer.hrFa(value.hours)}س" to colors.info
        null -> "·" to colors.textMute
    }

    val sparkAnim = remember { Animatable(0f) }
    LaunchedEffect(showSpark, value) {
        if (showSpark) {
            sparkAnim.snapTo(0f)
            sparkAnim.animateTo(1f, tween(320))
        }
    }

    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .width(88.dp)
            .height(48.dp)
            .combinedClickable(
                onClick = onTap,
                onLongClick = onLongPress
            )
    ) {
        Surface(
            shape = RoundedCornerShape(8.dp),
            color = if (value != null) glyphAndColor.second.copy(alpha = 0.16f) else colors.bgElev2.copy(alpha = 0.5f),
            border = BorderStroke(1.dp, if (value != null) glyphAndColor.second else colors.border),
            modifier = Modifier
                .size(width = 76.dp, height = 38.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Text(
                    text = glyphAndColor.first,
                    fontSize = 13.5.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = glyphAndColor.second
                )
            }
        }

        if (showSpark && sparkAnim.value in 0.01f..0.99f) {
            SparkParticleCanvas(
                progress = sparkAnim.value,
                color = glyphAndColor.second
            )
        }
    }
}

@Composable
fun SparkParticleCanvas(
    progress: Float,
    color: androidx.compose.ui.graphics.Color
) {
    Canvas(modifier = Modifier.size(48.dp)) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        val maxR = size.minDimension * 0.48f
        for (i in 0 until 8) {
            val angle = i * (Math.PI / 4.0)
            val r = maxR * progress
            val px = cx + (cos(angle) * r).toFloat()
            val py = cy + (sin(angle) * r).toFloat()
            drawCircle(
                color = color.copy(alpha = 1f - progress),
                radius = 3.dp.toPx() * (1f - progress * 0.5f),
                center = Offset(px, py)
            )
        }
    }
}
