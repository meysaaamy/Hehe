package com.workshop.ledger.data.local.db

import androidx.room.Dao
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Upsert
import com.workshop.ledger.data.local.db.EntityMappers.toEntity
import com.workshop.ledger.data.local.db.EntityMappers.toProjectEntity
import com.workshop.ledger.domain.model.Project
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine

@Dao
interface LedgerDao {

    // Projects
    @Query("SELECT * FROM projects ORDER BY createdAt ASC")
    fun observeAllProjectEntities(): Flow<List<ProjectEntity>>

    @Query("SELECT * FROM projects ORDER BY createdAt ASC")
    suspend fun getAllProjectEntities(): List<ProjectEntity>

    @Query("SELECT * FROM projects WHERE id = :projectId LIMIT 1")
    fun observeProjectEntity(projectId: String): Flow<ProjectEntity?>

    @Query("SELECT * FROM projects WHERE id = :projectId LIMIT 1")
    suspend fun getProjectEntity(projectId: String): ProjectEntity?

    @Upsert
    suspend fun upsertProject(entity: ProjectEntity)

    @Query("DELETE FROM projects WHERE id = :projectId")
    suspend fun deleteProjectById(projectId: String)

    @Query("DELETE FROM projects")
    suspend fun deleteAllProjects()

    // Child tables observation for active project
    @Query("SELECT * FROM users WHERE projectId = :projectId ORDER BY createdAt ASC")
    fun observeUsers(projectId: String): Flow<List<UserEntity>>

    @Query("SELECT * FROM wages WHERE projectId = :projectId ORDER BY effectiveDate ASC")
    fun observeWages(projectId: String): Flow<List<WageEntity>>

    @Query("SELECT * FROM attendance WHERE projectId = :projectId ORDER BY date ASC")
    fun observeAttendance(projectId: String): Flow<List<AttendanceEntity>>

    @Query("SELECT * FROM expenses WHERE projectId = :projectId ORDER BY date DESC, createdAt DESC")
    fun observeExpenses(projectId: String): Flow<List<ExpenseEntity>>

    @Query("SELECT * FROM receipts WHERE projectId = :projectId ORDER BY dateFrom DESC, createdAt DESC")
    fun observeReceipts(projectId: String): Flow<List<ReceiptEntity>>

    @Query("SELECT * FROM payouts WHERE projectId = :projectId ORDER BY date DESC, createdAt DESC")
    fun observePayouts(projectId: String): Flow<List<PayoutEntity>>

    @Query("SELECT * FROM transfers WHERE projectId = :projectId ORDER BY date DESC, createdAt DESC")
    fun observeTransfers(projectId: String): Flow<List<TransferEntity>>

    @Query("SELECT * FROM adjustments WHERE projectId = :projectId ORDER BY date DESC, createdAt DESC")
    fun observeAdjustments(projectId: String): Flow<List<AdjustmentEntity>>

    @Query("SELECT * FROM categories WHERE projectId = :projectId")
    fun observeCategories(projectId: String): Flow<List<CategoryEntity>>

    // One-shot child queries for snapshot / export
    @Query("SELECT * FROM users WHERE projectId = :projectId ORDER BY createdAt ASC")
    suspend fun getUsers(projectId: String): List<UserEntity>

    @Query("SELECT * FROM wages WHERE projectId = :projectId ORDER BY effectiveDate ASC")
    suspend fun getWages(projectId: String): List<WageEntity>

    @Query("SELECT * FROM attendance WHERE projectId = :projectId ORDER BY date ASC")
    suspend fun getAttendance(projectId: String): List<AttendanceEntity>

    @Query("SELECT * FROM expenses WHERE projectId = :projectId ORDER BY date DESC, createdAt DESC")
    suspend fun getExpenses(projectId: String): List<ExpenseEntity>

    @Query("SELECT * FROM receipts WHERE projectId = :projectId ORDER BY dateFrom DESC, createdAt DESC")
    suspend fun getReceipts(projectId: String): List<ReceiptEntity>

    @Query("SELECT * FROM payouts WHERE projectId = :projectId ORDER BY date DESC, createdAt DESC")
    suspend fun getPayouts(projectId: String): List<PayoutEntity>

    @Query("SELECT * FROM transfers WHERE projectId = :projectId ORDER BY date DESC, createdAt DESC")
    suspend fun getTransfers(projectId: String): List<TransferEntity>

    @Query("SELECT * FROM adjustments WHERE projectId = :projectId ORDER BY date DESC, createdAt DESC")
    suspend fun getAdjustments(projectId: String): List<AdjustmentEntity>

    @Query("SELECT * FROM categories WHERE projectId = :projectId")
    suspend fun getCategories(projectId: String): List<CategoryEntity>

    // Granular @Upsert & @Delete operations (~0.3 ms per write)
    @Upsert
    suspend fun upsertUser(user: UserEntity)

    @Upsert
    suspend fun upsertUsers(users: List<UserEntity>)

    @Query("DELETE FROM users WHERE projectId = :projectId AND id = :userId")
    suspend fun deleteUserRow(projectId: String, userId: String)

    @Upsert
    suspend fun upsertWage(wage: WageEntity)

    @Upsert
    suspend fun upsertWages(wages: List<WageEntity>)

    @Query("DELETE FROM wages WHERE projectId = :projectId AND id = :wageId")
    suspend fun deleteWage(projectId: String, wageId: String)

    @Upsert
    suspend fun upsertAttendance(attendance: AttendanceEntity)

    @Upsert
    suspend fun upsertAttendances(attendances: List<AttendanceEntity>)

    @Query("DELETE FROM attendance WHERE projectId = :projectId AND date = :date AND userId = :userId")
    suspend fun deleteAttendance(projectId: String, date: String, userId: String)

    @Upsert
    suspend fun upsertCategory(category: CategoryEntity)

    @Upsert
    suspend fun upsertCategories(categories: List<CategoryEntity>)

    @Query("DELETE FROM categories WHERE projectId = :projectId AND id = :categoryId")
    suspend fun deleteCategory(projectId: String, categoryId: String)

    @Upsert
    suspend fun upsertExpense(expense: ExpenseEntity)

    @Upsert
    suspend fun upsertExpenses(expenses: List<ExpenseEntity>)

    @Query("DELETE FROM expenses WHERE projectId = :projectId AND id = :expenseId")
    suspend fun deleteExpense(projectId: String, expenseId: String)

    @Upsert
    suspend fun upsertReceipt(receipt: ReceiptEntity)

    @Upsert
    suspend fun upsertReceipts(receipts: List<ReceiptEntity>)

    @Query("DELETE FROM receipts WHERE projectId = :projectId AND id = :receiptId")
    suspend fun deleteReceipt(projectId: String, receiptId: String)

    @Upsert
    suspend fun upsertPayout(payout: PayoutEntity)

    @Upsert
    suspend fun upsertPayouts(payouts: List<PayoutEntity>)

    @Query("DELETE FROM payouts WHERE projectId = :projectId AND id = :payoutId")
    suspend fun deletePayout(projectId: String, payoutId: String)

    @Upsert
    suspend fun upsertTransfer(transfer: TransferEntity)

    @Upsert
    suspend fun upsertTransfers(transfers: List<TransferEntity>)

    @Query("DELETE FROM transfers WHERE projectId = :projectId AND id = :transferId")
    suspend fun deleteTransfer(projectId: String, transferId: String)

    @Upsert
    suspend fun upsertAdjustment(adjustment: AdjustmentEntity)

    @Upsert
    suspend fun upsertAdjustments(adjustments: List<AdjustmentEntity>)

    @Query("DELETE FROM adjustments WHERE projectId = :projectId AND id = :adjustmentId")
    suspend fun deleteAdjustment(projectId: String, adjustmentId: String)

    // User hard-delete cascade helpers
    @Query("DELETE FROM attendance WHERE projectId = :projectId AND userId = :userId")
    suspend fun deleteAttendanceForUser(projectId: String, userId: String)

    @Query("DELETE FROM wages WHERE projectId = :projectId AND userId = :userId")
    suspend fun deleteWagesForUser(projectId: String, userId: String)

    @Query("DELETE FROM payouts WHERE projectId = :projectId AND userId = :userId")
    suspend fun deletePayoutsForUser(projectId: String, userId: String)

    @Query("DELETE FROM adjustments WHERE projectId = :projectId AND userId = :userId")
    suspend fun deleteAdjustmentsForUser(projectId: String, userId: String)

    @Query("DELETE FROM transfers WHERE projectId = :projectId AND (fromId = :userId OR toId = :userId)")
    suspend fun deleteTransfersForUser(projectId: String, userId: String)

    @Query("UPDATE expenses SET payerId = 'shared' WHERE projectId = :projectId AND payerId = :userId")
    suspend fun reassignExpensesToSharedForUser(projectId: String, userId: String)

    // Financial data reset for a project (keeps users, wages, categories, settings)
    @Query("DELETE FROM attendance WHERE projectId = :projectId")
    suspend fun clearProjectAttendance(projectId: String)

    @Query("DELETE FROM expenses WHERE projectId = :projectId")
    suspend fun clearProjectExpenses(projectId: String)

    @Query("DELETE FROM receipts WHERE projectId = :projectId")
    suspend fun clearProjectReceipts(projectId: String)

    @Query("DELETE FROM payouts WHERE projectId = :projectId")
    suspend fun clearProjectPayouts(projectId: String)

    @Query("DELETE FROM transfers WHERE projectId = :projectId")
    suspend fun clearProjectTransfers(projectId: String)

    @Query("DELETE FROM adjustments WHERE projectId = :projectId")
    suspend fun clearProjectAdjustments(projectId: String)

    @Transaction
    suspend fun hardDeleteUserCascade(projectId: String, userId: String) {
        deleteAttendanceForUser(projectId, userId)
        deleteWagesForUser(projectId, userId)
        deletePayoutsForUser(projectId, userId)
        deleteAdjustmentsForUser(projectId, userId)
        deleteTransfersForUser(projectId, userId)
        reassignExpensesToSharedForUser(projectId, userId)
        deleteUserRow(projectId, userId)
    }

    @Transaction
    suspend fun clearProjectFinancialData(projectId: String) {
        clearProjectAttendance(projectId)
        clearProjectExpenses(projectId)
        clearProjectReceipts(projectId)
        clearProjectPayouts(projectId)
        clearProjectTransfers(projectId)
        clearProjectAdjustments(projectId)
    }

    @Transaction
    suspend fun insertFullProjectGraph(project: Project) {
        // Temporarily insert unlocked so child rows are allowed by period-lock triggers, then lock if needed
        val initiallyLocked = project.settings.locked
        val unlockedProjectEntity = project.copy(
            settings = project.settings.copy(locked = false)
        ).toProjectEntity()
        upsertProject(unlockedProjectEntity)

        if (project.categories.isNotEmpty()) {
            upsertCategories(project.categories.map { it.toEntity(project.id) })
        }
        if (project.users.isNotEmpty()) {
            upsertUsers(project.users.map { it.toEntity(project.id) })
        }
        if (project.wages.isNotEmpty()) {
            upsertWages(project.wages.map { it.toEntity(project.id) })
        }
        val attRows = mutableListOf<AttendanceEntity>()
        for ((date, dayMap) in project.attendance) {
            for ((uid, v) in dayMap) {
                attRows.add(
                    AttendanceEntity(
                        projectId = project.id,
                        date = date,
                        userId = uid,
                        status = v.dbStatus,
                        halfHours = v.dbHalfHours
                    )
                )
            }
        }
        if (attRows.isNotEmpty()) {
            upsertAttendances(attRows)
        }
        if (project.expenses.isNotEmpty()) {
            upsertExpenses(project.expenses.map { it.toEntity(project.id) })
        }
        if (project.receipts.isNotEmpty()) {
            upsertReceipts(project.receipts.map { it.toEntity(project.id) })
        }
        if (project.payouts.isNotEmpty()) {
            upsertPayouts(project.payouts.map { it.toEntity(project.id) })
        }
        if (project.transfers.isNotEmpty()) {
            upsertTransfers(project.transfers.map { it.toEntity(project.id) })
        }
        if (project.adjustments.isNotEmpty()) {
            upsertAdjustments(project.adjustments.map { it.toEntity(project.id) })
        }
        if (initiallyLocked) {
            upsertProject(project.toProjectEntity())
        }
    }

    @Transaction
    suspend fun getFullProjectSnapshot(projectId: String): Project? {
        val p = getProjectEntity(projectId) ?: return null
        return EntityMappers.assembleProject(
            p = p,
            users = getUsers(projectId),
            wages = getWages(projectId),
            attendanceRows = getAttendance(projectId),
            expenses = getExpenses(projectId),
            receipts = getReceipts(projectId),
            payouts = getPayouts(projectId),
            transfers = getTransfers(projectId),
            adjustments = getAdjustments(projectId),
            categories = getCategories(projectId)
        )
    }

    @Transaction
    suspend fun getAllFullProjects(): List<Project> {
        val projects = getAllProjectEntities()
        return projects.mapNotNull { getFullProjectSnapshot(it.id) }
    }

    fun observeProjectSnapshot(projectId: String): Flow<Project?> {
        val flowA = combine(
            observeProjectEntity(projectId),
            observeUsers(projectId),
            observeWages(projectId),
            observeAttendance(projectId),
            observeCategories(projectId)
        ) { p, u, w, a, c ->
             SnapshotPartA(p, u, w, a, c)
        }
        val flowB = combine(
            observeExpenses(projectId),
            observeReceipts(projectId),
            observePayouts(projectId),
            observeTransfers(projectId),
            observeAdjustments(projectId)
        ) { e, r, pay, t, adj ->
            SnapshotPartB(e, r, pay, t, adj)
        }
        return combine(flowA, flowB) { a, b ->
            val p = a.project ?: return@combine null
            EntityMappers.assembleProject(
                p = p,
                users = a.users,
                wages = a.wages,
                attendanceRows = a.attendance,
                expenses = b.expenses,
                receipts = b.receipts,
                payouts = b.payouts,
                transfers = b.transfers,
                adjustments = b.adjustments,
                categories = a.categories
            )
        }
    }
}

private data class SnapshotPartA(
    val project: ProjectEntity?,
    val users: List<UserEntity>,
    val wages: List<WageEntity>,
    val attendance: List<AttendanceEntity>,
    val categories: List<CategoryEntity>
)

private data class SnapshotPartB(
    val expenses: List<ExpenseEntity>,
    val receipts: List<ReceiptEntity>,
    val payouts: List<PayoutEntity>,
    val transfers: List<TransferEntity>,
    val adjustments: List<AdjustmentEntity>
)
