package com.workshop.ledger.presentation.screens.dashboard

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.workshop.ledger.domain.engine.TextNormalizer
import com.workshop.ledger.domain.model.MasterResult
import com.workshop.ledger.presentation.theme.MoneyText
import com.workshop.ledger.presentation.theme.StayarTheme
import com.workshop.ledger.presentation.tutorial.QuestCoordinator
import com.workshop.ledger.presentation.tutorial.questTarget
import kotlin.math.abs

/**
 * Negative-balance settlement matrix («ماتریس تسویه مانده‌های منفی»)
 * with one-tap settle-to-fund («پرداخت به صندوق») or transfer-to-peer («انتقال به اوستای دیگر»).
 */
@Composable
fun NegativeBalanceMatrixSection(
    negativeMasters: List<MasterResult>,
    allMasters: List<MasterResult>,
    onSettleToFund: (master: MasterResult, positiveAmount: Long) -> Unit,
    onTransferToPeer: (debtorMaster: MasterResult, creditorMaster: MasterResult?, positiveAmount: Long) -> Unit,
    questCoordinator: QuestCoordinator? = null
) {
    if (negativeMasters.isEmpty()) return
    val colors = StayarTheme.colors
    val digitsMode = StayarTheme.digitsMode
    var confirmSettleMaster by remember { mutableStateOf<MasterResult?>(null) }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
            text = "ماتریس تسویه مانده‌های منفی",
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = colors.danger
        )

        for (debtor in negativeMasters) {
            val debtAmount = abs(debtor.finalBalance)
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = colors.danger.copy(alpha = 0.08f),
                border = BorderStroke(colors.defaultBorderWidth, colors.danger),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = debtor.name,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = colors.text
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "بدهکار به کارگاه: ",
                                fontSize = 13.sp,
                                color = colors.danger,
                                fontWeight = FontWeight.SemiBold
                            )
                            MoneyText(
                                amount = debtAmount,
                                showUnit = true,
                                color = colors.danger,
                                fontSize = 14.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { confirmSettleMaster = debtor },
                            colors = ButtonDefaults.buttonColors(containerColor = colors.accent),
                            modifier = Modifier
                                .weight(1f)
                                .questTarget("negative_matrix_settle", questCoordinator)
                        ) {
                            Text(
                                text = "پرداخت به صندوق",
                                color = colors.onAccent,
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        OutlinedButton(
                            onClick = {
                                val peer = allMasters
                                    .filter { it.id != debtor.id }
                                    .maxByOrNull { it.finalBalance }
                                onTransferToPeer(debtor, peer, debtAmount)
                            },
                            border = BorderStroke(colors.defaultBorderWidth, colors.borderStrong),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = "انتقال به اوستای دیگر",
                                color = colors.text,
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }
    }

    if (confirmSettleMaster != null) {
        val m = confirmSettleMaster!!
        val amt = abs(m.finalBalance)
        val amtText = TextNormalizer.fmtDisplay(amt, digitsMode)
        AlertDialog(
            onDismissRequest = { confirmSettleMaster = null },
            containerColor = colors.bgElev,
            title = {
                Text("پرداخت به صندوق", fontWeight = FontWeight.Bold, color = colors.text)
            },
            text = {
                Text(
                    text = "«${m.name}» مبلغ $amtText تومان نقد به صندوق پرداخت می‌کند و یک «تسویه نقدی» ثبت می‌شود تا ترازش صفر شود.",
                    color = colors.text
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        confirmSettleMaster = null
                        onSettleToFund(m, amt)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = colors.accent)
                ) {
                    Text("ثبت تسویه", color = colors.onAccent, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { confirmSettleMaster = null }) {
                    Text("انصراف", color = colors.text)
                }
            }
        )
    }
}
