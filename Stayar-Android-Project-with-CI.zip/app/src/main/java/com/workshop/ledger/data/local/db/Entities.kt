package com.workshop.ledger.data.local.db

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import com.workshop.ledger.domain.model.Adjustment
import com.workshop.ledger.domain.model.AttendanceValue
import com.workshop.ledger.domain.model.Category
import com.workshop.ledger.domain.model.Expense
import com.workshop.ledger.domain.model.Payout
import com.workshop.ledger.domain.model.Project
import com.workshop.ledger.domain.model.ProjectSettings
import com.workshop.ledger.domain.model.Receipt
import com.workshop.ledger.domain.model.Transfer
import com.workshop.ledger.domain.model.User
import com.workshop.ledger.domain.model.UserType
import com.workshop.ledger.domain.model.Wage

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey val id: String,
    val name: String,
    val createdAt: Long,
    val rangeFrom: String,
    val rangeTo: String,
    val theme: String,
    val overtimeFactor: Double,
    val absentPenalty: Double,
    val profitBasis: String,
    val locked: Boolean,
    @ColumnInfo(defaultValue = "2") val calcVersion: Int = 2
)

@Entity(
    tableName = "users",
    primaryKeys = ["projectId", "id"],
    foreignKeys = [
        ForeignKey(
            entity = ProjectEntity::class,
            parentColumns = ["id"],
            childColumns = ["projectId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["projectId"])]
)
data class UserEntity(
    val projectId: String,
    val id: String,
    val name: String,
    val role: String,
    val type: String,
    val workFactor: Double,
    val active: Boolean,
    val main: Boolean,
    val createdAt: Long,
    val deletedAt: Long? = null
)

@Entity(
    tableName = "wages",
    primaryKeys = ["projectId", "id"],
    foreignKeys = [
        ForeignKey(
            entity = ProjectEntity::class,
            parentColumns = ["id"],
            childColumns = ["projectId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["projectId"]),
        Index(value = ["projectId", "userId"])
    ]
)
data class WageEntity(
    val projectId: String,
    val id: String,
    val userId: String,
    val rate: Long,
    val effectiveDate: String
)

@Entity(
    tableName = "attendance",
    primaryKeys = ["projectId", "date", "userId"],
    foreignKeys = [
        ForeignKey(
            entity = ProjectEntity::class,
            parentColumns = ["id"],
            childColumns = ["projectId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["projectId"]),
        Index(value = ["projectId", "date"])
    ]
)
data class AttendanceEntity(
    val projectId: String,
    val date: String,
    val userId: String,
    val status: Int, // 0=Absent, 1=Full, 2=Half, 3=Hourly
    val halfHours: Int // 0..48
)

@Entity(
    tableName = "categories",
    primaryKeys = ["projectId", "id"],
    foreignKeys = [
        ForeignKey(
            entity = ProjectEntity::class,
            parentColumns = ["id"],
            childColumns = ["projectId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["projectId"])]
)
data class CategoryEntity(
    val projectId: String,
    val id: String,
    val name: String
)

@Entity(
    tableName = "expenses",
    primaryKeys = ["projectId", "id"],
    foreignKeys = [
        ForeignKey(
            entity = ProjectEntity::class,
            parentColumns = ["id"],
            childColumns = ["projectId"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = CategoryEntity::class,
            parentColumns = ["projectId", "id"],
            childColumns = ["projectId", "categoryId"],
            onDelete = ForeignKey.SET_NULL
        )
    ],
    indices = [
        Index(value = ["projectId", "date"]),
        Index(value = ["projectId", "categoryId"]),
        Index(value = ["projectId", "payerId"])
    ]
)
data class ExpenseEntity(
    val projectId: String,
    val id: String,
    val date: String,
    val description: String,
    val categoryId: String?,
    val payerId: String,
    val amount: Long,
    val active: Boolean,
    val createdAt: Long,
    val updatedAt: Long
)

@Entity(
    tableName = "receipts",
    primaryKeys = ["projectId", "id"],
    foreignKeys = [
        ForeignKey(
            entity = ProjectEntity::class,
            parentColumns = ["id"],
            childColumns = ["projectId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["projectId", "dateFrom"])]
)
data class ReceiptEntity(
    val projectId: String,
    val id: String,
    val dateFrom: String,
    val dateTo: String,
    val amount: Long,
    val description: String,
    val active: Boolean,
    val createdAt: Long,
    val updatedAt: Long
)

@Entity(
    tableName = "payouts",
    primaryKeys = ["projectId", "id"],
    foreignKeys = [
        ForeignKey(
            entity = ProjectEntity::class,
            parentColumns = ["id"],
            childColumns = ["projectId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["projectId", "date"]),
        Index(value = ["projectId", "userId"])
    ]
)
data class PayoutEntity(
    val projectId: String,
    val id: String,
    val date: String,
    val userId: String,
    val amount: Long,
    val description: String,
    val active: Boolean,
    val createdAt: Long,
    val updatedAt: Long
)

@Entity(
    tableName = "transfers",
    primaryKeys = ["projectId", "id"],
    foreignKeys = [
        ForeignKey(
            entity = ProjectEntity::class,
            parentColumns = ["id"],
            childColumns = ["projectId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["projectId", "date"])]
)
data class TransferEntity(
    val projectId: String,
    val id: String,
    val date: String,
    val fromId: String?,
    val toId: String,
    val amount: Long,
    val description: String,
    val kind: String,
    val active: Boolean,
    val createdAt: Long,
    val updatedAt: Long
)

@Entity(
    tableName = "adjustments",
    primaryKeys = ["projectId", "id"],
    foreignKeys = [
        ForeignKey(
            entity = ProjectEntity::class,
            parentColumns = ["id"],
            childColumns = ["projectId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["projectId", "date"]),
        Index(value = ["projectId", "userId"])
    ]
)
data class AdjustmentEntity(
    val projectId: String,
    val id: String,
    val date: String,
    val userId: String,
    val kind: String,
    val amount: Long,
    val description: String,
    val active: Boolean,
    val createdAt: Long,
    val updatedAt: Long
)

object EntityMappers {

    fun Project.toProjectEntity(): ProjectEntity = ProjectEntity(
        id = id,
        name = name,
        createdAt = createdAt,
        rangeFrom = settings.rangeFrom,
        rangeTo = settings.rangeTo,
        theme = settings.theme,
        overtimeFactor = settings.overtimeFactor,
        absentPenalty = settings.absentPenalty,
        profitBasis = settings.profitBasis,
        locked = settings.locked,
        calcVersion = settings.calcVersion
    )

    fun User.toEntity(projectId: String): UserEntity = UserEntity(
        projectId = projectId,
        id = id,
        name = name,
        role = role,
        type = type.key,
        workFactor = workFactor,
        active = active,
        main = main,
        createdAt = createdAt,
        deletedAt = deletedAt
    )

    fun UserEntity.toDomain(): User = User(
        id = id,
        name = name,
        role = role,
        type = UserType.fromKey(type),
        workFactor = workFactor,
        active = active,
        main = main,
        createdAt = createdAt,
        deletedAt = deletedAt
    )

    fun Wage.toEntity(projectId: String): WageEntity = WageEntity(
        projectId = projectId,
        id = id,
        userId = userId,
        rate = rate,
        effectiveDate = effectiveDate
    )

    fun WageEntity.toDomain(): Wage = Wage(
        id = id,
        userId = userId,
        rate = rate,
        effectiveDate = effectiveDate
    )

    fun Category.toEntity(projectId: String): CategoryEntity = CategoryEntity(
        projectId = projectId,
        id = id,
        name = name
    )

    fun CategoryEntity.toDomain(): Category = Category(
        id = id,
        name = name
    )

    fun Expense.toEntity(projectId: String): ExpenseEntity = ExpenseEntity(
        projectId = projectId,
        id = id,
        date = date,
        description = description,
        categoryId = categoryId,
        payerId = payerId,
        amount = amount,
        active = active,
        createdAt = createdAt,
        updatedAt = updatedAt
    )

    fun ExpenseEntity.toDomain(): Expense = Expense(
        id = id,
        date = date,
        amount = amount,
        description = description,
        categoryId = categoryId,
        payerId = payerId,
        active = active,
        createdAt = createdAt,
        updatedAt = updatedAt
    )

    fun Receipt.toEntity(projectId: String): ReceiptEntity = ReceiptEntity(
        projectId = projectId,
        id = id,
        dateFrom = dateFrom,
        dateTo = dateTo,
        amount = amount,
        description = description,
        active = active,
        createdAt = createdAt,
        updatedAt = updatedAt
    )

    fun ReceiptEntity.toDomain(): Receipt = Receipt(
        id = id,
        dateFrom = dateFrom,
        dateTo = dateTo,
        amount = amount,
        description = description,
        active = active,
        createdAt = createdAt,
        updatedAt = updatedAt
    )

    fun Payout.toEntity(projectId: String): PayoutEntity = PayoutEntity(
        projectId = projectId,
        id = id,
        date = date,
        userId = userId,
        amount = amount,
        description = description,
        active = active,
        createdAt = createdAt,
        updatedAt = updatedAt
    )

    fun PayoutEntity.toDomain(): Payout = Payout(
        id = id,
        date = date,
        userId = userId,
        amount = amount,
        description = description,
        active = active,
        createdAt = createdAt,
        updatedAt = updatedAt
    )

    fun Transfer.toEntity(projectId: String): TransferEntity = TransferEntity(
        projectId = projectId,
        id = id,
        date = date,
        fromId = fromId,
        toId = toId,
        amount = amount,
        description = description,
        kind = kind,
        active = active,
        createdAt = createdAt,
        updatedAt = updatedAt
    )

    fun TransferEntity.toDomain(): Transfer = Transfer(
        id = id,
        date = date,
        kind = kind,
        fromId = fromId,
        toId = toId,
        amount = amount,
        description = description,
        active = active,
        createdAt = createdAt,
        updatedAt = updatedAt
    )

    fun Adjustment.toEntity(projectId: String): AdjustmentEntity = AdjustmentEntity(
        projectId = projectId,
        id = id,
        date = date,
        userId = userId,
        kind = kind,
        amount = amount,
        description = description,
        active = active,
        createdAt = createdAt,
        updatedAt = updatedAt
    )

    fun AdjustmentEntity.toDomain(): Adjustment = Adjustment(
        id = id,
        date = date,
        userId = userId,
        kind = kind,
        amount = amount,
        description = description,
        active = active,
        createdAt = createdAt,
        updatedAt = updatedAt
    )

    fun assembleProject(
        p: ProjectEntity,
        users: List<UserEntity>,
        wages: List<WageEntity>,
        attendanceRows: List<AttendanceEntity>,
        expenses: List<ExpenseEntity>,
        receipts: List<ReceiptEntity>,
        payouts: List<PayoutEntity>,
        transfers: List<TransferEntity>,
        adjustments: List<AdjustmentEntity>,
        categories: List<CategoryEntity>
    ): Project {
        val attMap = LinkedHashMap<String, MutableMap<String, AttendanceValue>>()
        for (row in attendanceRows) {
            val v = AttendanceValue.fromDb(row.status, row.halfHours) ?: continue
            val dayMap = attMap.getOrPut(row.date) { LinkedHashMap() }
            dayMap[row.userId] = v
        }

        return Project(
            id = p.id,
            name = p.name,
            createdAt = p.createdAt,
            settings = ProjectSettings(
                rangeFrom = p.rangeFrom,
                rangeTo = p.rangeTo,
                theme = p.theme,
                overtimeFactor = p.overtimeFactor,
                absentPenalty = p.absentPenalty,
                profitBasis = p.profitBasis,
                locked = p.locked,
                calcVersion = p.calcVersion
            ),
            users = users.map { it.toDomain() },
            wages = wages.map { it.toDomain() },
            attendance = attMap,
            expenses = expenses.map { it.toDomain() },
            receipts = receipts.map { it.toDomain() },
            payouts = payouts.map { it.toDomain() },
            transfers = transfers.map { it.toDomain() },
            adjustments = adjustments.map { it.toDomain() },
            categories = categories.map { it.toDomain() }
        )
    }
}
