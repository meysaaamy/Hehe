package com.workshop.ledger.presentation.screens.projects

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.workshop.ledger.data.local.db.ProjectEntity
import com.workshop.ledger.domain.engine.TextNormalizer
import com.workshop.ledger.presentation.components.BadgePill
import com.workshop.ledger.presentation.components.TactileSheet
import com.workshop.ledger.presentation.theme.StayarTheme

/**
 * Projects Screen (`«پروژه‌ها»`, Section 12-13).
 * Supports:
 * - Switching active project
 * - Creating a new project (`«پروژه جدید»`, placeholder `«مثلاً ساختمان مسکونی گلستان»`, submit `«ساخت پروژه»`, max 100 limit)
 * - Renaming project (`«تغییر نام پروژه»`)
 * - Cloning structure (`«تکثیر ساختار»`: copies users, wages, categories, resets settings, leaves financial records zero)
 * - Two-step typed-confirmation Delete (`«حذف همیشگی»`, last project protected)
 * - Deterministic Sample Project creation (`«ساخت پروژه نمونه»`)
 */
@Composable
fun ProjectsScreen(
    allProjects: List<ProjectEntity>,
    activeProjectId: String,
    onSelectProject: (String) -> Unit,
    onCreateProject: (name: String) -> Unit,
    onRenameProject: (newName: String) -> Unit,
    onCloneStructure: (sourceProjectId: String) -> Unit,
    onDeleteProject: (projectId: String) -> Unit,
    onCreateSampleProject: () -> Unit
) {
    val colors = StayarTheme.colors
    val digitsMode = StayarTheme.digitsMode
    val f = { s: String -> TextNormalizer.formatDisplayDigits(s, digitsMode) }

    var showCreateSheet by remember { mutableStateOf(false) }
    var newProjectName by remember { mutableStateOf("") }

    var renamingProject by remember { mutableStateOf<ProjectEntity?>(null) }
    var renameInputName by remember { mutableStateOf("") }

    var step1DeleteProject by remember { mutableStateOf<ProjectEntity?>(null) }
    var step2DeleteProject by remember { mutableStateOf<ProjectEntity?>(null) }
    var typedConfirmationName by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Intro Card
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(colors.bgElev)
                .border(1.dp, colors.borderStrong, RoundedCornerShape(16.dp))
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = "مدیریت پروژه‌ها و کارگاه‌ها",
                fontWeight = FontWeight.ExtraBold,
                fontSize = 17.sp,
                color = colors.text
            )
            Text(
                text = "هر پروژه (ساختمان یا کار مستقل) حساب، کاربران و تنظیمات جدا دارد. «تکثیر ساختار» فقط اوستاها، شاگردها، ضرایب، نرخ‌ها و دسته‌ها را کپی می‌کند و داده‌های مالی را صفر می‌گذارد.",
                fontSize = 12.sp,
                lineHeight = 18.sp,
                color = colors.textDim
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        newProjectName = ""
                        showCreateSheet = true
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = colors.accent,
                        contentColor = colors.onAccent
                    ),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("+ پروژه جدید", fontWeight = FontWeight.Bold)
                }
                OutlinedButton(
                    onClick = onCreateSampleProject,
                    modifier = Modifier.weight(1f)
                ) {
                    Text("ساخت پروژه نمونه", fontWeight = FontWeight.Bold)
                }
            }
        }

        // Projects List
        Text(
            text = "فهرست پروژه‌ها (${f(allProjects.size.toString())} از ۱۰۰)",
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            color = colors.textDim
        )

        allProjects.forEach { proj ->
            val isActive = proj.id == activeProjectId
            val isSandbox = proj.id.startsWith("demo_quest_")

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(if (isActive) colors.accent.copy(alpha = 0.08f) else colors.bgElev)
                    .border(
                        width = if (isActive) 2.dp else 1.dp,
                        color = if (isActive) colors.accent else colors.border,
                        shape = RoundedCornerShape(14.dp)
                    )
                    .clickable { onSelectProject(proj.id) }
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = f(proj.name),
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 15.sp,
                            color = colors.text
                        )
                        if (isSandbox) {
                            BadgePill(text = "تمرینی", color = colors.warn)
                        }
                        if (isActive) {
                            BadgePill(text = "فعال", color = colors.accent)
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            renamingProject = proj
                            renameInputName = proj.name
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("تغییر نام", fontSize = 12.sp)
                    }

                    OutlinedButton(
                        onClick = { onCloneStructure(proj.id) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("تکثیر ساختار", fontSize = 12.sp)
                    }

                    OutlinedButton(
                        onClick = { step1DeleteProject = proj },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = colors.danger),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("حذف", fontSize = 12.sp)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(48.dp))
    }

    // Sheet: Create Project
    if (showCreateSheet) {
        TactileSheet(
            title = "پروژه جدید",
            onDismiss = { showCreateSheet = false }
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = newProjectName,
                    onValueChange = { if (it.length <= 80) newProjectName = it },
                    label = { Text("نام پروژه") },
                    placeholder = { Text("مثلاً ساختمان مسکونی گلستان") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Button(
                    onClick = {
                        val trimmed = newProjectName.trim()
                        if (trimmed.isNotEmpty()) {
                            onCreateProject(trimmed)
                            showCreateSheet = false
                        }
                    },
                    enabled = newProjectName.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = colors.accent,
                        contentColor = colors.onAccent
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("ساخت پروژه", fontWeight = FontWeight.Bold)
                }
            }
        }
    }

    // Sheet: Rename Project
    renamingProject?.let { proj ->
        TactileSheet(
            title = "تغییر نام پروژه",
            onDismiss = { renamingProject = null }
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = renameInputName,
                    onValueChange = { if (it.length <= 80) renameInputName = it },
                    label = { Text("نام جدید پروژه") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Button(
                    onClick = {
                        val trimmed = renameInputName.trim()
                        if (trimmed.isNotEmpty()) {
                            onRenameProject(trimmed)
                            renamingProject = null
                        }
                    },
                    enabled = renameInputName.isNotBlank() && renameInputName != proj.name,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = colors.accent,
                        contentColor = colors.onAccent
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("تغییر نام پروژه", fontWeight = FontWeight.Bold)
                }
            }
        }
    }

    // Delete Step 1: Danger Confirm Dialog
    step1DeleteProject?.let { proj ->
        AlertDialog(
            onDismissRequest = { step1DeleteProject = null },
            title = { Text("حذف پروژه") },
            text = { Text("پروژه «${proj.name}» (مرحله ۱ از ۲). با تمام اطلاعاتش حذف می‌شود. ادامه می‌دهید؟") },
            confirmButton = {
                Button(
                    onClick = {
                        step2DeleteProject = proj
                        typedConfirmationName = ""
                        step1DeleteProject = null
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = colors.danger,
                        contentColor = colors.onAccent
                    )
                ) {
                    Text("ادامه؛ مرحله ۲")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { step1DeleteProject = null }) {
                    Text("انصراف")
                }
            }
        )
    }

    // Delete Step 2: Typed Name Confirmation
    step2DeleteProject?.let { proj ->
        TactileSheet(
            title = "تأیید نهایی حذف پروژه (مرحله ۲ از ۲)",
            onDismiss = { step2DeleteProject = null }
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "برای تأیید حذف همیشگی، نام دقیق پروژه یعنی «${proj.name}» را عیناً در کادر زیر بنویسید:",
                    fontSize = 13.sp,
                    lineHeight = 20.sp,
                    color = colors.text
                )
                OutlinedTextField(
                    value = typedConfirmationName,
                    onValueChange = { typedConfirmationName = it },
                    label = { Text("نام پروژه") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                val matches = typedConfirmationName.trim() == proj.name.trim()
                Button(
                    onClick = {
                        if (matches) {
                            onDeleteProject(proj.id)
                            step2DeleteProject = null
                        }
                    },
                    enabled = matches,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = colors.danger,
                        contentColor = colors.onAccent
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("حذف همیشگی", fontWeight = FontWeight.ExtraBold)
                }
            }
        }
    }
}
