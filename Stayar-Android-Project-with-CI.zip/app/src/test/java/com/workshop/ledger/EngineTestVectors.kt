package com.workshop.ledger

import com.workshop.ledger.domain.engine.AccountingEngine
import com.workshop.ledger.domain.engine.DigitsMode
import com.workshop.ledger.domain.engine.JalaliCalendarEngine
import com.workshop.ledger.domain.engine.PersianMoneyWords
import com.workshop.ledger.domain.engine.StatementBuilder
import com.workshop.ledger.domain.engine.TextNormalizer
import com.workshop.ledger.domain.model.Adjustment
import com.workshop.ledger.domain.model.AttendanceValue
import com.workshop.ledger.domain.model.Expense
import com.workshop.ledger.domain.model.JalaliDate
import com.workshop.ledger.domain.model.Payout
import com.workshop.ledger.domain.model.Project
import com.workshop.ledger.domain.model.ProjectSettings
import com.workshop.ledger.domain.model.Receipt
import com.workshop.ledger.domain.model.ReportRange
import com.workshop.ledger.domain.model.Transfer
import com.workshop.ledger.domain.model.User
import com.workshop.ledger.domain.model.UserType
import com.workshop.ledger.domain.model.Wage
import com.workshop.ledger.domain.tutorial.PracticeSandboxSeeder
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class EngineTestVectors {

    @Test
    fun testAttFractionVectors() {
        assertEquals(1.0, AccountingEngine.attFraction(AttendanceValue.Full, 1.0)!!, 1e-9)
        assertEquals(0.5, AccountingEngine.attFraction(AttendanceValue.Half, 1.0)!!, 1e-9)
        assertEquals(0.0, AccountingEngine.attFraction(AttendanceValue.Absent, 1.0)!!, 1e-9)
        assertEquals(0.75, AccountingEngine.attFraction(AttendanceValue.Hourly(6.0), 1.0)!!, 1e-9)
        assertEquals(1.0, AccountingEngine.attFraction(AttendanceValue.Hourly(8.0), 1.0)!!, 1e-9)
        assertEquals(1.25, AccountingEngine.attFraction(AttendanceValue.Hourly(10.0), 1.0)!!, 1e-9)
        assertEquals(1.375, AccountingEngine.attFraction(AttendanceValue.Hourly(10.0), 1.5)!!, 1e-9)
        assertEquals(2.0, AccountingEngine.attFraction(AttendanceValue.Hourly(12.0), 2.0)!!, 1e-9)
        assertEquals(3.0, AccountingEngine.attFraction(AttendanceValue.Hourly(24.0), 1.0)!!, 1e-9)
        assertNull(AccountingEngine.attFraction(AttendanceValue.Hourly(25.0), 1.0))
    }

    @Test
    fun testAllocateVectors() {
        assertArrayEquals(longArrayOf(34L, 33L, 33L), AccountingEngine.allocate(100L, listOf(1.0, 1.0, 1.0)))
        assertArrayEquals(longArrayOf(-34L, -33L, -33L), AccountingEngine.allocate(-100L, listOf(1.0, 1.0, 1.0)))
        assertArrayEquals(longArrayOf(750L, 250L), AccountingEngine.allocate(1000L, listOf(3.0, 1.0)))
        assertArrayEquals(longArrayOf(0L, 0L), AccountingEngine.allocate(10L, listOf(0.0, 0.0)))
        assertArrayEquals(longArrayOf(2L, 2L, 1L), AccountingEngine.allocate(5L, listOf(2.0, 2.0, 1.0)))
        assertArrayEquals(longArrayOf(5L, 2L), AccountingEngine.allocate(7L, listOf(1.5, 0.5)))
    }

    @Test
    fun testReceiptShareVectors() {
        val r30m = Receipt(
            id = "r1",
            dateFrom = "1402/05/01",
            dateTo = "1402/05/30",
            amount = 30_000_000L
        )
        val r10m = Receipt(
            id = "r2",
            dateFrom = "1405/07/20",
            dateTo = "1405/08/09",
            amount = 10_000_000L
        )
        for (calcVer in listOf(1, 2)) {
            assertEquals(30_000_000L, AccountingEngine.receiptShare(r30m, ReportRange("", ""), calcVer))
            assertEquals(10_000_000L, AccountingEngine.receiptShare(r30m, ReportRange("1402/05/01", "1402/05/10"), calcVer))
            assertEquals(20_000_000L, AccountingEngine.receiptShare(r30m, ReportRange("1402/05/11", "1402/05/30"), calcVer))
            assertEquals(0L, AccountingEngine.receiptShare(r30m, ReportRange("1402/06/01", "1402/06/30"), calcVer))
            assertEquals(4_500_000L, AccountingEngine.receiptShare(r10m, ReportRange("1405/08/01", "1405/08/30"), calcVer))
        }
    }

    @Test
    fun testNumToFaWordVectors() {
        assertEquals("صفر تومان", PersianMoneyWords.numToFaWord(0L))
        assertEquals("پنج تومان", PersianMoneyWords.numToFaWord(5L))
        assertEquals("ده تومان", PersianMoneyWords.numToFaWord(10L))
        assertEquals("یازده تومان", PersianMoneyWords.numToFaWord(11L))
        assertEquals("نوزده تومان", PersianMoneyWords.numToFaWord(19L))
        assertEquals("بیست تومان", PersianMoneyWords.numToFaWord(20L))
        assertEquals("بیست و یک تومان", PersianMoneyWords.numToFaWord(21L))
        assertEquals("صد تومان", PersianMoneyWords.numToFaWord(100L))
        assertEquals("صد و یک تومان", PersianMoneyWords.numToFaWord(101L))
        assertEquals("سیصد و پنجاه تومان", PersianMoneyWords.numToFaWord(350L))
        assertEquals("هزار تومان", PersianMoneyWords.numToFaWord(1_000L))
        assertEquals("هزار و پانصد تومان", PersianMoneyWords.numToFaWord(1_500L))
        assertEquals("سیصد و پنجاه هزار تومان", PersianMoneyWords.numToFaWord(350_000L))
        assertEquals("دو میلیون و پانصد هزار تومان", PersianMoneyWords.numToFaWord(2_500_000L))
        assertEquals(
            "دوازده میلیون و سیصد و چهل و پنج هزار و ششصد و هفتاد و هشت تومان",
            PersianMoneyWords.numToFaWord(12_345_678L)
        )
        assertEquals("یک میلیارد تومان", PersianMoneyWords.numToFaWord(1_000_000_000L))
        assertEquals(
            "نهصد و نود و نه میلیارد و نهصد و نود و نه میلیون و نهصد و نود و نه هزار و نهصد و نود و نه تومان",
            PersianMoneyWords.numToFaWord(999_999_999_999L)
        )
        assertEquals("منفی هزار و پانصد تومان", PersianMoneyWords.numToFaWord(-1_500L))
    }

    @Test
    fun testParseMoneyVectors() {
        val c1 = PersianMoneyWords.parseMoney("۱۲۳٬۴۵۶")
        assertEquals(123_456L, c1.v)
        assertTrue(c1.has)
        assertFalse(c1.dec)
        assertFalse(c1.clamped)

        val c2 = PersianMoneyWords.parseMoney("1,234.50")
        assertEquals(1_234L, c2.v)
        assertTrue(c2.has)
        assertTrue(c2.dec)

        val c3 = PersianMoneyWords.parseMoney("0012")
        assertEquals(12L, c3.v)

        val c4 = PersianMoneyWords.parseMoney("")
        assertEquals(0L, c4.v)
        assertFalse(c4.has)

        val c5 = PersianMoneyWords.parseMoney("99999999999999")
        assertEquals(999_999_999_999L, c5.v)
        assertTrue(c5.clamped)
    }

    @Test
    fun testFormattingVectors() {
        assertEquals("1,234,567", TextNormalizer.fmt(1234567))
        assertEquals("-1,234,567", TextNormalizer.fmt(-1234567))
        assertEquals("1,000", TextNormalizer.fmt(999.5))
        assertEquals("1.25", TextNormalizer.fmtDays(1.25))
        assertEquals("2", TextNormalizer.fmtDays(2))
        assertEquals("0.33", TextNormalizer.fmtDays(0.3333))
        assertEquals("-0.5", TextNormalizer.fmtDays(-0.5))
        assertEquals("50", TextNormalizer.pctText(0.5))
        assertEquals("33.3", TextNormalizer.pctText(0.3333))
        assertEquals("100", TextNormalizer.pctText(1))
    }

    @Test
    fun testJalaliVectors() {
        assertEquals("1403/01/01", JalaliCalendarEngine.gregorianToJalali(2024, 3, 20).toFormattedString())
        assertEquals("1404/01/01", JalaliCalendarEngine.gregorianToJalali(2025, 3, 21).toFormattedString())
        assertEquals("1404/10/11", JalaliCalendarEngine.gregorianToJalali(2026, 1, 1).toFormattedString())
        assertEquals("1405/08/13", JalaliCalendarEngine.gregorianToJalali(2026, 11, 4).toFormattedString())
        assertEquals("چهارشنبه", JalaliCalendarEngine.jDowStr("1405/08/13"))
        assertEquals("13 آبان 1405", JalaliCalendarEngine.jHuman("1405/08/13", DigitsMode.EN))
        assertEquals(30, JalaliCalendarEngine.jalaaliMonthLength(1403, 12))
        assertEquals(29, JalaliCalendarEngine.jalaaliMonthLength(1404, 12))
        assertEquals(31, JalaliCalendarEngine.jalaaliMonthLength(1404, 6))
        assertEquals(30, JalaliCalendarEngine.jalaaliMonthLength(1404, 7))
        assertTrue(JalaliCalendarEngine.isLeapJalaaliYear(1403))
        assertFalse(JalaliCalendarEngine.isLeapJalaaliYear(1404))
        assertEquals("1406/01/02", JalaliCalendarEngine.jAddDays("1405/12/29", 2))
        assertEquals("1406/01", JalaliCalendarEngine.jAddMonths("1405/12", 1))
        assertEquals(228L, JalaliCalendarEngine.jDaysBetween("1405/01/01", "1405/08/13"))
        assertEquals(JalaliDate.of(1405, 8, 13), JalaliCalendarEngine.jParse("۱۳/۸/۱۴۰۵"))
        assertNull(JalaliCalendarEngine.jParse("1405/13/01"))
    }

    private fun buildScenarioS1Project(
        profitBasis: String = "cash",
        overtimeFactor: Double = 1.0,
        absentPenalty: Double = 0.5,
        rangeFrom: String = "1405/08/01",
        rangeTo: String = "1405/08/30",
        calcVersion: Int = 2
    ): Project {
        val users = listOf(
            User(id = "m1", name = "M1", type = UserType.MASTER, main = true, workFactor = 1.0),
            User(id = "m2", name = "M2", type = UserType.MASTER, main = false, workFactor = 0.8),
            User(id = "a1", name = "A1", type = UserType.APPRENTICE),
            User(id = "c1", name = "C1", type = UserType.CUSTOM)
        )
        val wages = listOf(
            Wage(id = "w1", userId = "a1", rate = 1_300_000L, effectiveDate = "1405/07/01"),
            Wage(id = "w2", userId = "a1", rate = 1_500_000L, effectiveDate = "1405/08/12"),
            Wage(id = "w3", userId = "c1", rate = 900_000L, effectiveDate = "1405/08/01")
        )
        val attendance = mapOf(
            "1405/08/10" to mapOf(
                "m1" to AttendanceValue.Full,
                "m2" to AttendanceValue.Half,
                "a1" to AttendanceValue.Full,
                "c1" to AttendanceValue.Hourly(10.0)
            ),
            "1405/08/11" to mapOf(
                "m1" to AttendanceValue.Full,
                "m2" to AttendanceValue.Full,
                "a1" to AttendanceValue.Absent,
                "c1" to AttendanceValue.Full
            ),
            "1405/08/12" to mapOf(
                "m1" to AttendanceValue.Hourly(6.0),
                "m2" to AttendanceValue.Full,
                "a1" to AttendanceValue.Full,
                "c1" to AttendanceValue.Half
            ),
            "1405/08/13" to mapOf(
                "m1" to AttendanceValue.Full,
                "m2" to AttendanceValue.Absent,
                "a1" to AttendanceValue.Hourly(9.0)
            )
        )
        val receipts = listOf(
            Receipt(id = "r1", dateFrom = "1405/08/01", dateTo = "1405/08/20", amount = 20_000_000L, active = true),
            Receipt(id = "r2", dateFrom = "1405/07/20", dateTo = "1405/08/09", amount = 10_000_000L, active = true),
            Receipt(id = "r3", dateFrom = "1405/08/01", dateTo = "1405/08/10", amount = 777_777L, active = false)
        )
        val expenses = listOf(
            Expense(id = "e1", date = "1405/08/05", amount = 3_000_000L, description = "shared", payerId = "shared", active = true),
            Expense(id = "e2", date = "1405/08/07", amount = 700_000L, description = "personal m2", payerId = "m2", active = true),
            Expense(id = "e3", date = "1405/08/08", amount = 999_999L, description = "inactive", payerId = "shared", active = false),
            Expense(id = "e4", date = "1405/07/25", amount = 111_111L, description = "before", payerId = "shared", active = true)
        )
        val payouts = listOf(
            Payout(id = "p1", date = "1405/08/15", userId = "a1", amount = 2_000_000L, active = true),
            Payout(id = "p2", date = "1405/08/16", userId = "c1", amount = 500_000L, active = true),
            Payout(id = "p3", date = "1405/08/16", userId = "m1", amount = 123_456L, active = true)
        )
        val transfers = listOf(
            Transfer(id = "t1", date = "1405/08/17", kind = "peer", fromId = "m1", toId = "m2", amount = 300_000L, active = true),
            Transfer(id = "t2", date = "1405/08/18", kind = "advance", fromId = null, toId = "m2", amount = 1_000_000L, active = true)
        )
        val adjustments = listOf(
            Adjustment(id = "adj1", date = "1405/08/19", userId = "a1", kind = "bonus", amount = 200_000L, active = true),
            Adjustment(id = "adj2", date = "1405/08/19", userId = "c1", kind = "penalty", amount = 100_000L, active = true),
            Adjustment(id = "adj3", date = "1405/08/19", userId = "c1", kind = "assistance", amount = 150_000L, active = true),
            Adjustment(id = "adj4", date = "1405/08/20", userId = "m1", kind = "bonus", amount = 250_000L, active = true),
            Adjustment(id = "adj5", date = "1405/08/20", userId = "m2", kind = "settle", amount = 50_000L, active = true)
        )
        return Project(
            id = "p_s1",
            name = "Test",
            settings = ProjectSettings(
                rangeFrom = rangeFrom,
                rangeTo = rangeTo,
                overtimeFactor = overtimeFactor,
                absentPenalty = absentPenalty,
                profitBasis = profitBasis,
                calcVersion = calcVersion
            ),
            users = users,
            wages = wages,
            attendance = attendance,
            receipts = receipts,
            expenses = expenses,
            payouts = payouts,
            transfers = transfers,
            adjustments = adjustments
        )
    }

    @Test
    fun testScenarioS1CashBothCalcVersions() {
        for (calcVer in listOf(1, 2)) {
            val p = buildScenarioS1Project(profitBasis = "cash", calcVersion = calcVer)
            val r = AccountingEngine.compute(p)

            assertEquals(24_500_000L, r.totalReceipts)
            assertEquals(3_000_000L, r.sharedExpenses)
            assertEquals(700_000L, r.personalExpTotal)
            assertEquals(6_412_500L, r.totalWages)
            assertEquals(2_500_000L, r.totalCashPayouts)
            assertEquals(150_000L, r.staffAssistance)
            assertEquals(250_000L, r.masterBonus)
            assertEquals(0L, r.masterPenalty)
            assertEquals(18_600_000L, r.profit)
            assertEquals(0L, r.unallocated)
            assertEquals(5.35, r.totalWorkFinal, 1e-6)
            assertEquals(3_762_500L, r.unpaidWages)

            val m1 = r.masters.find { it.id == "m1" }!!
            assertEquals(3.75, m1.days, 1e-6)
            assertEquals(3.75, m1.workFinal, 1e-6)
            assertEquals(0.700935, m1.percent, 1e-6)
            assertEquals(13_037_383L, m1.share)
            assertEquals(0L, m1.reimburse)
            assertEquals(490_654L, m1.sharedPersonalExp)
            assertEquals(300_000L, m1.given)
            assertEquals(0L, m1.taken)
            assertEquals(0L, m1.advance)
            assertEquals(250_000L, m1.bonus)
            assertEquals(0L, m1.penalty)
            assertEquals(0L, m1.settle)
            assertEquals(13_096_729L, m1.finalBalance)

            val m2 = r.masters.find { it.id == "m2" }!!
            assertEquals(2.0, m2.days, 1e-6)
            assertEquals(1.6, m2.workFinal, 1e-6)
            assertEquals(0.299065, m2.percent, 1e-6)
            assertEquals(5_562_617L, m2.share)
            assertEquals(700_000L, m2.reimburse)
            assertEquals(209_346L, m2.sharedPersonalExp)
            assertEquals(0L, m2.given)
            assertEquals(300_000L, m2.taken)
            assertEquals(1_000_000L, m2.advance)
            assertEquals(0L, m2.bonus)
            assertEquals(0L, m2.penalty)
            assertEquals(50_000L, m2.settle)
            assertEquals(4_803_271L, m2.finalBalance)

            val a1 = r.staff.find { it.id == "a1" }!!
            assertEquals(2.625, a1.days, 1e-6)
            assertEquals(2, a1.full)
            assertEquals(0, a1.half)
            assertEquals(1, a1.hourly)
            assertEquals(1.0, a1.overtimeHours, 1e-6)
            assertEquals(1, a1.absent)
            assertEquals(3_837_500L, a1.baseWage)
            assertEquals(200_000L, a1.bonus)
            assertEquals(0L, a1.penalty)
            assertEquals(4_037_500L, a1.entitled)
            assertEquals(2_000_000L, a1.paid)
            assertEquals(0L, a1.assistance)
            assertEquals(2_000_000L, a1.totalPaid)
            assertEquals(2_037_500L, a1.debt)

            val c1 = r.staff.find { it.id == "c1" }!!
            assertEquals(2.75, c1.days, 1e-6)
            assertEquals(1, c1.full)
            assertEquals(1, c1.half)
            assertEquals(1, c1.hourly)
            assertEquals(2.0, c1.overtimeHours, 1e-6)
            assertEquals(0, c1.absent)
            assertEquals(2_475_000L, c1.baseWage)
            assertEquals(0L, c1.bonus)
            assertEquals(100_000L, c1.penalty)
            assertEquals(2_375_000L, c1.entitled)
            assertEquals(500_000L, c1.paid)
            assertEquals(150_000L, c1.assistance)
            assertEquals(650_000L, c1.totalPaid)
            assertEquals(1_725_000L, c1.debt)

            assertEquals(listOf("پرداختی به اوستا ثبت شده است (M1) و محاسبه نشد"), r.errors)
            assertTrue(r.negativeMasters.isEmpty())
        }
    }

    @Test
    fun testScenarioS1CommitmentVariants() {
        for (calcVer in listOf(1, 2)) {
            // Variant 1: commitment
            val p1 = buildScenarioS1Project(profitBasis = "commitment", calcVersion = calcVer)
            val r1 = AccountingEngine.compute(p1)
            assertEquals(14_837_500L, r1.profit)
            val m1 = r1.masters.find { it.id == "m1" }!!
            val m2 = r1.masters.find { it.id == "m2" }!!
            assertEquals(10_400_117L, m1.share)
            assertEquals(10_459_463L, m1.finalBalance)
            assertEquals(4_437_383L, m2.share)
            assertEquals(3_678_037L, m2.finalBalance)

            // Variant 2: commitment_ot15_pen0
            val p2 = buildScenarioS1Project(
                profitBasis = "commitment",
                overtimeFactor = 1.5,
                absentPenalty = 0.0,
                calcVersion = calcVer
            )
            val r2 = AccountingEngine.compute(p2)
            assertEquals(7_268_750L, r2.totalWages)
            assertEquals(13_981_250L, r2.profit)
            assertEquals(5.75, r2.totalWorkFinal, 1e-6)
            assertEquals(4_618_750L, r2.unpaidWages)
            val m1Ot = r2.masters.find { it.id == "m1" }!!
            val m2Ot = r2.masters.find { it.id == "m2" }!!
            assertEquals(9_118_207L, m1Ot.share)
            assertEquals(456_522L, m1Ot.sharedPersonalExp)
            assertEquals(9_211_685L, m1Ot.finalBalance)
            assertEquals(4_863_043L, m2Ot.share)
            assertEquals(243_478L, m2Ot.sharedPersonalExp)
            assertEquals(4_069_565L, m2Ot.finalBalance)

            val a1Ot = r2.staff.find { it.id == "a1" }!!
            val c1Ot = r2.staff.find { it.id == "c1" }!!
            assertEquals(3.1875, a1Ot.days, 1e-6)
            assertEquals(4_581_250L, a1Ot.baseWage)
            assertEquals(4_781_250L, a1Ot.entitled)
            assertEquals(2_781_250L, a1Ot.debt)
            assertEquals(2.875, c1Ot.days, 1e-6)
            assertEquals(2_587_500L, c1Ot.baseWage)
            assertEquals(2_487_500L, c1Ot.entitled)
            assertEquals(1_837_500L, c1Ot.debt)

            // Variant 3: commitment_norange
            val p3 = buildScenarioS1Project(
                profitBasis = "commitment",
                rangeFrom = "",
                rangeTo = "",
                calcVersion = calcVer
            )
            val r3 = AccountingEngine.compute(p3)
            assertEquals(30_000_000L, r3.totalReceipts)
            assertEquals(3_111_111L, r3.sharedExpenses)
            assertEquals(20_226_389L, r3.profit)
            val m1NoRange = r3.masters.find { it.id == "m1" }!!
            val m2NoRange = r3.masters.find { it.id == "m2" }!!
            assertEquals(14_177_375L, m1NoRange.share)
            assertEquals(14_236_721L, m1NoRange.finalBalance)
            assertEquals(6_049_014L, m2NoRange.share)
            assertEquals(5_289_668L, m2NoRange.finalBalance)
        }
    }

    @Test
    fun testScenarioS2TutorialPracticeWorkshop() {
        val sandbox = PracticeSandboxSeeder.seed("1405/08/13")
        assertEquals("🛠️ کارگاه تمرینی (آموزش زنده)", sandbox.name)
        assertTrue(PracticeSandboxSeeder.sandboxScenarioOk(sandbox))
    }

    @Test
    fun testScenarioS3GoldenExportsAndStatements() {
        val baseS1 = buildScenarioS1Project(profitBasis = "cash", calcVersion = 2)
        val s3Project = baseS1.copy(
            receipts = listOf(
                Receipt(
                    id = "r1",
                    dateFrom = "1405/08/01",
                    dateTo = "1405/08/20",
                    amount = 20_000_000L,
                    description = "r1",
                    active = true
                ),
                Receipt(
                    id = "r2",
                    dateFrom = "1405/07/20",
                    dateTo = "1405/08/09",
                    amount = 10_000_000L,
                    description = "=SUM(A1)",
                    active = true
                )
            ),
            expenses = listOf(
                Expense(
                    id = "e1",
                    date = "1405/08/05",
                    amount = 3_000_000L,
                    description = "shared",
                    payerId = "shared",
                    active = true
                ),
                Expense(
                    id = "e2",
                    date = "1405/08/07",
                    amount = 700_000L,
                    description = "personal m2",
                    payerId = "m2",
                    active = true
                )
            ),
            payouts = listOf(
                Payout(
                    id = "p1",
                    date = "1405/08/15",
                    userId = "a1",
                    amount = 2_000_000L,
                    active = true
                )
            ),
            transfers = listOf(
                Transfer(
                    id = "t1",
                    date = "1405/08/17",
                    kind = "peer",
                    fromId = "m1",
                    toId = "m2",
                    amount = 300_000L,
                    active = true
                ),
                Transfer(
                    id = "t2",
                    date = "1405/08/18",
                    kind = "advance",
                    fromId = null,
                    toId = "m2",
                    amount = 1_000_000L,
                    active = true
                )
            ),
            adjustments = listOf(
                Adjustment(
                    id = "adj1",
                    date = "1405/08/19",
                    userId = "a1",
                    kind = "bonus",
                    amount = 200_000L,
                    active = true
                )
            )
        )

        val r = AccountingEngine.compute(s3Project)
        val finCsv = StatementBuilder.buildFinancialReportCsv(s3Project, r, nowStr = "{now}", includeBom = false)
        val expectedFinCsv = """
گزارش جامع مالی — استایار
پروژه,Test
بازه,1 آبان 1405 تا 30 آبان 1405
مبنای سود,نقدی
تاریخ تهیه,{now}

شاخص‌های کلیدی
شاخص,مبلغ (تومان)
مجموع واریزی,24500000
هزینه‌های مشترک,3000000
هزینه‌های شخصی اوستاها,700000
کل دستمزد استحقاقی,6512500
پرداختی‌های نقدی,2000000
مساعده پرسنل,0
پاداش اوستاها,0
جریمه اوستاها,0
مانده قابل تقسیم,19500000

سهم اوستاها
نام,کارکرد (روز),ضریب,کارکرد نهایی,درصد سهم,سهم پایه,بازپرداخت هزینه شخصی,سهم هزینه شخصی,انتقال داده‌شده,انتقال گرفته‌شده,پیش‌برداشت,مساعده,پاداش,جریمه,تسویه نقدی,مانده نهایی
M1,3.75,1,3.75,70.09,13668224,0,490654,300000,0,0,0,0,0,0,13477570
M2,2,0.8,1.6,29.91,5831776,700000,209346,0,300000,1000000,0,0,0,0,5022430

تراز شاگردان و پرسنل سایر
نام,نوع,روز کامل,روز نصفه,ساعتی,ساعت اضافه‌کار,دستمزد پایه,پاداش,جریمه,دستمزد استحقاقی,پرداختی,مساعده,مانده
A1,شاگرد,2,0,1,1,3837500,200000,0,4037500,2000000,0,2037500
C1,سایر پرسنل,1,1,1,2,2475000,0,0,2475000,0,0,2475000
        """.trimIndent()
        assertEquals(expectedFinCsv, finCsv)

        val auditCsv = StatementBuilder.buildDetailedAuditCsv(s3Project, r, includeBom = false)
        assertTrue(auditCsv.contains("واریزی,1405/08/01 تا 1405/08/20,r1,,,20000000,,فعال,20000000"))
        assertTrue(auditCsv.contains("واریزی,1405/07/20 تا 1405/08/09,'=SUM(A1),,,10000000,,فعال,4500000"))
        assertTrue(auditCsv.contains("انتقال,1405/08/17,,,M1 → M2,300000,,فعال,"))
        assertTrue(auditCsv.contains("پیش‌برداشت,1405/08/18,,,صندوق → M2,1000000,,فعال,"))

        val stA1 = StatementBuilder.statementText(s3Project, "a1", r)
        val expectedStA1 = """
📒 صورتحساب کارگاه — استایار
👤 A1 (شاگرد)
🏗️ پروژه: Test
📅 بازه: 1 آبان 1405 تا 30 آبان 1405
━━━━━━━━━━━━━━
⏱️ کارکرد: 2.63 روز (کامل 2، نصفه 0، ساعتی 1، غایب 1)
💰 دستمزد پایه: 3,837,500 تومان
🎁 پاداش: 200,000 تومان
⚠️ جریمه: 0 تومان
📌 دستمزد استحقاقی: 4,037,500 تومان
💵 پرداختی و مساعده: 2,000,000 تومان
━━━━━━━━━━━━━━
✅ مانده طلب: 2,037,500 تومان
        """.trimIndent()
        assertEquals(expectedStA1, stA1)

        val stM2 = StatementBuilder.statementText(s3Project, "m2", r)
        val expectedStM2 = """
📒 صورتحساب کارگاه — استایار
👤 M2 (اوستا)
🏗️ پروژه: Test
📅 بازه: 1 آبان 1405 تا 30 آبان 1405
━━━━━━━━━━━━━━
⏱️ کارکرد: 2 روز (کامل 2، نصفه 1، ساعتی 0، غایب 1)
📊 سهم از سود: ٪29.9 = 5,831,776 تومان
🧾 بازپرداخت هزینه شخصی: 700,000 تومان
➖ سهم هزینه‌های شخصی مشترک: 209,346 تومان
🔄 انتقال‌ها (خالص): -300,000 تومان
🏦 پیش‌برداشت و مساعده: 1,000,000 تومان
🎁 پاداش/جریمه: 0 تومان
━━━━━━━━━━━━━━
✅ مانده تسویه: 5,022,430 تومان
        """.trimIndent()
        assertEquals(expectedStM2, stM2)
    }

    @Test
    fun testSymmetricRationalArithmeticDefectQ13() {
        val users = listOf(
            User(id = "m1", name = "M1", type = UserType.MASTER, main = true),
            User(id = "a1", name = "A1", type = UserType.APPRENTICE)
        )
        val wages = listOf(Wage(id = "w1", userId = "a1", rate = 1_000_001L, effectiveDate = "1405/01/01"))
        val attendance = mapOf(
            "1405/08/01" to mapOf("a1" to AttendanceValue.Half),
            "1405/08/02" to mapOf("a1" to AttendanceValue.Absent)
        )
        val p = Project(
            id = "p_q13",
            settings = ProjectSettings(absentPenalty = 0.5, calcVersion = 2),
            users = users,
            wages = wages,
            attendance = attendance
        )
        val r = AccountingEngine.compute(p)
        val a1 = r.staff.first()
        // +500,001 and -500,001 cancel out to 0L under calcVersion = 2
        assertEquals(0L, a1.baseWage)
    }
}
