package com.workshop.ledger

import com.workshop.ledger.domain.engine.DataHealthChecker
import com.workshop.ledger.domain.engine.HealthSeverity
import com.workshop.ledger.domain.engine.SampleProjectFactory
import com.workshop.ledger.domain.model.AppState
import com.workshop.ledger.domain.model.Expense
import com.workshop.ledger.domain.model.ProjectSettings
import com.workshop.ledger.domain.tutorial.OnboardingState
import com.workshop.ledger.domain.validation.ProjectSanitizer
import com.workshop.ledger.domain.validation.StateValidator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class StateValidatorTest {

    @Test
    fun testValidFreshStateAndOnboardingStepRangeQ2() {
        val project = SampleProjectFactory.createEmptyProject()
        val state = AppState(
            version = 3,
            activeProjectId = project.id,
            onboarding = OnboardingState(
                status = "in_quest",
                questStep = 23, // Previously broken by 0..4 clamp in v1.0; now 0..27 supported!
                sandboxProjectId = "demo_quest_abc123",
                chapter = 3
            ),
            projects = listOf(project)
        )
        val res = StateValidator.validateAppState(state)
        assertTrue("Expected valid state, got: ${res.errors}", res.ok)
    }

    @Test
    fun testRejectsInvalidMoneyAndPositionalErrorMessage() {
        val base = SampleProjectFactory.createEmptyProject()
        val badExpense = Expense(
            id = "exp_bad",
            date = "1405/08/10",
            amount = -500L,
            description = "bad",
            payerId = "shared"
        )
        val p2 = base.copy(id = "proj_2", expenses = listOf(badExpense, badExpense, badExpense, badExpense, badExpense))
        val state = AppState(
            activeProjectId = base.id,
            projects = listOf(base, p2)
        )
        val res = StateValidator.validateAppState(state)
        assertFalse(res.ok)
        assertTrue(res.errors.any { it.contains("پروژه 2 / هزینه 5: مبلغ (amount) نامعتبر، منفی یا بیش از سقف مجاز است.") })
    }

    @Test
    fun testProjectSanitizerLegacyMigration() {
        val p = SampleProjectFactory.createEmptyProject().copy(
            settings = ProjectSettings(overtimeFactor = 1.4, calcVersion = 2)
        )
        val sanitized = ProjectSanitizer.sanitizeProject(p, legacyVersion = 2)
        assertEquals(1.0, sanitized.value.settings.overtimeFactor, 1e-9)
        assertEquals(1, sanitized.value.settings.calcVersion)
        assertTrue(sanitized.fixes >= 1)
    }

    @Test
    fun testDataHealthChecker9Rules() {
        val sample = SampleProjectFactory.createSampleProject("1405/08/13")
        val rules = DataHealthChecker.check(sample)
        assertEquals(9, rules.size)
        val masterRule = rules.find { it.code == "master" }!!
        assertEquals(HealthSeverity.OK, masterRule.severity)
    }
}
