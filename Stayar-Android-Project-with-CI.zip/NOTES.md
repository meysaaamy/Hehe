# NOTES — «استایار» (Stayar) 100% Pure Native Android Workshop Ledger

Package: `com.workshop.ledger`  
Version: `1.0.0` (Native Android Rebuild)  
Target: Kotlin 2.1+ (K2 compiler), minSdk 26, targetSdk 35, compileSdk 35, Jetpack Compose Material 3.

---

## 1. Architectural Overview & Deliverables Status

### [D1] Self-Contained Android Gradle Architecture
- **Clean Architecture**: Decoupled packages (`domain`, `data`, `presentation`, `core`).
- **Zero WebView & Zero JavaScript**: Completely purged legacy hybrid bottlenecks (no `android.webkit.WebView`, no `localStorage`, no `DOM MutationObserver`, no JSON bridge serializations).
- **Offline Security**: Only `android.permission.VIBRATE` requested. `android.permission.INTERNET` is strictly omitted.

### [D2] Pure Kotlin Domain Layer
- **Value Classes**: Zero-allocation `@JvmInline value class Money(val tomans: Long)`, `JalaliDate(val packed: Int)`, `ProjectId`, `UserId`, `CategoryId`.
- **Dual-Mode Calculation Engine (`calcVersion` 1 & 2)**:
  - `calcVersion = 2` (Default): Exact 64-bit integer rational arithmetic with symmetric half-away-from-zero rounding (`roundHalfAwayFromZero`) and lower-index tie-breaking. Fractions use denominator `1600L`.
  - `calcVersion = 1` (Legacy): Reproduces IEEE-754 `Double` and `Math.round()` toward `+infinity` for bit-for-bit backward compatibility with v1.0 exports.
- **Bit-Packed Jalali Engine**: 33-year cycle break table with bit-shift date packing `(year shl 9) or (month shl 5) or day`.
- **Persian Money Words & Keypad**: Persian numeral text synthesizer (`numToFaWord`) and inline arithmetic parser (`+` / `−` expressions).
- **Data Health Checker**: All 9 automated quality assurance rules with jump-to-fix and orphan record cleaning.
- **28-Step Interactive Tutorial State Machine**: 3 chapters with proactive guards, presets, and sandbox seeder (`PracticeSandboxSeeder`).

### [D3] Native Data & Infrastructure Layer
- **Room Database in WAL Mode**: Foreign key cascades (`ForeignKey.CASCADE`), `@Upsert` DAOs, and SQLite triggers on all 9 child tables (`BEFORE INSERT`, `BEFORE UPDATE`, `BEFORE DELETE`) raising `ABORT 'PERIOD_LOCKED'` when `projects.locked == 1`.
- **Proto DataStore (`app_prefs.pb`)**: Persists device preferences, digits mode, theme mode, and onboarding tutorial state (steps 0..27).
- **ACID Backups**: `AtomicFile` emergency recovery snapshots (`recovery_snapshot.json.gz`) via `executeDestructiveAction()` before any state-modifying or destructive operation.
- **Document Engine (`StayarDocumentEngine`)**: Two-pass measurement and rendering for true vector `PdfDocument` (~40 KB) and 2x high-resolution A4 PNG bitmaps (`1588 x 2246 px`).
- **Audio & Haptics**: Low-latency 44.1 kHz PCM synthesizer (`NativePcmSynthesizer`) using `AudioTrack` and rich tactile haptics (`RichHapticsManager`).

### [D4] Presentation Layer (Jetpack Compose Material 3)
- **4 Themes**: Cream Light (`#EFE6D3`), Dark (`#0A0A0F`), System, and Sunlight Outdoor High-Contrast (`#FFFFFF` background, `#000000` text, 2.dp bold borders).
- **Custom Keypad (`WorkshopMoneyKeypad`)**: Dedicated `۰۰۰` (thousand) and `۰۰۰٬۰۰۰` (million) keys, inline math operator support, and live Persian words.
- **Attendance Matrix (`LazyTwoDimensionalGrid`)**: Bi-directional 120 FPS scrolling matrix with sticky headers and day summary footers.
- **4 Interactive Compose Charts**: 3D extruded donut chart, horizontal share bars, cash flow trend, and workshop financial balance diverging chart.
- **Quest Coordinator & Beacon**: `Modifier.questTarget()`, pulsing beacon overlay, and docked progress bar.

### [D5] Unit Test Suite
- Automated JVM tests (`EngineTestVectors.kt`, `StateValidatorTest.kt`) covering:
  - Primitive vectors: `attFraction`, `allocate`, `receiptShare`, `numToFaWord`, `parseMoney`, formatting, and Jalali conversions.
  - Scenario S1: Fixed dates, two masters, apprentice, custom worker, cash & commitment basis.
  - Scenario S2: Tutorial sandbox scenario seeder and verification.
  - Scenario S3: Golden exports (financial CSV with UTF-8 BOM, detailed audit CSV, and statement texts).
  - Defect Q13: Symmetric rational arithmetic tie-free invariant.
  - State validation & ProjectSanitizer migration rules.

---

## 2. Implementation Choices Where Specification Was Silent

1. **Ambient Light Sensor Integration**:
   - `MainActivity` registers a `Sensor.TYPE_LIGHT` listener. When ambient light exceeds `20,000 lux` (typical direct midday construction sunlight in Iran), the UI dynamically swaps the active palette to `ThemeMode.SUNLIGHT` with high-contrast borders and deep contrast ink.
2. **Project Structure Cloning**:
   - `cloneProjectStructure()` preserves users, re-mapped wage rates, categories, and settings (profit basis, overtime factor, absent penalty) while clearing financial attendance, expenses, receipts, payouts, and transfers, naming the new project `«{name} (تکثیر)»`.
3. **Emergency Snapshot File Retention**:
   - Emergency recovery snapshots are written to `context.filesDir/backups/recovery_snapshot.json.gz` using `AtomicFile`. Up to 3 rolling auto-backup snapshots are rotated in `rolling_snap_1..3.json.gz`.
4. **Font Loading & OpenType Features**:
   - Monospace amounts and Persian tabular numbers leverage OpenType `fontFeatureSettings = "tnum"` with `LayoutDirection.Ltr` to prevent number-reversal in RTL layouts while preserving Persian glyphs (`۰-۹`).
